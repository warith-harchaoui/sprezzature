# Rendre lisible un graphique de détection de sauts

Réponse à la question d'un ami : *« comment employer votre outil pour
visualiser un peu plus joliment ce genre de graphique ? »*, à propos d'une
figure BTC/USDT à deux panneaux — prix + rendements minute, avec les alertes
de `highfrequency::intradayJumpTest` superposées.

Données **fictives**, statistique **réelle** : les prix sont simulés, mais le
détecteur est le vrai test de Lee & Mykland (2008). Les 15 points marqués sont
des alertes que le test a effectivement levées, pas des points placés à la
main. Une démo qui dessine ses propres conclusions ne prouve rien.

## D'abord : le graphique de départ est bon

Il est honnête là où beaucoup ne le sont pas — il distingue le seuil corrigé
du seuil exploratoire, il dit que la première heure de chaque segment n'est
pas testable, et il refuse explicitement d'attribuer une cause à une
coïncidence. Ce n'est pas l'analyse qu'il faut refaire.

Ce qu'il coûte, c'est de la **charge de lecture**. C'est là-dessus que les six
changements ci-dessous portent, et chacun a une raison.

| Changement | Pourquoi |
|---|---|
| **Un seul axe de temps**, en bas | Les deux panneaux partagent la même horloge. L'axe dessiné deux fois oblige l'œil à revérifier qu'il s'agit bien du même instant. Un repère vertical traversant les deux panneaux devient alors sans ambiguïté. |
| **Le seuil en bande pleine**, pas en pointillés | Le panneau B est l'encre la plus dense de la figure : des milliers de pics gris traversés par deux courbes pointillées que l'œil confond avec des données. Un aplat pâle dit « ici, c'est ordinaire » sans concurrencer les pics. |
| **Plein vs creux**, pas rouge vs ocre | Disque rouge contre cercle ocre, ce sont deux teintes chaudes — exactement la paire que le gris et la vision deutan effacent. Disque plein contre anneau vide survit aux deux ; la teinte devient un renfort redondant au lieu d'être tout le signal. |
| **La légende sur la figure** | Les marques sont nommées là où elles servent. Le lecteur n'a plus à descendre dans les notes pour savoir ce qu'est un point. |
| **Un titre qui dit le résultat** | « Prix BTC/USDT — alertes superposées » décrit le contenu ; le lecteur doit encore trouver ce qui s'est passé. |
| **Survol** | Chaque alerte porte horodatage, prix, rendement et statistique. Le détail qui encombrerait le tracé est à un pointeur — et la révélation est en **CSS pur** (`#hit-n:hover ~ #tip-n`), sans une ligne de JavaScript. |

## Ce que la Ralph Eyeball Loop a rattrapé

C'est le point le plus utile pour votre ami, et il ne tient pas au style.
Six itérations, et **quatre défauts n'étaient visibles que dans le rendu ou à
l'exécution** — à chaque fois avec un SVG valide, un code de sortie 0 et des
chiffres exacts.

### Itération 1 — les quinze infobulles s'affichaient en permanence

Elles recouvraient tout le panneau A. La courbe de prix, sujet de la figure,
n'était plus qu'une poignée de fragments bleus entre des rectangles blancs.

Cause : le helper `foreground_tip_css` n'émet que les règles de *révélation*,
indexées sur des **id**. La règle de base `.tip{opacity:0}` est à la charge de
l'appelant, et je ne l'avais pas écrite. Par-dessus, j'utilisais des classes là
où le helper attend des id, et j'avais emballé la cible dans un `<g>`, ce qui
casse le combinateur de frères.

### Itération 2 — l'annotation traversait la courbe

Elle était placée à un décalage fixe au-dessus du point marqué ; or ce point est
un pic d'une minute, et la courbe de part et d'autre est *plus haute que le pic
lui-même*. Elle mesure désormais le maximum local sur sa propre largeur de
texte.

### Itération 3 — vérifications

Simulation en niveaux de gris et en deutéranopie : la distinction plein / creux
tient sans couleur. Auditeur statique maison (`audit_figure.py`) : aucune
remarque. XML bien formé.

### Itération 4 — la passe française a révélé un double échappement

L'infobulle affichait `statistique 10.0 confirm&#233;e`, l'entité imprimée telle
quelle : j'avais écrit la table de chaînes avec des entités numériques, et une
valeur qui traverse `tooltip_bubble` est ré-échappée en XML. Toute la table est
passée en UTF-8 réel, qui n'a pas ce mode de défaillance.

### Itération 5 — le clic

Le contrôle plein écran maison pose un gestionnaire de clic sur la racine
`<svg>` et lui met `tabindex="0"` : cliquer une alerte basculait en plein écran
au lieu d'épingler sa valeur, et le focus dessinait un liseré bleu parasite
autour de toute la figure. Retiré ; le plein écran est un bouton étiqueté dans
la page.

Deux autres défauts trouvés en pilotant de **vrais** événements souris et
clavier (CDP) plutôt qu'en raisonnant sur le balisage : le panneau B n'avait
**aucune** cible de survol — pointer le pic qui explique l'alerte ne faisait
rien — et `.hit:focus-visible ~ .ring` allumait tous les anneaux suivants, parce
que `~` vise les frères *généraux* et non l'adjacent.

### Itération 6 — rendre l'envoi possible

À la question « est-ce que je peux zipper ce dossier et l'envoyer ? », la réponse
était non : `make_jumpscan.py` allait chercher ses helpers dans
`~/sprezzature-figures/`, absent chez le destinataire. Le moteur de dessin est
désormais empaqueté dans `sprezzature_svg.py`, et les constantes partagées
extraites dans `common.py` — ce qui rend la séparation réelle : calculer demande
numpy, dessiner n'exige que la bibliothèque standard.

---

Le compte rendu détaillé des six itérations est dans
`ralph-loop-assessment.md`.

## Reproduire

```sh
cd ~/sprezzature/g
python3 make_data.py           # calcule et écrit jumpscan.csv + events.csv
python3 make_jumpscan.py       # lit les CSV, écrit jumpscan.svg
open index.html                # la page : plein écran, survol, clic, clavier

# la boucle elle-même
python3 ~/sprezzature-figures/scripts/ralph_eyeball_loop.py jumpscan.svg
```

Séparation nette : `make_data.py` **calcule** (numpy), `make_jumpscan.py`
**dessine** (bibliothèque standard seule). Tout ce que la figure montre est
dans le CSV — inspectable dans un tableur, remplaçable par un vrai flux.

La page charge la figure dans un `<object>`, **pas** dans un `<img>` : une
balise `<img>` met le SVG en bac à sable et tue le `:hover` sur lequel les
infobulles reposent. C'est toute la raison d'être de la page plutôt que d'une
capture.

Le SVG est un fichier unique : infobulles en CSS, aucune ligne de JavaScript.
Les polices (Roboto) sont **liées** depuis Google Fonts plutôt qu'embarquées —
262 Ko au lieu de 684 Ko. Contrepartie à connaître : elles ne se chargent que si
le SVG est le document (ouvert directement, ou via `<object>` / `<iframe>`
comme le fait `index.html`). Dans une balise `<img>`, le navigateur bloque la
requête externe et la figure retombe sur une police système ; tout le reste
s'affiche normalement.

## Honnêteté du jeu de données

16 sauts injectés, **15 retrouvés**, 1 manqué — celui volontairement placé
sous le seuil. Zéro fausse alarme. Les deux alertes exploratoires sont deux
sauts calibrés pour tomber dans la bande étroite entre le seuil à 1 % et le
seuil corrigé sur 3 segments. C'est ce que fait un détecteur réel : il rate
des choses, et la figure le dit plutôt que de le taire.

## Fichiers

| Fichier | Rôle |
|---|---|
| `make_data.py` | Calcule : série minute simulée + test de Lee-Mykland (variation bipuissance, seuil de Gumbel, Bonferroni sur 3 segments) |
| `jumpscan.csv` | Les données : une ligne par minute — prix, rendement, seuil, statistique, verdict |
| `events.csv` | Les trois publications macro marquées en rails |
| `make_jumpscan.py` | Dessine : lit les CSV, écrit le SVG directement |
| `jumpscan.svg` | Le résultat, interactif |
| `index.html` | La page qui le charge : plein écran, survol, clic |
| `sprezzature_svg.py` | Le moteur de dessin, empaqueté — c'est lui qui rend le dossier autonome |
| `common.py` | Les quelques constantes partagées, sans dépendance |
| `ralph-loop-assessment.md` | Le compte rendu des itérations |
