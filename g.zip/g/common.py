"""
common — the handful of facts both scripts need, and nothing else.

``make_data.py`` computes and needs numpy; ``make_jumpscan.py`` only draws
and should need nothing at all. They still share a few constants — how long a
day is, how the test was parameterised, how a minute index reads as a clock —
and routing those through the computing script would have dragged numpy into
the drawing one, quietly breaking the split this layout exists to make.

So: standard library only, no imports beyond ``typing``. If something here
ever needs a third-party package, it belongs in ``make_data.py`` instead.

Author
------
`Warith Harchaoui, Ph.D. <https://www.linkedin.com/in/warith-harchaoui/>`_
"""

from __future__ import annotations

from typing import Dict, Tuple

#: Minutes per day, and the three-day window the figure covers.
MINUTES_PER_DAY: int = 1440
N_DAYS: int = 3
N: int = MINUTES_PER_DAY * N_DAYS

#: Trailing window for the local volatility estimate, in observations. Quoted
#: on the figure, so it lives where both scripts can reach it.
VOL_WINDOW: int = 60

#: Per-segment significance, and the number of segments the correction
#: divides it across.
ALPHA_EXPLORATORY: float = 0.01
N_SEGMENTS: int = 3

#: Day labels per language, for the timestamp column and the figure's axis.
DAY_NAMES: Dict[str, Tuple[str, ...]] = {
    "en": ("Jul 15", "Jul 16", "Jul 17", "Jul 18"),
    "fr": ("15 juil.", "16 juil.", "17 juil.", "18 juil."),
}


def clock(minute: int, language: str = "en") -> str:
    """
    ``Jul 16 14:07`` for a minute index into the window.

    Parameters
    ----------
    minute : int
        Minutes since the start of the window.
    language : str, optional
        ``"en"`` or ``"fr"``; an unknown value falls back to English rather
        than raising, so a typo degrades to a readable label.

    Returns
    -------
    str
        Day name and 24-hour clock, no timezone suffix — the figure states
        UTC once, on the axis, instead of repeating it on every mark.
    """
    day, rest = divmod(minute, MINUTES_PER_DAY)
    hour, mi = divmod(rest, 60)
    return f"{DAY_NAMES.get(language, DAY_NAMES['en'])[day]} {hour:02d}:{mi:02d}"
