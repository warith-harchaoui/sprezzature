"""
make_data — write the minute series and its jump alerts to CSV.

Splits cleanly in two: this file *computes*, the figure generator beside it
only *draws*. Everything the chart shows lives in ``jumpscan.csv`` and
``events.csv``, so the data can be inspected in a spreadsheet, swapped for a
real feed, or handed to a different renderer without touching drawing code.

The prices are synthetic; the statistic is not. The detector below is the
real Lee & Mykland (2008) intraday jump test, so a row flagged in the CSV is
a row the test actually flagged. A demo that hand-placed its alerts would
prove nothing about the chart it is demonstrating.

Usage
-----
::

    python3 make_data.py            # writes jumpscan.csv + events.csv
    python3 make_data.py --seed 7   # a different three days

Author
------
`Warith Harchaoui, Ph.D. <https://www.linkedin.com/in/warith-harchaoui/>`_
"""

from __future__ import annotations

import argparse
import csv
import math
from pathlib import Path
from typing import Any, Dict, List, Tuple

import numpy as np

from common import (  # shared, dependency-free
    ALPHA_EXPLORATORY,
    MINUTES_PER_DAY,
    N,
    N_SEGMENTS,
    VOL_WINDOW,
    clock,
)

#: sqrt(2/pi), the scaling constant of the bipower variation estimator.
_C: float = math.sqrt(2.0 / math.pi)

#: Injected jumps: ``(minute index, size in units of the local volatility at
#: that minute)``. Sizing in sigma rather than in percent is what makes the
#: set meaningful — a 0.4% move is a jump at 3am and noise during a data
#: release, and the detector exists to know the difference. The spread is
#: deliberate: most sit clear of the corrected threshold (~6.1), two are
#: parked just under it so they surface only at the exploratory level, and
#: one sits below both as a jump the method simply misses. A demo where
#: every injected jump is recovered would be advertising.
_INJECTED: Tuple[Tuple[int, float], ...] = (
    (412, +11.5),
    (735, -8.2),
    (1_063, +7.1),
    (1_255, -6.6),
    (1_420, -9.4),
    (1_704, +13.2),
    (2_118, -7.6),
    (2_402, +6.9),
    (2_610, -6.20),
    (2_760, -10.8),
    (3_090, +7.8),
    (3_355, -6.5),
    (3_618, +9.1),
    (3_902, -8.6),
    (4_115, +6.32),
    (4_260, +5.2),
)

#: Scheduled macro releases in the window. Descriptive simultaneity only:
#: nothing here claims a release caused a jump.
EVENTS: Tuple[Dict[str, Any], ...] = (
    {
        "id": "E09",
        "minute": 0 * MINUTES_PER_DAY + 750,
        "en": "US producer prices (PPI)",
        "fr": "Prix à la production US (PPI)",
    },
    {
        "id": "E10",
        "minute": 1 * MINUTES_PER_DAY + 810,
        "en": "US retail sales",
        "fr": "Ventes de détail US",
    },
    {
        "id": "E11",
        "minute": 2 * MINUTES_PER_DAY + 780,
        "en": "US industrial production",
        "fr": "Production industrielle US",
    },
)


def _volatility_path(rng: np.random.Generator) -> np.ndarray:
    """
    Per-minute volatility: an intraday seasonal times a slow random factor.

    Crypto trades around the clock, so the seasonal is mild — a broad lift
    across the European/US overlap rather than the sharp open-close U-shape
    of an equity session.
    """
    minute_of_day = np.arange(N) % MINUTES_PER_DAY
    seasonal = 1.0 + 0.45 * np.exp(-0.5 * ((minute_of_day - 870) / 260.0) ** 2)
    seasonal += 0.18 * np.exp(-0.5 * ((minute_of_day - 30) / 90.0) ** 2)

    # theta / sigma_ou give a stationary spread of about +-0.25 in logs, so
    # the factor swings roughly 0.8x to 1.3x. Wider and the price level
    # wanders far enough to bury the jumps in the panel.
    log_factor = np.zeros(N)
    theta, sigma_ou = 0.0020, 0.0158
    for t in range(1, N):
        log_factor[t] = log_factor[t - 1] * (1.0 - theta) + sigma_ou * rng.standard_normal()
    # Scaled so three days accumulate a couple of percent of drift-free
    # travel: the order of magnitude of a quiet mid-July window.
    return 0.00023 * seasonal * np.exp(log_factor)


def build_series(seed: int = 20260715) -> Dict[str, Any]:
    """Generate the price path and its log returns."""
    rng = np.random.default_rng(seed)
    sigma = _volatility_path(rng)

    ret = sigma * rng.standard_normal(N)
    ret += -0.0000042  # a mild drift, so the path has somewhere to go
    for minute, size_in_sigma in _INJECTED:
        ret[minute] += size_in_sigma * sigma[minute]

    price = 65_000.0 * np.exp(np.concatenate([[0.0], np.cumsum(ret)]))
    return {"price": price, "ret": ret, "injected": np.array([m for m, _ in _INJECTED])}


def _bipower_sigma(ret: np.ndarray, window: int = VOL_WINDOW) -> np.ndarray:
    """
    Local volatility from trailing bipower variation.

    Bipower variation — the mean of ``|r_i| * |r_{i-1}|`` — is robust to jumps
    in a way a rolling standard deviation is not: one large return inflates a
    variance estimate enough to mask itself, whereas multiplying neighbours
    keeps a single outlier from dominating.
    """
    products = np.abs(ret[1:]) * np.abs(ret[:-1])
    sigma = np.full(ret.size, np.nan)
    rolled = np.convolve(products, np.ones(window - 2), mode="valid") / (window - 2)
    start = window - 1
    usable = min(rolled.size, ret.size - start)
    sigma[start : start + usable] = np.sqrt(rolled[:usable] / (_C**2))
    return sigma


def _gumbel_threshold(n_tested: int, alpha: float) -> float:
    """
    Critical value for the maximum of ``n_tested`` statistics.

    Under the null of no jump the statistics behave like absolute normals, so
    their *maximum* over a day is Gumbel. Testing each minute at alpha would
    flag one in a hundred by chance alone — fourteen false alarms a day on
    1 440 minutes.
    """
    log_n = math.log(n_tested)
    root = math.sqrt(2.0 * log_n)
    c_n = root / _C - (math.log(math.pi) + math.log(log_n)) / (2.0 * _C * root)
    s_n = 1.0 / (_C * root)
    return c_n + s_n * (-math.log(-math.log(1.0 - alpha)))


def detect(series: Dict[str, Any]) -> Dict[str, Any]:
    """Run the test over the series and classify every minute."""
    ret = series["ret"]
    sigma_hat = _bipower_sigma(ret)
    stat = ret / sigma_hat

    n_tested = int(np.isfinite(stat).sum() / N_SEGMENTS)
    level_exploratory = _gumbel_threshold(n_tested, ALPHA_EXPLORATORY)
    level_confirmed = _gumbel_threshold(n_tested, ALPHA_EXPLORATORY / N_SEGMENTS)

    magnitude = np.abs(stat)
    kind = np.full(ret.size, "", dtype=object)
    kind[magnitude > level_exploratory] = "exploratory"
    kind[magnitude > level_confirmed] = "confirmed"

    return {
        "stat": stat,
        "sigma_hat": sigma_hat,
        "band": level_confirmed * sigma_hat,
        "kind": kind,
        "level_confirmed": level_confirmed,
        "level_exploratory": level_exploratory,
        "n_tested": n_tested,
    }


def write_csv(seed: int, out_dir: Path) -> Dict[str, int]:
    """
    Write ``jumpscan.csv`` and ``events.csv``; return a small summary.

    One row per minute, every column the figure reads and nothing it does
    not. ``band_pct`` is blank for the first window of each segment, which is
    how the CSV says "not testable here" rather than implying a threshold
    that does not exist.
    """
    series = build_series(seed)
    found = detect(series)
    injected = set(series["injected"].tolist())

    rows: List[Dict[str, Any]] = []
    for i in range(N):
        band = found["band"][i]
        stat = found["stat"][i]
        rows.append(
            {
                "minute": i,
                "timestamp": clock(i),
                "price": f"{series['price'][i + 1]:.2f}",
                "ret_pct": f"{series['ret'][i] * 100:.6f}",
                "band_pct": "" if not np.isfinite(band) else f"{band * 100:.6f}",
                "statistic": "" if not np.isfinite(stat) else f"{stat:.4f}",
                "alert": found["kind"][i],
                "was_injected": int(i in injected),
            }
        )

    out_dir.mkdir(parents=True, exist_ok=True)
    data_path = out_dir / "jumpscan.csv"
    with data_path.open("w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)

    events_path = out_dir / "events.csv"
    with events_path.open("w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=["id", "minute", "timestamp", "label_en", "label_fr"])
        writer.writeheader()
        for ev in EVENTS:
            writer.writerow(
                {
                    "id": ev["id"],
                    "minute": ev["minute"],
                    "timestamp": clock(ev["minute"]),
                    "label_en": ev["en"],
                    "label_fr": ev["fr"],
                }
            )

    confirmed = int((found["kind"] == "confirmed").sum())
    exploratory = int((found["kind"] == "exploratory").sum())
    recovered = sum(1 for i in injected if found["kind"][i])
    print(f"wrote {data_path}   ({N:,} rows, {data_path.stat().st_size / 1024:.0f} KB)")
    print(f"wrote {events_path}  ({len(EVENTS)} rows)")
    print()
    print(f"  threshold  exploratory   {found['level_exploratory']:.3f}")
    print(f"  threshold  confirmed     {found['level_confirmed']:.3f}")
    print(f"  alerts     confirmed     {confirmed}")
    print(f"  alerts     exploratory   {exploratory}")
    print(f"  injected jumps           {len(_INJECTED)}   recovered {recovered}   "
          f"missed {len(_INJECTED) - recovered}")
    print(f"  false alarms             {confirmed + exploratory - recovered}")
    return {"confirmed": confirmed, "exploratory": exploratory, "recovered": recovered}


def main() -> None:
    """Command-line entry point."""
    parser = argparse.ArgumentParser(description="Write the minute series and its jump alerts to CSV.")
    parser.add_argument("--seed", type=int, default=20260715, help="random seed (default: 20260715)")
    parser.add_argument("--out-dir", type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    write_csv(args.seed, args.out_dir)


if __name__ == "__main__":
    main()
