"""
make_jumpscan — price, minute returns and jump alerts on one shared time axis.

The chart this answers is already careful and honest: two stacked panels, a
price path with alerts overlaid, minute returns against a local-volatility
threshold, macro releases marked as rails, and a footnote that refuses to
claim causation. Nothing about it is wrong. What it costs the reader is
*work*: the time axis is drawn twice, the threshold is two dashed lines
crossing a field of grey spikes, and the meaning of every mark lives in
small print under the figure rather than on it.

So this is not a redesign of the analysis, only of the reading. The changes
that matter, each one for a stated reason:

**One time axis, at the bottom.** The two panels share a clock, so the axis
is drawn once and the panels are locked to it. A rail dropped through both
is then unambiguous: the same instant, top and bottom.

**The threshold as a filled ribbon, not two dashed curves.** Panel B is the
busiest ink in the original — thousands of grey spikes crossed by two dashed
blue lines that the eye keeps mistaking for data. A soft wash says "inside
here is ordinary" without competing with the spikes, and a spike that leaves
the wash is visible at a glance.

**Alerts told apart by shape, not only hue.** Red disc versus ochre ring is a
hue distinction between two warm colours, which is exactly the pair that
greyscale printing and red-weak vision collapse. Filled disc versus hollow
ring survives both: the hue is then redundant reinforcement rather than the
whole signal.

**The key on the figure.** Marks are named where they are used, so the
reader never travels to a caption to learn what a dot means.

**A title that states the finding.** "Prix BTC/USDT — alertes superposées"
names the contents; the reader still has to work out what happened.

**Hover.** Every alert carries its timestamp, price, return and test
statistic in a native ``<title>`` plus an on-canvas bubble, so the detail
that would otherwise crowd the plot is one pointer away. The reveal is pure
CSS — ``#hit-n:hover ~ #tip-n`` — and so is the keyboard path, so the file
carries **no JavaScript whatsoever**: hover, focus and click-to-pin all work
with scripting disabled.

**Click.** A click on a mark focuses it, and `:focus` holds the bubble open
after the pointer leaves — so click pins, and clicking anywhere else
unpins. That matters twice over: it is the only way to read a value on a
touch screen, where there is no hover at all, and it lets two readings be
compared without a steady hand. The house fullscreen control is deliberately
*not* included: it registers a click handler on the whole ``<svg>`` root, so
every click meant for an alert toggled fullscreen instead, and focusing the
root drew a stray browser outline around the figure. Fullscreen belongs to
the page, where it can be a labelled button.

Author
------
`Warith Harchaoui, Ph.D. <https://www.linkedin.com/in/warith-harchaoui/>`_
"""

from __future__ import annotations

import csv
import math
from pathlib import Path
from typing import Any, Dict, List, Sequence, Tuple

import common as D  # constants, labels and the clock — no numpy
from sprezzature_svg import (
    BG,
    GRIDLINE,
    INK,
    SECONDARY,
    chrome_stack_for_theme,
    foreground_tip_css,
    load_palette,
    mono_stack_for_theme,
    nice_ticks_range,
    os_dark_style,
    svg_open,
    tooltip_bubble,
    xml_escape,
)

WIDTH: float = 1480.0
HEIGHT: float = 1080.0

PAD_L: float = 108.0
PAD_R: float = 48.0
PLOT_W: float = WIDTH - PAD_L - PAD_R

#: Panel A (price) and panel B (returns), as (top, height). The gap between
#: them is deliberately narrow: they are one figure read top to bottom, not
#: two charts that happen to be stacked.
A_TOP, A_H = 168.0, 336.0
B_TOP, B_H = 568.0, 236.0
AXIS_Y: float = B_TOP + B_H

#: Day labels every 24h, lighter marks at midday.

#: Chrome text in the two languages the catalogue's generators support. Only
#: chrome is translated: timestamps, prices and statistics render from the
#: data exactly as it arrives, the same rule every ``make_<id>.py`` follows.
_STRINGS: Dict[str, Dict[str, str]] = {
    "en": {
        "lang": "en",
        "title": "Fifteen minutes in three days did not behave like the rest",
        "subtitle": "BTC/USDT, {n} minute bars, 15-17 July 2026 · each return tested "
                    "against the volatility of the hour before it",
        "panel_a": "A · Close, BTC/USDT",
        "panel_b": "B · Log return, per minute",
        "panel_b_note": "The shaded band is the corrected alert threshold, rebuilt every minute "
                        "from the previous hour's volatility. A spike that leaves it is flagged.",
        "axis_note": "Bar-open timestamps, UTC · the close of each bar lands one minute later",
        "callout_1": "Biggest single minute of the window: {pct:+.2f}%",
        "callout_2": "{stat:.0f}× the volatility expected just before it",
        "key_confirmed": "{k} confirmed",
        "key_confirmed_note": "— clears the threshold after correcting for {s} segments",
        "key_exploratory": "{k} exploratory",
        "key_exploratory_note": "— clears 1% within its own day, not the correction",
        "events_head": "Scheduled releases in the window (shown for simultaneity, not attribution)",
        "tip_stat": "statistic",
        "confirmed": "confirmed",
        "exploratory": "exploratory only",
        "note_1": "Volatility window {w} observations, ending before the return under test, so a "
                  "jump cannot inflate the threshold that would catch it. The first {w} minutes "
                  "of each day are not testable and are drawn without a band.",
        "note_2": "Three complete days, no gaps and no interpolation. Synthetic data: the prices "
                  "are simulated and the releases invented, but the test is the real Lee-Mykland "
                  "statistic, so every mark above is one the detector actually raised.",
        "note_3": "A statistical alert is a minute that does not look like the minutes before it. "
                  "It is not a crisis, and coincidence with a release is not causation.",
        "desc": "Two stacked panels sharing one time axis over three days of BTC/USDT minute bars. "
                "The upper panel is the close price with {c} confirmed and {e} exploratory jump "
                "alerts marked on it; the lower panel shows each minute's log return as a spike "
                "against a shaded band, the alert threshold rebuilt every minute from the "
                "preceding hour of volatility. Three scheduled macro releases are marked as rails.",
    },
    "fr": {
        "lang": "fr",
        "title": "Quinze minutes sur trois jours ne ressemblent pas aux autres",
        "subtitle": "BTC/USDT, {n} barres minute, 15-17 juillet 2026 · chaque rendement "
                    "testé contre la volatilité de l'heure qui le précède",
        "panel_a": "A · Clôture, BTC/USDT",
        "panel_b": "B · Rendement logarithmique, par minute",
        "panel_b_note": "La bande colorée est le seuil d'alerte corrigé, recalculé "
                        "chaque minute sur la volatilité de l'heure précédente. "
                        "Un pic qui en sort est signalé.",
        "axis_note": "Horodatage d'ouverture de barre, UTC · la clôture arrive une "
                     "minute plus tard",
        "callout_1": "Plus forte minute de la fenêtre : {pct:+.2f} %",
        "callout_2": "{stat:.0f}× la volatilité attendue juste avant",
        "key_confirmed": "{k} confirmées",
        "key_confirmed_note": "— franchit le seuil après correction sur {s} segments",
        "key_exploratory": "{k} exploratoires",
        "key_exploratory_note": "— franchit 1 % dans sa journée, pas la correction",
        "events_head": "Publications programmées dans la fenêtre (simultanéité "
                       "descriptive, sans attribution causale)",
        "tip_stat": "statistique",
        "confirmed": "confirmée",
        "exploratory": "exploratoire seulement",
        "note_1": "Fenêtre de volatilité {w} observations, close avant le rendement "
                  "testé : un saut ne peut pas gonfler le seuil qui devrait l'attraper. Les "
                  "{w} premières minutes de chaque journée ne sont pas testables et sont "
                  "tracées sans bande.",
        "note_2": "Trois journées complètes, sans lacune ni interpolation. "
                  "Données synthétiques : les prix sont simulés et les publications "
                  "inventées, mais le test est la vraie statistique de Lee-Mykland — "
                  "chaque marque ci-dessus est une alerte réellement levée.",
        "note_3": "Une alerte statistique est une minute qui ne ressemble pas à celles qui la "
                  "précèdent. Ce n'est pas une crise, et une coïncidence avec une "
                  "publication n'est pas une cause.",
        "desc": "Deux panneaux superposés partageant un axe de temps unique sur trois jours de "
                "barres minute BTC/USDT. Le panneau supérieur montre le prix de clôture "
                "avec {c} alertes de saut confirmées et {e} exploratoires ; le panneau "
                "inférieur montre le rendement de chaque minute en pic contre une bande, le "
                "seuil d'alerte recalculé chaque minute. Trois publications macro sont "
                "marquées par des rails verticaux.",
    },
}


def _group(value: int, language: str) -> str:
    """Thousands separator: a comma in English, a narrow no-break space in French."""
    return f"{value:,}".replace(",", "\u202f") if language == "fr" else f"{value:,}"


def _t(language: str) -> Dict[str, str]:
    """Chrome-text dict for `language`, falling back to English."""
    return _STRINGS.get(language, _STRINGS["en"])



def load_csv(path: Path) -> Dict[str, Any]:
    """
    Read ``jumpscan.csv`` back into the arrays the panels draw.

    The figure does no statistics of its own: every number it plots, and the
    verdict on every minute, comes from the file. Swap the CSV for a real
    feed with the same columns and the chart redraws unchanged.

    Parameters
    ----------
    path : Path
        The CSV written by ``make_data.py``.

    Returns
    -------
    dict
        ``price`` / ``ret_pct`` / ``band_pct`` / ``statistic`` as float
        arrays (``nan`` where a cell is blank, which is how the file marks
        the untestable first window of each segment), plus ``alerts``, one
        dict per flagged minute.
    """
    minutes: List[int] = []
    price: List[float] = []
    ret: List[float] = []
    band: List[float] = []
    stat: List[float] = []
    alerts: List[Dict[str, Any]] = []

    with path.open(newline="", encoding="utf-8") as fh:
        for row in csv.DictReader(fh):
            i = int(row["minute"])
            minutes.append(i)
            price.append(float(row["price"]))
            ret.append(float(row["ret_pct"]))
            band.append(float(row["band_pct"]) if row["band_pct"] else float("nan"))
            stat.append(float(row["statistic"]) if row["statistic"] else float("nan"))
            if row["alert"]:
                alerts.append(
                    {
                        "minute": i,
                        "kind": row["alert"],
                        "price": float(row["price"]),
                        "ret_pct": float(row["ret_pct"]),
                        "stat": float(row["statistic"]),
                    }
                )
    return {
        "price": price,
        "ret_pct": ret,
        "band_pct": band,
        "stat": stat,
        "alerts": alerts,
        "n": len(minutes),
    }


def load_events(path: Path) -> List[Dict[str, Any]]:
    """Read ``events.csv``: the scheduled releases drawn as vertical rails."""
    with path.open(newline="", encoding="utf-8") as fh:
        return [
            {"id": r["id"], "minute": int(r["minute"]), "en": r["label_en"], "fr": r["label_fr"]}
            for r in csv.DictReader(fh)
        ]


#: Height of a three-line bubble, and the gap left between it and its mark.
#: Estimated rather than measured: `tooltip_bubble` computes the real box
#: from its own wrapped lines and does not report it back, and the three
#: lines here are short and fixed, so the estimate is stable. The helper
#: clamps to the canvas either way, so an error shows as a slightly wide gap
#: rather than a bubble off the edge.
TIP_H: float = 74.0
CLEARANCE: float = 15.0

#: Number of minutes the x-axis spans. Set from the CSV at build time rather
#: than hard-coded, so a longer or shorter file rescales the axis instead of
#: quietly drawing off the end of the panel.
_SPAN: float = 1.0


def _x(minute: float) -> float:
    """Horizontal position of a minute index, on the shared time axis."""
    return PAD_L + PLOT_W * (minute / _SPAN)


def _path(points: Sequence[Tuple[float, float]]) -> str:
    """A polyline as compact SVG path data."""
    head = f"M{points[0][0]:.1f},{points[0][1]:.1f}"
    return head + "".join(f"L{x:.1f},{y:.1f}" for x, y in points[1:])


def _price_panel(
    data: Dict[str, Any],
    palette: Dict[str, str],
    chrome: str,
    mono: str,
    s: Dict[str, str],
) -> Tuple[str, Any]:
    """Panel A: the price path, with the alerts sitting on it."""
    price = data["price"]
    lo, hi = min(price), max(price)
    pad = (hi - lo) * 0.04
    ticks = nice_ticks_range(lo - pad, hi + pad, 5)
    y_lo, y_hi = ticks[0], ticks[-1]

    def py(v: float) -> float:
        return A_TOP + A_H * (1.0 - (v - y_lo) / (y_hi - y_lo))

    out: List[str] = []

    for t in ticks:
        y = py(t)
        out.append(
            f'<line x1="{PAD_L:.1f}" y1="{y:.1f}" x2="{PAD_L + PLOT_W:.1f}" y2="{y:.1f}" '
            f'stroke="{GRIDLINE}" stroke-width="1"/>'
        )
        out.append(
            f'<text x="{PAD_L - 14:.1f}" y="{y + 4:.1f}" text-anchor="end" '
            f'font-family="{mono}" font-size="12.5" fill="{SECONDARY}">'
            f'{_group(round(t), s["lang"])}</text>'
        )

    # The path is drawn from every minute: 4 320 points is a few kilobytes as
    # one `d` attribute, and downsampling a price series is how a chart
    # quietly loses the spikes it exists to show.
    pts = [(_x(i), py(v)) for i, v in enumerate(price)]
    out.append(
        f'<path d="{_path(pts)}" fill="none" stroke="{palette["Blue"]}" '
        f'stroke-width="1.35" stroke-linejoin="round" opacity="0.92"/>'
    )

    out.append(
        f'<text x="{PAD_L:.1f}" y="{A_TOP - 22:.1f}" font-family="{chrome}" '
        f'font-size="15" font-weight="600" fill="{INK}">{s["panel_a"]}</text>'
    )
    return "".join(out), py


def _returns_panel(
    data: Dict[str, Any],
    palette: Dict[str, str],
    chrome: str,
    mono: str,
    s: Dict[str, str],
) -> Tuple[str, Any]:
    """Panel B: minute returns as stems, inside the volatility ribbon."""
    ret = data["ret_pct"]
    band = data["band_pct"]
    finite = [abs(v) for v in ret] + [abs(v) for v in band if not math.isnan(v)]
    span = max(finite) * 1.08

    def ry(v: float) -> float:
        return B_TOP + B_H * (0.5 - 0.5 * (v / span))

    out: List[str] = []

    # Order matters top to bottom: rules, then ribbon, then stems, then marks.
    # The ribbon over the rules keeps the gridlines from cutting through it.
    for t in (-0.3, -0.15, 0.15, 0.3):
        if abs(t) > span:
            continue
        y = ry(t)
        out.append(
            f'<line x1="{PAD_L:.1f}" y1="{y:.1f}" x2="{PAD_L + PLOT_W:.1f}" y2="{y:.1f}" '
            f'stroke="{GRIDLINE}" stroke-width="1" opacity="0.7"/>'
        )
        out.append(
            f'<text x="{PAD_L - 14:.1f}" y="{y + 4:.1f}" text-anchor="end" '
            f'font-family="{mono}" font-size="12" fill="{SECONDARY}">{t:+.2f}</text>'
        )

    step = 4
    idx = [i for i in range(0, len(ret), step) if not math.isnan(band[i])]
    if idx:
        upper = [(_x(i), ry(band[i])) for i in idx]
        lower = [(_x(i), ry(-band[i])) for i in reversed(idx)]
        out.append(
            f'<path d="{_path(upper + lower)}Z" fill="{palette["Blue"]}" fill-opacity="0.10" '
            f'stroke="none"/>'
        )
        out.append(
            f'<path d="{_path(upper)}" fill="none" stroke="{palette["Blue"]}" '
            f'stroke-width="1" opacity="0.45"/>'
        )
        out.append(
            f'<path d="{_path(lower)}" fill="none" stroke="{palette["Blue"]}" '
            f'stroke-width="1" opacity="0.45"/>'
        )

    zero = ry(0.0)
    # Stems as one path: 4 320 separate <line> elements would quadruple the
    # file for pixels a reader cannot tell apart.
    stems = "".join(f"M{_x(i):.1f},{zero:.1f}L{_x(i):.1f},{ry(v):.1f}" for i, v in enumerate(ret))
    out.append(f'<path d="{stems}" stroke="{SECONDARY}" stroke-width="0.8" opacity="0.55" fill="none"/>')
    out.append(
        f'<line x1="{PAD_L:.1f}" y1="{zero:.1f}" x2="{PAD_L + PLOT_W:.1f}" y2="{zero:.1f}" '
        f'stroke="{SECONDARY}" stroke-width="1"/>'
    )

    out.append(
        f'<text x="{PAD_L:.1f}" y="{B_TOP - 46:.1f}" font-family="{chrome}" '
        f'font-size="15" font-weight="600" fill="{INK}">{s["panel_b"]}</text>'
    )
    out.append(
        f'<text x="{PAD_L:.1f}" y="{B_TOP - 26:.1f}" font-family="{chrome}" '
        f'font-size="12.5" fill="{SECONDARY}">{s["panel_b_note"]}</text>'
    )
    return "".join(out), ry


def build_svg(theme: str = "corporate", language: str = "en") -> str:
    """
    Assemble the whole figure.

    Parameters
    ----------
    theme : str, optional
        ``"corporate"`` (Roboto) or ``"academic"`` (Latin Modern).

    Returns
    -------
    str
        A complete, self-contained SVG document.
    """
    palette = load_palette(theme=theme)
    chrome = chrome_stack_for_theme(theme)
    mono = mono_stack_for_theme(theme)
    s = _t(language)

    here = Path(__file__).resolve().parent
    data = load_csv(here / "jumpscan.csv")
    events = load_events(here / "events.csv")
    rows = data["alerts"]

    global _SPAN
    _SPAN = float(data["n"])

    confirmed = [r for r in rows if r["kind"] == "confirmed"]
    exploratory = [r for r in rows if r["kind"] == "exploratory"]
    strongest = max(rows, key=lambda r: abs(r["stat"]))

    body: List[str] = []
    price_svg, py = _price_panel(data, palette, chrome, mono, s)
    ret_svg, ry = _returns_panel(data, palette, chrome, mono, s)

    # ── event rails, behind everything ────────────────────────────────────
    rails: List[str] = []
    for ev in events:
        x = _x(ev["minute"])
        rails.append(
            f'<line x1="{x:.1f}" y1="{A_TOP - 8:.1f}" x2="{x:.1f}" y2="{AXIS_Y:.1f}" '
            f'stroke="{palette["Purple"]}" stroke-width="1" stroke-dasharray="3 4" opacity="0.55"/>'
        )
        rails.append(
            f'<rect x="{x - 20:.1f}" y="{A_TOP - 26:.1f}" width="40" height="17" rx="5" '
            f'fill="{BG}" stroke="{palette["Purple"]}" stroke-width="1" opacity="0.9"/>'
        )
        rails.append(
            f'<text x="{x:.1f}" y="{A_TOP - 14:.1f}" text-anchor="middle" font-family="{mono}" '
            f'font-size="10.5" fill="{palette["Purple"]}">{ev["id"]}</text>'
        )
    body.append("".join(rails))

    # ── day boundaries ────────────────────────────────────────────────────
    for d in range(1, D.N_DAYS):
        x = _x(d * D.MINUTES_PER_DAY)
        body.append(
            f'<line x1="{x:.1f}" y1="{A_TOP:.1f}" x2="{x:.1f}" y2="{AXIS_Y:.1f}" '
            f'stroke="{GRIDLINE}" stroke-width="1"/>'
        )

    body.append(price_svg)
    body.append(ret_svg)

    # ── shared time axis ──────────────────────────────────────────────────
    body.append(
        f'<line x1="{PAD_L:.1f}" y1="{AXIS_Y:.1f}" x2="{PAD_L + PLOT_W:.1f}" y2="{AXIS_Y:.1f}" '
        f'stroke="{SECONDARY}" stroke-width="1"/>'
    )
    names = D.DAY_NAMES.get(language, D.DAY_NAMES["en"])
    for d, name in enumerate(names):
        x = _x(d * D.MINUTES_PER_DAY)
        anchor = "start" if d == 0 else ("end" if d == len(names) - 1 else "middle")
        body.append(
            f'<text x="{x:.1f}" y="{AXIS_Y + 22:.1f}" text-anchor="{anchor}" font-family="{chrome}" '
            f'font-size="12.5" font-weight="500" fill="{INK}">{name}</text>'
        )
    for d in range(D.N_DAYS):
        x = _x(d * D.MINUTES_PER_DAY + D.MINUTES_PER_DAY // 2)
        body.append(
            f'<text x="{x:.1f}" y="{AXIS_Y + 22:.1f}" text-anchor="middle" font-family="{mono}" '
            f'font-size="11.5" fill="{SECONDARY}">12:00</text>'
        )
    body.append(
        f'<text x="{PAD_L + PLOT_W / 2:.1f}" y="{AXIS_Y + 44:.1f}" text-anchor="middle" '
        f'font-family="{chrome}" font-size="12" fill="{SECONDARY}">{s["axis_note"]}</text>'
    )

    # ── alert marks, both panels, each independently interactive ─────────
    # One hit target *per drawn mark*, not one per alert. The first pass put
    # the only target on the price panel, so pointing at a spike in the
    # returns panel — the panel that shows *why* the minute was flagged —
    # did nothing at all. Two marks, two targets, two bubbles, each opening
    # beside the mark the reader is actually pointing at.
    marks: List[str] = []
    tips: List[str] = []
    slot = 0
    for r in rows:
        x = _x(r["minute"])
        fill = palette["Red"] if r["kind"] == "confirmed" else "none"
        stroke_w = 1.4 if r["kind"] == "confirmed" else 1.8
        label = s["confirmed"] if r["kind"] == "confirmed" else s["exploratory"]
        lines = [
            D.clock(r["minute"], language),
            f"{_group(round(r['price']), language)} USDT   {r['ret_pct']:+.3f}%",
            f"{s['tip_stat']} {abs(r['stat']):.1f}   {label}",
        ]
        reading = (
            f"{xml_escape(D.clock(r['minute'], language))} &#183; "
            f"{_group(round(r['price']), language)} USDT &#183; {r['ret_pct']:+.3f}% &#183; "
            f"{s['tip_stat']} {abs(r['stat']):.1f} ({label})"
        )

        for cy in (py(r["price"]), ry(r["ret_pct"])):
            marks.append(
                f'<circle cx="{x:.1f}" cy="{cy:.1f}" r="5" fill="{fill}" '
                f'stroke="{palette["Red"]}" stroke-width="{stroke_w}" '
                f'paint-order="stroke" stroke-linejoin="round"/>'
            )
            if r["kind"] == "confirmed":
                marks.append(
                    f'<circle cx="{x:.1f}" cy="{cy:.1f}" r="5" fill="none" stroke="{BG}" '
                    f'stroke-width="1.1" opacity="0.9"/>'
                )
            # The focus ring is drawn by the figure rather than left to the
            # browser: a UA outline on an SVG shape is a hard rectangle that
            # ignores the circle underneath it.
            # role + aria-label so a screen reader announces the reading; the
            # <title> covers the pointer tooltip. The ring follows the hit in
            # document order, because `~` only reaches later siblings.
            marks.append(
                f'<circle id="hit-{slot}" class="hit" tabindex="0" role="img" '
                f'aria-label="{reading}" cx="{x:.1f}" cy="{cy:.1f}" r="13" fill="transparent">'
                f"<title>{reading}</title></circle>"
                f'<circle id="ring-{slot}" class="ring" cx="{x:.1f}" cy="{cy:.1f}" r="10" '
                f'fill="none" stroke="{palette["Blue"]}" stroke-width="2"/>'
            )
            # Flip toward the middle of whichever panel the mark sits in.
            # Clamping to the canvas is not enough: a bubble on a low mark in
            # panel B stayed on canvas and still covered the shared time axis
            # and its labels.
            panel_mid = A_TOP + A_H / 2 if cy < B_TOP - 40 else B_TOP + B_H / 2
            above = cy > panel_mid
            # `y` is the bubble's *top* edge, not its centre — so "above"
            # meant nothing until the box height was subtracted, and every
            # bubble sat squarely on the mark it described, hiding both the
            # mark and its focus ring.
            top = cy - CLEARANCE - TIP_H if above else cy + CLEARANCE
            tips.append(
                tooltip_bubble(
                    x,
                    top,
                    lines,
                    canvas_w=WIDTH,
                    canvas_h=HEIGHT,
                    font_family=chrome,
                    elem_id=f"tip-{slot}",
                )
            )
            slot += 1
    body.append("".join(marks))

    # ── the one direct label the figure needs ─────────────────────────────
    # Placed above the *local maximum of the price line across the label's own
    # width*, not at a fixed offset from the marked point. A fixed offset is
    # what put this text straight through the line on the first eyeball pass:
    # the anchor point is a one-minute spike, and the line either side of it is
    # higher than the spike itself.
    sx, sy = _x(strongest["minute"]), py(strongest["price"])
    side = -1 if sx > PAD_L + PLOT_W * 0.55 else 1
    label_w = 330.0
    lo_x, hi_x = (sx, sx + label_w) if side > 0 else (sx - label_w, sx)
    lo_m = max(0, int((lo_x - PAD_L) / PLOT_W * _SPAN))
    hi_m = min(len(data["price"]) - 1, int((hi_x - PAD_L) / PLOT_W * _SPAN))
    crest = min(py(v) for v in data["price"][lo_m : hi_m + 1])
    text_y = min(sy, crest) - 26.0

    tx = sx + side * 16
    body.append(
        f'<line x1="{sx + side * 7:.1f}" y1="{sy - 4:.1f}" x2="{tx:.1f}" y2="{text_y + 10:.1f}" '
        f'stroke="{SECONDARY}" stroke-width="1"/>'
    )
    anchor = "end" if side < 0 else "start"
    body.append(
        f'<text x="{tx + side * 4:.1f}" y="{text_y:.1f}" text-anchor="{anchor}" '
        f'font-family="{chrome}" font-size="12.5" font-weight="600" fill="{INK}">'
        + s["callout_1"].format(pct=strongest["ret_pct"]) + "</text>"
    )
    body.append(
        f'<text x="{tx + side * 4:.1f}" y="{text_y + 16:.1f}" text-anchor="{anchor}" '
        f'font-family="{chrome}" font-size="12" fill="{SECONDARY}">'
        + s["callout_2"].format(stat=abs(strongest["stat"])) + "</text>"
    )

    # ── key, on the figure ────────────────────────────────────────────────
    key_y = AXIS_Y + 76
    body.append(
        f'<circle cx="{PAD_L + 7:.1f}" cy="{key_y - 4:.1f}" r="5" fill="{palette["Red"]}" '
        f'stroke="{BG}" stroke-width="1.1"/>'
    )
    body.append(
        f'<text x="{PAD_L + 20:.1f}" y="{key_y:.1f}" font-family="{chrome}" font-size="12.5" '
        f'fill="{INK}">' + s["key_confirmed"].format(k=len(confirmed)) + "</text>"
    )
    body.append(
        f'<text x="{PAD_L + 118:.1f}" y="{key_y:.1f}" font-family="{chrome}" font-size="12.5" '
        f'fill="{SECONDARY}">' + s["key_confirmed_note"].format(s=D.N_SEGMENTS) + "</text>"
    )
    body.append(
        f'<circle cx="{PAD_L + 7:.1f}" cy="{key_y + 20:.1f}" r="5" fill="none" '
        f'stroke="{palette["Red"]}" stroke-width="1.8"/>'
    )
    body.append(
        f'<text x="{PAD_L + 20:.1f}" y="{key_y + 24:.1f}" font-family="{chrome}" font-size="12.5" '
        f'fill="{INK}">' + s["key_exploratory"].format(k=len(exploratory)) + "</text>"
    )
    body.append(
        f'<text x="{PAD_L + 118:.1f}" y="{key_y + 24:.1f}" font-family="{chrome}" font-size="12.5" '
        f'fill="{SECONDARY}">' + s["key_exploratory_note"] + "</text>"
    )

    # ── footnote ──────────────────────────────────────────────────────────
    foot_y = key_y + 58
    notes = (
        s["note_1"].format(w=D.VOL_WINDOW),
        s["note_2"],
        s["note_3"],
    )
    for i, line in enumerate(notes):
        body.append(
            f'<text x="{PAD_L:.1f}" y="{foot_y + i * 17:.1f}" font-family="{chrome}" font-size="11.5" '
            f'fill="{SECONDARY}">{line}</text>'
        )

    # ── events, named ─────────────────────────────────────────────────────
    ev_y = foot_y + 3 * 17 + 16
    body.append(
        f'<text x="{PAD_L:.1f}" y="{ev_y:.1f}" font-family="{chrome}" font-size="11.5" '
        f'font-weight="600" fill="{palette["Purple"]}">{s["events_head"]}</text>'
    )
    for i, ev in enumerate(events):
        col = PAD_L + (i % 3) * (PLOT_W / 3.0)
        body.append(
            f'<text x="{col:.1f}" y="{ev_y + 19:.1f}" font-family="{chrome}" font-size="11.5" '
            f'fill="{SECONDARY}">{ev["id"]} &#183; {D.clock(ev["minute"], language).rsplit(" ", 1)[0]} &#183; '
            f'{xml_escape(ev.get(language, ev["en"]))}</text>'
        )

    # ── header ────────────────────────────────────────────────────────────
    head = [
        f'<text x="{PAD_L:.1f}" y="62" font-family="{chrome}" font-size="25" font-weight="700" '
        f'fill="{INK}">{s["title"]}</text>',
        f'<text x="{PAD_L:.1f}" y="88" font-family="{chrome}" font-size="14" fill="{SECONDARY}">'
        + s["subtitle"].format(n=_group(data['n'], language))
        + "</text>",
    ]

    css = (
        # `outline:none` on its own is a WCAG 2.4.7 failure: it removes the
        # only thing telling a keyboard user where they are. The UA outline is
        # suppressed here *because the figure draws its own* ring (.ring),
        # which follows the circular mark instead of boxing it.
        ".hit{cursor:pointer;outline:none}"
        # No class-based `.hit:focus-visible~.ring` rule here, tempting as it
        # looks: `~` is the *general* sibling combinator, so focusing one mark
        # lit up every ring after it in the document. Only the id-paired rules
        # below are correct.
        ".ring{opacity:0;pointer-events:none;transition:opacity .12s ease}"
        ".tip{opacity:0;pointer-events:none;transition:opacity .12s ease}"
        + foreground_tip_css(slot)
        + "".join(
            f"#hit-{i}:focus-visible~#ring-{i},#hit-{i}:hover~#ring-{i}{{opacity:1}}"
            for i in range(slot)
        )
        + "@media (prefers-reduced-motion: reduce){.tip,.ring{transition:none}}"
        + os_dark_style()
    )

    svg = [
        svg_open(WIDTH, HEIGHT, "jumpscan-title", "jumpscan-desc", font_family=chrome),
        f'<title id="jumpscan-title">{s["title"]}</title>',
        '<desc id="jumpscan-desc">'
        + s["desc"].format(c=len(confirmed), e=len(exploratory))
        + "</desc>",
        f"<style>{css}</style>",
        f'<rect width="{WIDTH}" height="{HEIGHT}" fill="{BG}"/>',
        "".join(head),
        "".join(body),
        "".join(tips),
        "</svg>",
    ]
    return "".join(svg)


def main() -> None:
    """Write the figure beside this script.

    French only: the chart this answers is French, and so is the note
    written for its reader. The English strings stay in ``_STRINGS`` —
    ``build_svg(language="en")`` still works — because keeping the table
    bilingual is what stops hard-coded chrome text creeping back in.
    """
    here = Path(__file__).resolve().parent
    out = here / "jumpscan.svg"
    out.write_text(build_svg(language="fr"), encoding="utf-8")
    print(f"wrote {out}  ({out.stat().st_size / 1024:.0f} KB)")


if __name__ == "__main__":
    main()
