# Ralph Eyeball Loop — `jumpscan.svg`

| Champ | Valeur |
|---|---|
| **Source** | `make_jumpscan.py` → `jumpscan.svg` / `jumpscan.fr.svg` |
| **Nature** | SVG écrit directement |
| **Mode** | agent (l'agent lit le PNG) |
| **Itérations** | 6 |
| **Verdict** | ✅ livrable |

La boucle : **produire → regarder → écrire la critique → corriger la source →
relancer**, jusqu'à ce que la case Verdict soit cochée.

*Ce qu'on corrige, c'est toujours la source. Jamais le PNG.*

---

## Itération 1 — trois défauts, dont un fatal

### Critique

**Mise en page — fatal.** Les quinze infobulles s'affichaient **toutes en même
temps** et recouvraient la quasi-totalité du panneau A. La courbe de prix — le
sujet de la figure — n'était plus qu'une poignée de fragments bleus entre des
rectangles blancs. Un lecteur n'aurait vu aucun graphique.

Cause racine, trouvée en lisant le contrat du helper plutôt qu'en devinant :
`_svg.foreground_tip_css` n'émet **que** les règles de *révélation*, indexées
sur des **id** (`#hit-0:hover ~ #tip-0`). La règle de base `.tip{opacity:0}`
est explicitement à la charge de l'appelant, et je ne l'avais pas écrite. Par
dessus, j'utilisais des classes (`class="tip tip0"`) là où le helper attend des
id, et j'avais emballé la cible dans un `<g>`, ce qui casse le combinateur de
frères dont la règle dépend.

Trois erreurs empilées, et **aucune n'est visible dans la source** : le SVG est
valide, le générateur sort en 0, rien n'avertit.

**Occupation de l'espace.** L'axe des prix était marginé de 10 % de l'amplitude
puis arrondi vers l'extérieur : les graduations allaient de 64 000 à 69 000 pour
des données vivant entre 64 792 et 67 743. Un tiers du panneau était vide.

**Signatures malhonnêtes.** Les deux constructeurs de panneaux étaient annotés
`-> str` alors qu'ils renvoyaient `(markup, fonction_d_échelle)`.

### Corrections

- `.tip{opacity:0;pointer-events:none;transition:opacity .12s ease}` ajouté,
  plus la clause `prefers-reduced-motion`, comme dans `make_scatter.py`.
- Cibles émises en `<circle id="hit-N" class="hit" tabindex="0">` à la racine,
  bulles en `elem_id="tip-N"`, pour qu'elles soient bien frères.
- Marge d'axe 10 % → 4 %.
- Signatures corrigées en `Tuple[str, Any]`.

---

## Itération 2 — une collision, un repère manquant

### Critique

**Mise en page.** L'annotation « plus forte minute » était tracée **à travers la
courbe de prix**. Elle était placée à un décalage fixe au-dessus du point
marqué — or ce point est un pic d'une minute, et la courbe de part et d'autre
est *plus haute que le pic lui-même*. Un décalage fixe atterrit donc dans les
données.

C'est typiquement le défaut qui n'existe que dans le rendu : les nombres sont
exacts, le texte est là où le code dit qu'il doit être, et c'est illisible.

**Axes.** Les graduations ±0,15 / ±0,30 du panneau B flottaient sans aucune
ligne à quoi se raccrocher : impossible de juger la hauteur d'un pic.

### Corrections

- L'annotation mesure désormais le **maximum local de la courbe sur sa propre
  largeur de texte** et se place au-dessus, au lieu de se décaler du point
  d'ancrage. Une ligne de rappel conserve le lien avec la minute marquée.
- Reformulé « Plus forte de la fenêtre » → « Plus forte minute de la fenêtre » :
  le premier est ambigu sur *le plus fort quoi*, sur un graphique qui montre
  aussi un mouvement de plusieurs heures bien plus ample.
- Lignes de graduation ajoutées au panneau B, tracées **sous** la bande pour
  qu'elles se lisent comme du chrome et ne la coupent pas.

---

## Itération 3 — vérifications

### Critique

**Mise en page.** L'annotation dégage la courbe avec de la marge. Les rails
traversent les deux panneaux et se posent sur l'axe partagé. Plus aucun
recouvrement.

**Contraste et couleur** — contrôlés par simulation, pas à l'œil :

- *Niveaux de gris* : la distinction confirmée / exploratoire survit
  intégralement, parce qu'elle est portée par la **forme** (disque plein contre
  anneau creux) et non par la teinte. Le couple disque rouge / cercle ocre du
  graphique d'origine, lui, est composé de deux teintes chaudes que le gris
  fusionne.
- *Deutéranopie (Machado)* : les marques rouges restent séparées du tracé bleu.
  Rouge/bleu est un couple sûr, contrairement à rouge/vert.

**Honnêteté des données.** La figure annonce 13 alertes confirmées et 2
exploratoires sur 16 sauts injectés. Un saut injecté n'est **pas** retrouvé, et
la note de bas de page dit que les données sont synthétiques tandis que la
statistique est réelle. Une démo qui retrouverait les 16 serait de la publicité.

**Auditeur statique.** `audit_figure.py` : aucune remarque.

---

## Itération 4 — la passe française, et un double échappement

### Critique

Ajouter une variante française — le graphique auquel cette figure répond est en
français, et la note rédigée pour le lecteur aussi — a fait apparaître un défaut
invisible en anglais : l'infobulle affichait **`statistique 10.0 confirm&#233;e`**,
l'entité imprimée telle quelle.

Cause : j'avais écrit la table de chaînes avec des entités numériques. Une valeur
injectée directement dans le balisage passe très bien ainsi, mais une valeur qui
traverse `tooltip_bubble` est ré-échappée en XML, transformant `&#233;` en
`&amp;#233;`. Toute la table est passée en UTF-8 réel, qui n'a pas ce mode de
défaillance : échapper un « é » véritable est sans effet, et le fichier est écrit
en UTF-8 de toute façon.

Trois broutilles attrapées dans la même passe, chacune une habitude anglaise
survivant en français : `4,320` et `65,456` (le français groupe avec une espace
fine insécable), le mot `statistic` codé en dur dans le constructeur d'infobulle
au lieu d'être tiré de la table, et les trois libellés d'événements non traduits.

---

## Itération 5 — le clic, et trois défauts que seul un vrai pointeur trouve

Déclenchée par la consigne « réparer le survol et le clic ». Plutôt que de
raisonner sur le balisage, les interactions ont été pilotées en CDP avec de
véritables `Input.dispatchMouseEvent` / `dispatchKeyEvent` : `:hover` et
`:focus` ne se posent pas depuis un script, donc toute autre méthode aurait testé
mes suppositions au lieu du fichier.

### Critique

**Toute la figure était un gros bouton plein écran.** `fullscreen_control` pose
un gestionnaire de clic sur la racine `<svg>` et lui met `tabindex="0"`. Un clic
destiné à épingler la valeur d'une alerte basculait donc en plein écran, et le
focus qui s'ensuivait dessinait le liseré par défaut du navigateur autour de la
figure entière — un rectangle bleu arrondi juste à l'intérieur du cadre.

Retiré de la figure ; le plein écran est désormais un bouton étiqueté dans la
page, où il est repérable et n'entre plus en collision avec les données.

**Le panneau des rendements n'avait aucune cible.** Quinze alertes y étaient
*dessinées* et aucune ne répondait : la boucle émettait une marque par panneau
mais une seule cible par alerte, sur le panneau des prix. Pointer le pic qui
*explique* l'alerte ne faisait rien. Chaque marque dessinée porte maintenant sa
propre cible et sa propre bulle, qui s'ouvre à côté de la marque réellement sous
le pointeur.

**`.hit:focus-visible ~ .ring` allumait tous les anneaux suivants.** `~` est le
combinateur de frères *généraux*, pas l'adjacent : focaliser la cinquième marque
surlignait les marques cinq à trente. Seules les règles appariées par id sont
correctes — exactement la forme que `foreground_tip_css` emploie déjà, pour la
même raison.

**Les bulles recouvraient la marque qu'elles décrivaient.** Le `y` de
`tooltip_bubble` est le bord **haut** de la boîte : `cy - 18` posait donc la
bulle en plein sur sa propre marque et sur son anneau de focus. Le placement
soustrait maintenant la hauteur de la boîte et bascule vers le milieu du panneau
concerné, de sorte qu'une marque basse du panneau B ne jette plus sa bulle en
travers de l'axe de temps partagé.

**`outline:none` sans rien à la place** était une infraction WCAG 2.4.7. La
figure dessine désormais son propre anneau, qui suit la marque circulaire au lieu
de l'encadrer comme le fait un liseré de navigateur.

### Ce qui marche, vérifié et non supposé

| Interaction | Résultat |
|---|---|
| Survol, les deux panneaux | opacité 0 → 1 → 0 |
| Clic | focalise la marque, la bulle reste après le départ du pointeur — seul moyen de lire une valeur sur écran tactile |
| Tabulation | atteint les 30 marques, affiche sa bulle et exactement un anneau |
| Échap / clic ailleurs | dépingle |
| JavaScript désactivé | tout ce qui précède fonctionne encore : le SVG n'en contient pas une ligne |

---

## Itération 6 — rendre l'envoi possible

### Critique

Question posée : *« est-ce que je peux zipper `g` et l'envoyer ? »* La réponse
était **non**, et la vérification l'a montré : `make_jumpscan.py` faisait
`sys.path.insert(0, Path.home() / "sprezzature-figures" / "scripts")` puis
importait `_svg`, `_style`, `_scale`. Chez un destinataire qui n'a pas ce dépôt,
le script s'arrête à l'import. Le zip aurait contenu une figure superbe et un
générateur incapable de tourner.

Second défaut découvert en testant dans un environnement nu (`env -i`, sans
`PYTHONPATH`) : `make_jumpscan.py` importait `make_data`, qui importe numpy au
niveau module. La séparation « calcul ↔ dessin » annoncée dans la documentation
était donc fausse — dessiner exigeait numpy.

### Corrections

- Moteur de dessin empaqueté en un seul `sprezzature_svg.py` (115 Ko, 64
  fonctions), avec le bundler qui sert déjà aux kits de la galerie du site.
- Constantes partagées extraites dans `common.py`, sans aucune dépendance. La
  répartition est maintenant réelle : `make_data.py` calcule et demande numpy,
  `make_jumpscan.py` dessine et n'exige que la bibliothèque standard.
- Vérifié en relançant depuis `/tmp` avec `env -i PATH=/usr/bin:/bin`, sans
  numpy installé : les deux SVG se produisent.

---

## Verdict

- [x] **Livrable.**

Six itérations. **Quatre des défauts n'étaient visibles que dans le rendu ou à
l'exécution** — infobulles omniprésentes, annotation en travers de la courbe,
anneaux de focus multiples, clic détourné vers le plein écran — avec à chaque
fois un SVG valide, un code de sortie 0 et des chiffres exacts. Aucun test,
aucun linter, aucun schéma ne les attrape.

C'est tout l'argument de la boucle : il faut produire l'image, la regarder, et
appuyer réellement sur les choses.
