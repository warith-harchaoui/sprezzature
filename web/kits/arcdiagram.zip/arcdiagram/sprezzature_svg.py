"""
sprezzature_svg — the drawing engine behind this figure, in one file.

Scales and tick placement, SVG path builders, the house palette, the
label placer, the hover and fullscreen chrome, and the write-and-report
tail. Merged from the helper modules of sprezzature-figures so the kit
stays at two Python files; the sections below are in dependency order
and keep their original docstrings.

The one deliberate difference from the repo: typefaces are linked from
Google Fonts instead of embedded as base64, which takes a figure from
roughly 430 KB to roughly 20 KB. See GOOGLE_FONTS_IMPORT for what that
costs you.

Author
------
`Warith Harchaoui, Ph.D. <https://www.linkedin.com/in/warith-harchaoui/>`_
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import os
import sys
import textwrap
import warnings
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple
from typing import List as _List


# ──────────────────────────────────────────────────────────────────────────
# from _scale.py
# ──────────────────────────────────────────────────────────────────────────

import math


def log_position(v: float, lo: float, hi: float, p0: float, p1: float) -> float:
    """Map ``v`` from the log-domain ``[lo, hi]`` to the pixel range ``[p0, p1]``.

    Works for either axis direction: pass ``p0`` as the pixel position of
    ``lo`` and ``p1`` as the pixel position of ``hi`` — for a y-axis (pixels
    grow downward, values grow upward) that means ``p0`` is the *bottom* of
    the plot and ``p1`` is the *top*, which flips the sign naturally without
    a separate code path.

    Parameters
    ----------
    v : float
        The data value to place. Values below `lo` clamp to `lo` (matching
        an axis floor), rather than mapping to a negative-infinity pixel.
    lo, hi : float
        The log-domain bounds. Must both be positive; `hi` must be
        greater than `lo`.
    p0, p1 : float
        Pixel positions of `lo` and `hi` respectively.

    Returns
    -------
    float
        The pixel position, linear in log10(v).

    Examples
    --------
    >>> log_position(10, 1, 100, 0.0, 100.0)
    50.0
    >>> log_position(0.5, 1, 100, 0.0, 100.0)
    0.0
    """
    if lo <= 0 or hi <= lo:
        return p0
    v = max(v, lo)
    frac = (math.log10(v) - math.log10(lo)) / (math.log10(hi) - math.log10(lo))
    return p0 + frac * (p1 - p0)


def log_ticks(lo: float, hi: float) -> list[float]:
    """Decade tick values (``..., 1, 10, 100, ...``) spanning ``[lo, hi]``.

    Rounds outward to the nearest decade on both ends so the first and last
    tick always bracket the data (``floor(log10(lo))`` to ``ceil(log10(hi))``),
    which means the returned ticks can extend a little past `lo`/`hi` — filter
    the result against the plotted domain if a caller wants ticks strictly
    inside it (as the x-axis case does, since its domain floor is the
    smallest *positive* data value rather than a round decade).

    Parameters
    ----------
    lo, hi : float
        The data range to cover. Must both be positive; `hi` must be
        greater than or equal to `lo`.

    Returns
    -------
    list of float
        Ascending decade values, e.g. ``[1.0, 10.0, 100.0]``. Empty if
        `lo`/`hi` are not both positive or `hi` < `lo`.

    Examples
    --------
    >>> log_ticks(3, 420)
    [1.0, 10.0, 100.0, 1000.0]
    """
    if lo <= 0 or hi <= 0 or hi < lo:
        return []
    d = 10.0 ** math.floor(math.log10(lo))
    # The upper bound is rounded outward too, so the loop needs the same
    # tiny multiplicative slop as the boundary decade itself to include it
    # despite float rounding (e.g. log10(1000) landing at 2.9999999998).
    hi_bound = 10.0 ** math.ceil(math.log10(hi))
    ticks: list[float] = []
    while d <= hi_bound * 1.0000001:
        ticks.append(d)
        d *= 10
    return ticks


def _nice_num(value: float, round_up_only: bool) -> float:
    """Round `value` to the nearest 1/2/5-times-a-power-of-ten "nice" number.

    Shared step of the classic Heckbert (1990) "nice numbers for graph
    labels" algorithm, used twice by :func:`nice_ticks`: once to round the
    overall span *up* (``round_up_only=True`` is misleading naming avoided —
    see call sites) and once to round the per-tick step to the nearest of
    ``{1, 2, 5, 10}`` (``round_up_only=False``, i.e. round-to-nearest).
    """
    exponent = math.floor(math.log10(value))
    fraction = value / (10.0**exponent)
    if round_up_only:
        nice_fraction = 10.0 if fraction > 5 else 5.0 if fraction > 2 else 2.0 if fraction > 1 else 1.0
    else:
        nice_fraction = 1.0 if fraction < 1.5 else 2.0 if fraction < 3 else 5.0 if fraction < 7 else 10.0
    return nice_fraction * (10.0**exponent)


def nice_ticks(max_val: float, n: int = 4) -> list[float]:
    """Evenly-spaced "nice" tick values from ``0`` up to a rounded ceiling ``>= max_val``.

    Several linear-axis generators (bar, grouped-bar, stacked-area,
    column-range, ...) used to divide ``max_val`` into `n` raw equal steps
    (``max_val / n``), which lands the top gridline exactly on the data peak
    but produces label values like ``23``/``46``/``69``/``92`` —
    arithmetically even, but not numbers a reader can scan or do quick mental
    math with. This is the classic "nice numbers for graph labels" fix
    (Heckbert 1990, the "nice numbers" rule): round the
    overall span up to a nice ceiling, then pick a nice step near
    ``ceiling / n``, so ticks land on ``0``/``20``/``40``/``60``/``80``/
    ``100`` instead of ``0``/``23``/``46``/``69``/``92``. Because the step is
    rounded rather than forced, the returned list can have more or fewer than
    ``n + 1`` entries — the point is round numbers, not an exact count. The
    tradeoff is that the top tick (and therefore the axis ceiling a caller
    derives from ``ticks[-1]``) may now sit a little *above* ``max_val``
    rather than exactly on it — deliberate: it gives the tallest bar/area a
    sliver of headroom below the plot's top edge instead of touching it,
    which is the more common professional-chart convention anyway.

    Parameters
    ----------
    max_val : float
        The largest value the axis must cover. Non-positive input returns
        ``[0.0]`` (a degenerate single-tick axis) rather than raising.
    n : int, optional
        Target number of steps (actual count may differ slightly once the
        step is rounded to a nice number). Defaults to ``4``, matching every
        existing caller's previous ``max_val / 4.0``.

    Returns
    -------
    list of float
        Ascending ticks ``[0, step, 2*step, ...]`` with `step` a nice
        1/2/5-times-a-power-of-ten value. The last entry is always
        ``>= max_val`` (assuming `max_val` is positive).

    Examples
    --------
    >>> nice_ticks(92)
    [0.0, 20.0, 40.0, 60.0, 80.0, 100.0]
    >>> nice_ticks(0)
    [0.0]
    """
    if max_val <= 0:
        return [0.0]
    nice_range = _nice_num(max_val, True)
    step = _nice_num(nice_range / n, False)
    nice_max = math.ceil(max_val / step) * step
    count = int(round(nice_max / step))
    return [i * step for i in range(count + 1)]


def nice_ticks_range(lo: float, hi: float, n: int = 5) -> list[float]:
    """Nice tick values covering an arbitrary ``[lo, hi]`` span (not anchored at 0).

    :func:`nice_ticks` assumes a ``0``-anchored axis (bar/area charts). Axes
    whose floor isn't ``0`` (a beeswarm's value axis padded around
    ``[v_min, v_max]``, a column-range's padded ``[y_min, y_max]``) instead
    divided their *raw* span by a fixed tick count, which -- exactly like the
    ``0``-anchored case -- produces label values that are evenly spaced but
    not round (e.g. a beeswarm spanning 14.3..74.6 got ticks at 14/24/35/...
    instead of 10/20/30/...). This rounds both the step *and* the two bounds
    outward to the nearest nice multiple, the same Heckbert approach as
    :func:`nice_ticks` generalized to a non-zero floor.

    Parameters
    ----------
    lo, hi : float
        The span to cover (typically already includes the caller's own
        padding). `hi` must be greater than `lo`.
    n : int, optional
        Target number of steps; the actual count may differ once the step is
        rounded to a nice number. Defaults to ``5``.

    Returns
    -------
    list of float
        Ascending ticks whose first entry is ``<= lo`` and last is ``>= hi``.
        Empty if `hi` <= `lo`.

    Examples
    --------
    >>> nice_ticks_range(14.3, 74.6)
    [10.0, 20.0, 30.0, 40.0, 50.0, 60.0, 70.0, 80.0]
    """
    if hi <= lo:
        return []
    span = hi - lo
    raw_step = span / n
    step = _nice_num(raw_step, False)
    nice_lo = math.floor(lo / step) * step
    nice_hi = math.ceil(hi / step) * step
    count = int(round((nice_hi - nice_lo) / step))
    return [nice_lo + i * step for i in range(count + 1)]


def fixed_step_ticks(lo: float, hi: float, step: float) -> list[float]:
    """Evenly-spaced tick values from `lo` to `hi` at an explicit `step`.

    Unlike :func:`nice_ticks`/:func:`nice_ticks_range`, the step is not
    rounded to a "nice" 1/2/5 multiple: the caller has already chosen it
    (e.g. to match a known theoretical bound, or a fixed grid density for a
    print figure). Values are rounded to 9 decimal places to absorb float
    accumulation error from repeated addition (``-1.6 + 8 * 0.2`` landing a
    few ULPs off ``0``).

    Parameters
    ----------
    lo, hi : float
        Inclusive tick range. `hi` must be greater than or equal to `lo`.
    step : float
        Spacing between consecutive ticks. Must be positive.

    Returns
    -------
    list of float
        Ascending ticks from `lo` to `hi` (`hi` included when it falls on
        an exact multiple of `step` from `lo`, within float tolerance).
        Never exceeds `hi`: when `step` does not evenly divide
        ``hi - lo``, the last tick lands short of `hi` rather than
        overshooting it (a naive ``round()`` of the tick count can push
        the final tick past `hi`, placing a gridline/label outside the
        plotted axis).

    Examples
    --------
    >>> fixed_step_ticks(-1.6, 1.6, 0.2)[:3]
    [-1.6, -1.4, -1.2]
    """
    if step <= 0 or hi < lo:
        return []
    n = int(math.floor((hi - lo) / step + 1e-9))
    return [round(lo + i * step, 9) for i in range(n + 1)]


if __name__ == "__main__":  # tiny self-test
    assert log_position(1, 1, 100, 0.0, 100.0) == 0.0
    assert log_position(100, 1, 100, 0.0, 100.0) == 100.0
    assert log_ticks(3, 420) == [1.0, 10.0, 100.0, 1000.0]
    assert log_ticks(0, 5) == []
    assert nice_ticks(92) == [0.0, 20.0, 40.0, 60.0, 80.0, 100.0]
    assert nice_ticks(0) == [0.0]
    assert nice_ticks_range(14.3, 74.6) == [10.0, 20.0, 30.0, 40.0, 50.0, 60.0, 70.0, 80.0]
    assert nice_ticks_range(5, 5) == []
    assert fixed_step_ticks(-1.6, 1.6, 0.2)[0] == -1.6
    assert fixed_step_ticks(-1.6, 1.6, 0.2)[-1] == 1.6
    assert len(fixed_step_ticks(-1.6, 1.6, 0.2)) == 17
    assert fixed_step_ticks(1, 0, 0.1) == []
    assert fixed_step_ticks(0, 23, 3) == [0.0, 3.0, 6.0, 9.0, 12.0, 15.0, 18.0, 21.0]
    print("_scale self-test OK")


# ──────────────────────────────────────────────────────────────────────────
# from _textfit.py
# ──────────────────────────────────────────────────────────────────────────

# Per-character advance widths in em units, calibrated to Roboto. Only the
# classes that differ much from the mean are listed; everything else falls back
# to _DEFAULT_EM. Values are deliberately a hair generous so a fitted layout
# errs toward whitespace, never toward a clip.
_DEFAULT_EM = 0.52
_EM: dict[str, float] = {
    " ": 0.26, "i": 0.24, "j": 0.24, "l": 0.24, "I": 0.30, "t": 0.31, "f": 0.32,
    "r": 0.34, "'": 0.20, "’": 0.20, "!": 0.26, ".": 0.26, ",": 0.26, ":": 0.26,
    ";": 0.26, "|": 0.22, "(": 0.31, ")": 0.31, "[": 0.31, "]": 0.31, "-": 0.33,
    "m": 0.82, "M": 0.84, "w": 0.72, "W": 0.92, "%": 0.82, "@": 0.92,
    "0": 0.55, "1": 0.55, "2": 0.55, "3": 0.55, "4": 0.55, "5": 0.55,
    "6": 0.55, "7": 0.55, "8": 0.55, "9": 0.55,
}
# Function words that must not be stranded at the end of a wrapped line.
_ORPHANS_EN = {
    "of", "the", "a", "an", "to", "and", "or", "for", "in", "on", "is", "from",
    "with", "by", "at", "as", "into", "over", "than", "per", "vs",
}
_ORPHANS_FR = {"le", "la", "les", "de", "des", "du", "un", "une", "et", "ou", "à"}
_ORPHANS = _ORPHANS_EN | _ORPHANS_FR


def text_width(text: str, font_size: float, *, bold: bool = False) -> float:
    """Estimate the rendered width, in pixels, of ``text`` at ``font_size``.

    Bold Roboto is a little wider; ``bold`` scales the estimate by 3%.
    """
    ems = sum(_EM.get(ch, _DEFAULT_EM) for ch in text)
    return ems * font_size * (1.03 if bold else 1.0)


def fit_font_size(text: str, max_px: float, start: float, *, min_px: float = 9.0) -> float:
    """The largest size <= ``start`` at which ``text`` fits ``max_px`` on one
    line, floored at ``min_px``."""
    size = start
    while size > min_px and text_width(text, size) > max_px:
        size -= 0.5
    return max(size, min_px)


def _ends_on_orphan(line: str) -> bool:
    words = line.split()
    if not words:
        return False
    last = words[-1].strip(".,;:!?").lower()
    # A trailing elision ("l'", "d'") or a bare function word both count.
    return last in _ORPHANS or last.endswith("’") or last.endswith("'")


def wrap_to_width(text: str, max_px: float, font_size: float, *, bold: bool = False) -> list[str]:
    """Wrap ``text`` to lines no wider than ``max_px``, then push any dangling
    function word off the end of a line onto the next.

    Returns the list of lines. A single word wider than ``max_px`` is kept on
    its own line rather than split mid-word.
    """
    words = text.split()
    if not words:
        return [""]
    lines: list[str] = []
    cur = ""
    for w in words:
        trial = w if not cur else f"{cur} {w}"
        if text_width(trial, font_size, bold=bold) <= max_px or not cur:
            cur = trial
        else:
            lines.append(cur)
            cur = w
    if cur:
        lines.append(cur)

    # Orphan pass: while a line ends on a function word, move that word down.
    changed = True
    while changed:
        changed = False
        for i in range(len(lines) - 1):
            if _ends_on_orphan(lines[i]):
                words_i = lines[i].split()
                moved = words_i.pop()
                lines[i] = " ".join(words_i)
                lines[i + 1] = f"{moved} {lines[i + 1]}"
                changed = True
        # The last line may also strand an orphan ("... share of the"); if so and
        # there is room to fold the previous word up would not help, so open a new
        # trailing line to carry the dangling word rather than leave it hanging.
        if lines and _ends_on_orphan(lines[-1]) and len(lines[-1].split()) > 1:
            words_last = lines[-1].split()
            moved = words_last.pop()
            lines[-1] = " ".join(words_last)
            lines.append(moved)
            changed = True
    return [ln for ln in lines if ln]


if __name__ == "__main__":  # tiny self-test
    assert text_width("", 20) == 0
    assert text_width("mmm", 20) > text_width("iii", 20)
    w = wrap_to_width("The ring is one full year; follow it clockwise from the top.", 180, 15)
    assert all(not _ends_on_orphan(ln) for ln in w), w
    fr = wrap_to_width("La longueur de chaque arc est sa part de l’année entière.", 180, 15)
    assert all(not ln.rstrip().endswith(("’", "'")) for ln in fr), fr
    assert fit_font_size("Very wide title here", 60, 30) < 30
    print("wrap EN:", w)
    print("wrap FR:", fr)
    print("_textfit self-test OK")


# ──────────────────────────────────────────────────────────────────────────
# from _style.py
# ──────────────────────────────────────────────────────────────────────────

import csv
import os
import sys
import warnings
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple


# ------------------------------------------------------------------
# House chrome — the ink/paper/gridline/mono-font quartet every generator's
# title, axis and tick text is drawn in. ~65 generators each re-declared
# these five names as bare module-level constants (confirmed byte-identical
# by grep before centralizing here); import them instead of re-typing the
# hex codes so a house-style change is one edit, not sixty-five.
# ------------------------------------------------------------------
INK = "#1D1D1F"
SECONDARY = "#6E6E73"
BG = "#FFFFFF"
GRIDLINE = "#E5E5EA"
FONT_MONO = "Roboto Mono, ui-monospace, monospace"


# ------------------------------------------------------------------
# Built-in curated fallback — the Apple-inspired 8 + 4 neutrals.
# The canonical source is sprezzature-colors/references/palette.csv, which
# projects each hex onto four semantic axes: **Emotion**, **Concepts**,
# **PsychologyPositive**, **PsychologyNegative**. The full mapping is
# documented at <https://harchaoui.org/warith/colors/>. When the CSV is
# available, :func:`load_semantic_palette` reads it. This fallback is
# used only when neither ``sprezzature-colors`` nor ``SPREZZATURE_COLORS_PALETTE``
# can be resolved.
# ------------------------------------------------------------------
_FALLBACK_PALETTE: Dict[str, str] = {
    # 8 saturated hues.
    "Red":    "#FF3B30",
    "Orange": "#FF9500",
    "Yellow": "#FFCC00",
    "Green":  "#34C759",
    "Mint":   "#00C7BE",
    "Teal":   "#5AC8FA",
    "Blue":   "#007AFF",
    "Purple": "#AF52DE",
    # 4 neutrals.
    "Gray":   "#8E8E93",
    "Brown":  "#A2845E",
    "Black":  "#000000",
    "White":  "#FFFFFF",
}


# ------------------------------------------------------------------
# Academic-theme palette — Okabe & Ito (2002), the categorical palette Bang
# Wong's 2011 Nature Methods editorial made the de facto standard for
# scientific figures: colour-vision-deficiency-safe *by construction* (no
# pure red/green pairing), not merely re-leveled into safety on request the
# way the corporate palette is via :func:`_apply_accessibility_level`. Same
# key set as :data:`_FALLBACK_PALETTE` so every existing
# ``cycle_hues(keys, accessibility)`` call resolves unchanged once `theme`
# is threaded through -- no caller needs its own hue-name list to change.
# Neutrals (Gray/Brown/Black/White) are theme-agnostic and match corporate;
# Okabe-Ito itself defines only the 7 chromatic hues + black. Two corporate
# slots (Mint, Teal) have no distinct Okabe-Ito counterpart and share Green/
# Sky Blue respectively rather than inventing an unvetted seventh hue.
# ------------------------------------------------------------------
_ACADEMIC_PALETTE: Dict[str, str] = {
    "Red":    "#D55E00",  # vermilion -- Okabe-Ito's red substitute (pure red excluded by design)
    "Orange": "#E69F00",
    "Yellow": "#F0E442",
    "Green":  "#009E73",  # bluish green
    "Mint":   "#009E73",  # no distinct Okabe-Ito equivalent; shares Green
    "Teal":   "#56B4E9",  # sky blue
    "Blue":   "#0072B2",
    "Purple": "#CC79A7",  # reddish purple
    "Gray":   "#8E8E93",
    "Brown":  "#A2845E",
    "Black":  "#000000",
    "White":  "#FFFFFF",
}


#: Emotion → hex fallback, mirroring the ``Emotion`` column of the
#: sprezzature-colors CSV. Anger / Sadness / Joy etc. Source:
#: <https://harchaoui.org/warith/colors/>.
_FALLBACK_EMOTIONS: Dict[str, str] = {
    "Anger":     "#FF3B30",
    "Surprise":  "#FF9500",
    "Joy":       "#FFCC00",
    "Disgust":   "#34C759",
    "Happiness": "#00C7BE",
    "Sadness":   "#007AFF",
    "Fear":      "#AF52DE",
    "Love":      "#FF2D55",
    "Comfort":   "#A2845E",
    "Silence":   "#000000",
    "Neutral":   "#8E8E93",
    "Peace":     "#FFFFFF",
}


def _sibling_palette_csv() -> Optional[Path]:
    """Locate ``sprezzature-colors/references/palette.csv`` if co-installed.

    Returns
    -------
    pathlib.Path or None
        The path to the CSV if found; ``None`` otherwise. Search:

        1. ``SPREZZATURE_COLORS_PALETTE`` env var (explicit override).
        2. Sibling directory (``../../sprezzature-colors/references/palette.csv``
           relative to this file).
        3. ``~/.claude/skills/sprezzature-colors/references/palette.csv``.
        4. ``~/.opencode/skills/sprezzature-colors/references/palette.csv``.
    """
    env = (os.environ.get("SPREZZATURE_COLORS_PALETTE") or os.environ.get("FRONT_COLORS_PALETTE") or "").strip()
    if env:
        p = Path(env).expanduser()
        if p.is_file():
            return p

    here = Path(__file__).resolve()
    # sprezzature-figures/scripts/_style.py -> repo-root/sprezzature-colors/references/palette.csv
    sibling = here.parent.parent.parent / "sprezzature-colors" / "references" / "palette.csv"
    if sibling.is_file():
        return sibling

    for runtime in ("claude", "opencode"):
        p = Path.home() / f".{runtime}" / "skills" / "sprezzature-colors" / "references" / "palette.csv"
        if p.is_file():
            return p

    return None


def _sibling_sprezzature_colors_scripts() -> Optional[Path]:
    """Locate ``sprezzature-colors/scripts`` (the accessibility-level engine) if present.

    Same co-installation search as :func:`_sibling_palette_csv`, one directory
    over. Returns ``None`` when sprezzature-colors is not alongside, in which case only
    the ``universal`` level is available (see :func:`load_palette`).
    """
    csv_path = _sibling_palette_csv()
    if csv_path is not None:
        # references/palette.csv -> ../scripts
        scripts = csv_path.parent.parent / "scripts"
        if (scripts / "accessibility_levels.py").is_file():
            return scripts
    return None


def _apply_accessibility_level(palette: Dict[str, str], level: str) -> Dict[str, str]:
    """Remap ``palette`` to an accessibility ``level`` via the sprezzature-colors engine.

    The colour science (OKLCH round-trip, WCAG contrast, Machado colour-vision
    matrices) lives in ``sprezzature-colors/scripts/accessibility_levels.py`` so it is
    not duplicated here. When sprezzature-colors is not co-installed, or the level is
    unknown, the palette is returned unchanged and a warning is emitted, so a
    figure never crashes over accessibility styling.
    """
    scripts = _sibling_sprezzature_colors_scripts()
    if scripts is None:
        warnings.warn(
            f"accessibility level {level!r} requested but sprezzature-colors is not "
            "co-installed; using the universal palette",
            stacklevel=2,
        )
        return palette
    if str(scripts) not in sys.path:
        sys.path.insert(0, str(scripts))
    try:
        from accessibility_levels import apply_level  # noqa: PLC0415 (lazy, optional dep)

        return apply_level(palette, level)
    except Exception as exc:  # pragma: no cover - defensive; never break a figure
        warnings.warn(f"accessibility level {level!r} failed ({exc}); using universal", stacklevel=2)
        return palette


def load_palette(accessibility: str = "universal", theme: str = "corporate") -> Dict[str, str]:
    """Read the canonical palette, at a chosen accessibility level and theme.

    Parameters
    ----------
    accessibility : str, optional
        The accessibility level to render the palette at. ``"universal"``
        (default) is the curated, colour-vision-safe standard everyone gets.
        Other levels are ``"high-contrast"``, ``"monochrome"``,
        ``"deuteranopia"``, ``"protanopia"`` and ``"tritanopia"``; they are
        applied by the sprezzature-colors engine when it is co-installed. See
        ``sprezzature-colors/references/accessibility-levels.md`` for the model.
        Applies on top of either theme's base palette -- academic's
        ``universal`` default is already CVD-safe by construction (Okabe-Ito),
        but the engine still runs for e.g. ``"monochrome"`` grayscale output.
    theme : str, optional
        ``"corporate"`` (default) reads the sprezzature-colors CSV / Apple-
        system :data:`_FALLBACK_PALETTE`, unchanged from before this
        parameter existed. ``"academic"`` returns :data:`_ACADEMIC_PALETTE`
        (Okabe-Ito) directly, ignoring any co-installed brand CSV -- Okabe-Ito
        is a fixed, citable scientific standard, not a brand palette meant to
        be swapped per project.

    Returns
    -------
    dict of str to str
        Mapping ``{"Red": "#FF3B30", ...}``. Keys are the palette CSV's ``Base``
        values; values are the level-appropriate hex. Order follows the CSV; the
        fallback follows the order in ``_FALLBACK_PALETTE``.
    """
    if theme == "academic":
        palette = dict(_ACADEMIC_PALETTE)
    else:
        csv_path = _sibling_palette_csv()
        if csv_path is None:
            palette = dict(_FALLBACK_PALETTE)
        else:
            palette = {}
            with csv_path.open("r", encoding="utf-8", newline="") as fh:
                reader = csv.DictReader(fh)
                for row in reader:
                    name = (row.get("Base") or row.get("name") or "").strip()
                    hexv = (row.get("Hexcode") or row.get("Hex") or row.get("hex") or "").strip()
                    if name and hexv.startswith("#") and len(hexv) in (4, 7):
                        palette[name] = hexv.upper()
            palette = palette or dict(_FALLBACK_PALETTE)

    # ``universal`` is the identity, so the default path never touches the engine
    # and stays byte-for-byte what it always produced.
    if accessibility and accessibility != "universal":
        palette = _apply_accessibility_level(palette, accessibility)
    return palette


def leveled_colors(colors: Dict[str, str], accessibility: str = "universal") -> Dict[str, str]:
    """Apply an accessibility level to an *arbitrary* ``{name: hex}`` colour set.

    Some figures pick categorical colours that are not the shared palette (a
    curated per-species or per-class set tuned during the accessibility pass).
    Wrapping that set with this helper lets the figure still answer to the
    ``accessibility`` argument without adopting the house palette: ``universal``
    returns the colours unchanged (so the default figure is byte-for-byte the
    same), and every other level remaps *these* colours through the same
    sprezzature-colors engine that levels the palette.

    Do NOT use this on a continuous / perceptual colour map (viridis, a single
    hue ramp): those are already colour-vision- and greyscale-safe by
    construction, and re-spacing their anchors by lightness would de-tune them.
    Leave such maps at ``universal``.

    Parameters
    ----------
    colors : dict of str to str
        The figure's own ``{category: "#RRGGBB"}`` mapping.
    accessibility : str, optional
        One of the levels understood by :func:`load_palette`. Defaults to
        ``"universal"`` (the identity).

    Returns
    -------
    dict of str to str
        The same keys, remapped to the level (or unchanged for ``universal``).
    """
    if not accessibility or accessibility == "universal":
        return dict(colors)
    return _apply_accessibility_level(colors, accessibility)


#: Default categorical cycle order for :func:`cycle_hues` — the four hues
#: every ``_category_colors``/``_series_colors``/``_segment_colors`` copy
#: picked, before this helper existed, reordered once: the original
#: (Blue, Orange, Green, Purple) put Orange (#FF9500, relative luminance
#: ~160.7) directly next to Green (#34C759, ~159.8) -- a ~1-point gap that
#: several Ralph Eyeball Loop passes independently found collapsing to the
#: same grey under grayscale/achromatopsia simulation. Swapping Green and
#: Purple keeps the same four hues (no caller's semantics change) but
#: spaces every adjacent pair (including the wrap) at least ~48 luminance
#: points apart: Blue(105.7)-Orange(160.7)-Purple(111.8)-Green(159.8)-wrap.
_DEFAULT_CYCLE = ("Blue", "Orange", "Purple", "Green")


def cycle_hues(
    keys: List[str], accessibility: str = "universal", hues: Optional[List[str]] = None,
    theme: str = "corporate",
) -> Dict[str, str]:
    """Assign each of `keys` a hue, cycling through a small qualitative set.

    Generalizes the ``_category_colors``/``_series_colors``/``_segment_colors``
    pattern that ~14 generators each hand-rolled: look up a handful of named
    hues from the accessibility-leveled palette, then hand them out to
    `keys` in order, wrapping around once the hue list is exhausted. Callers
    keep their own thin wrapper (its name and signature vary by figure, e.g.
    ``_category_colors(accessibility)``) that just delegates its body here.

    Parameters
    ----------
    keys : list of str
        The categories/series to color, in the order they should receive
        hues (typically a chart's fixed category list, not the row order,
        so the mapping is stable across `data` inputs).
    accessibility : str, optional
        Forwarded to :func:`load_palette`. Defaults to ``"universal"``.
    hues : list of str, optional
        Palette hue *names* to cycle through, e.g. ``["Blue", "Red"]``.
        Defaults to :data:`_DEFAULT_CYCLE` (``Blue, Orange, Purple, Green``),
        chosen for grayscale/CVD luminance separation between adjacent
        hues (see that constant's own comment). Names are
        shared across themes (see :data:`_ACADEMIC_PALETTE`), so a caller's
        existing `hues` list needs no change to theme correctly.
    theme : str, optional
        Forwarded to :func:`load_palette`. Defaults to ``"corporate"``.

    Returns
    -------
    dict of str to str
        ``{key: hex}``, one entry per `keys`, hues repeating past the 4th.

    Examples
    --------
    >>> colors = cycle_hues(["North", "South", "East", "West", "Central"])
    >>> len(colors)
    5
    >>> colors["North"] == colors["Central"]  # wraps after 4 hues
    True
    """
    palette = load_palette(accessibility, theme=theme)
    fallback = _ACADEMIC_PALETTE if theme == "academic" else _FALLBACK_PALETTE
    order = hues or list(_DEFAULT_CYCLE)
    picked = [palette.get(name, fallback.get(name, "#007AFF")) for name in order]
    if not picked:
        picked = ["#007AFF"]
    return {key: picked[i % len(picked)] for i, key in enumerate(keys)}


def os_adaptive_style(
    series: Dict[str, str],
    *,
    role: str = "fill",
    forced: bool = False,
    forced_keyword: str = "CanvasText",
    extra_contrast: str = "",
    extra_forced: str = "",
) -> str:
    """Emit the additive ``@media`` overrides that let one SVG adapt to the OS.

    The idea behind the "OS-adaptive" figure: ship *one* SVG that quietly
    retunes itself when the reader's operating system signals a preference,
    instead of a separate file per level. This returns only the ``@media``
    blocks — append them **inside the figure's existing** ``<style>``. Because
    a CSS class rule outranks an inline ``fill=""``/``stroke=""`` presentation
    attribute, and because *every* rule here lives inside a media query, the
    default render (no preference active) matches none of them and stays
    byte-for-byte what the figure always produced. Only when the OS asks does a
    block take over.

    Two signals are handled, deliberately:

    - ``prefers-contrast: more`` — deepen each series to its ``high-contrast``
      hue (via the same sprezzature-colors engine that levels the palette) on the
      chosen ``role``. This is the broad, safe win: it never loses category
      identity, it only strengthens it.
    - ``forced-colors: active`` (Windows High Contrast and kin) — opt-in via
      ``forced=True``. Only meaningful for figures whose category identity is
      carried by **position or shape, not colour** (a Venn, a parliament, a
      waffle): those can drop to system-palette line art and still read. Do
      **not** set ``forced=True`` on a colour-encoded figure (multi-line,
      stacked area, heatmap) — the ~4-colour system palette cannot preserve the
      encoding, and the browser leaves SVG fills alone by default, which is the
      correct behaviour there.

    ``prefers-color-scheme: dark`` is intentionally **not** handled: on a
    light-poster figure it needs a real design pass (ink inversion, blend-mode
    flips), not a hue swap, so it is left to a separate, deliberate effort.

    Parameters
    ----------
    series : dict of str to str
        Maps a **CSS selector** (e.g. ``".bar-3"``, ``".setlabel-A"``) to that
        series' base hex. The whole set is deepened together so the
        ``high-contrast`` spacing stays balanced.
    role : str, optional
        Which property the hue drives on these selectors under
        ``prefers-contrast``: ``"fill"`` (default), ``"stroke"``, or ``"both"``.
    forced : bool, optional
        Emit a ``forced-colors: active`` block. Default ``False``.
    forced_keyword : str, optional
        System colour keyword the selectors take under forced colours
        (``"CanvasText"`` default; ``"Canvas"`` for fills you want to blank).
    extra_contrast, extra_forced : str, optional
        Figure-specific CSS appended inside the respective block — for the
        legibility tuning the engine cannot know (e.g. dropping a lobe's
        ``fill-opacity`` so region counts stay readable, or a text backplate).

    Returns
    -------
    str
        The ``@media`` block(s), ready to concatenate into the figure's
        ``<style>``. Empty selectors + no ``forced`` + no extras yield ``""``.
    """
    if role not in ("fill", "stroke", "both"):
        raise ValueError(f"role must be fill/stroke/both, got {role!r}")

    blocks: List[str] = []

    # ---- prefers-contrast: more -> deepened, higher-contrast hues ----
    hc = leveled_colors(series, "high-contrast") if series else {}
    contrast_rows: List[str] = []
    for selector, hexv in hc.items():
        if role == "fill":
            decl = f"fill:{hexv};"
        elif role == "stroke":
            decl = f"stroke:{hexv};"
        else:
            decl = f"fill:{hexv};stroke:{hexv};"
        contrast_rows.append(f"{selector}{{{decl}}}")
    if extra_contrast:
        contrast_rows.append(extra_contrast)
    if contrast_rows:
        blocks.append(
            "@media (prefers-contrast: more){\n  " + "\n  ".join(contrast_rows) + "\n}"
        )

    # ---- forced-colors: active -> hand identity to the system palette ----
    if forced or extra_forced:
        forced_rows = [f"{selector}{{fill:{forced_keyword};}}" for selector in series]
        if extra_forced:
            forced_rows.append(extra_forced)
        blocks.append(
            "@media (forced-colors: active){\n  " + "\n  ".join(forced_rows) + "\n}"
        )

    return "\n".join(blocks)


#: House inks and their dark-mode counterparts. The generators pull ink from a
#: shared, fixed set (`_BG` #FFFFFF, `_INK` #1D1D1F, `_SUBTLE` #6E6E73), so a
#: single attribute-selector block flips the whole catalogue to a dark surface
#: without per-figure bespoke selectors.
_DARK_INK_MAP: Dict[str, str] = {
    "#FFFFFF": "#0B0B0C",   # paper -> near-black surface
    "#1D1D1F": "#F2F2F7",   # primary ink -> off-white
    "#6E6E73": "#9C9CA3",   # secondary ink -> light grey
}


def os_dark_style(*, ink_map: Optional[Dict[str, str]] = None, screen_blend: bool = True, extra: str = "") -> str:
    """Emit an additive ``prefers-color-scheme: dark`` block for a house figure.

    Because every generator inks its text and paper from the same fixed
    constants, dark mode is mostly uniform: invert the paper and the two ink
    tiers with attribute selectors (`[fill="#RRGGBB"]`), and flip any
    ``mix-blend-mode: multiply`` group to ``screen`` so overlaps *lighten* on a
    dark surface instead of turning to mud. The data hues are left alone (the
    saturated house palette reads on dark). White keylines and halos
    (``stroke="#FFFFFF"``) are deliberately not touched — white-on-dark still
    separates marks. Anything figure-specific (a light panel, a custom
    gridline, a white pill that should darken) goes through ``extra``.

    The block is additive and media-gated, so the default (light) render is
    unchanged; it only applies when the reader's operating system asks for dark.

    Parameters
    ----------
    ink_map : dict of str to str, optional
        Light-hex -> dark-hex overrides. Defaults to :data:`_DARK_INK_MAP`
        (paper + the two ink tiers). Keys are matched as ``[fill="key"]``.
    screen_blend : bool, optional
        If ``True`` (default), flip ``mix-blend-mode: multiply`` groups to
        ``screen`` for correct overlap behaviour on dark.
    extra : str, optional
        Figure-specific CSS appended inside the block.

    Returns
    -------
    str
        A single ``@media (prefers-color-scheme: dark){ ... }`` block, or ``""``
        if nothing would be emitted.
    """
    rows: List[str] = []
    for light, dark in (ink_map or _DARK_INK_MAP).items():
        rows.append(f'[fill="{light}"]{{fill:{dark};}}')
    if screen_blend:
        rows.append('[style*="multiply"]{mix-blend-mode:screen;}')
    if extra:
        rows.append(extra)
    if not rows:
        return ""
    return "@media (prefers-color-scheme: dark){\n  " + "\n  ".join(rows) + "\n}"


#: A cycling set of forced-colors fill patterns. Each is a `Canvas`-backed tile
#: stroked/dotted in `CanvasText`, so it renders in the reader's system theme
#: and survives Windows High Contrast, where a colour encoding would collapse.
_FC_PATTERN_TILES: List[str] = [
    '<rect width="8" height="8" fill="Canvas"/><path d="M0,8L8,0" stroke="CanvasText" stroke-width="1.6"/>',       # diag /
    '<rect width="8" height="8" fill="Canvas"/><path d="M0,0L8,8" stroke="CanvasText" stroke-width="1.6"/>',       # diag \
    '<rect width="8" height="8" fill="Canvas"/><path d="M0,4L8,4" stroke="CanvasText" stroke-width="1.6"/>',       # horizontal
    '<rect width="8" height="8" fill="Canvas"/><path d="M4,0L4,8" stroke="CanvasText" stroke-width="1.6"/>',       # vertical
    '<rect width="10" height="10" fill="Canvas"/><circle cx="5" cy="5" r="1.8" fill="CanvasText"/>',               # dots
    '<rect width="8" height="8" fill="Canvas"/><path d="M0,4L8,4M4,0L4,8" stroke="CanvasText" stroke-width="1.4"/>',  # cross
]


def forced_color_patterns(series: List[str], *, prefix: str = "fcp") -> Tuple[str, str]:
    """Build per-series SVG patterns + the forced-colors block that applies them.

    For a colour-*encoded* figure (multi-line, streamgraph, many wedges) the
    roughly four-colour Windows High Contrast palette cannot preserve the
    encoding, and a flat system colour would merge every series. This gives each
    series a distinct **pattern** (hatch, dots, cross) drawn in ``Canvas`` /
    ``CanvasText``, so identity survives without colour. ``forced-color-adjust:
    none`` keeps the pattern fill from being overridden by the user agent.

    The patterns are additive and only referenced inside the forced-colors media
    query, so the default render is unchanged.

    Parameters
    ----------
    series : list of str
        The CSS selectors (e.g. ``[".river-0", ".river-1", ...]``) whose fills
        should become patterns under forced colours, in order.
    prefix : str, optional
        Id prefix for the generated ``<pattern>`` elements. Defaults to
        ``"fcp"``. Pass a figure-unique prefix if a page inlines several SVGs.

    Returns
    -------
    tuple of (str, str)
        ``(defs, style)`` — the ``<pattern>`` definitions to drop anywhere in
        the SVG, and the ``@media (forced-colors: active){ ... }`` block to
        append inside ``<style>``. Both are ``""`` when ``series`` is empty.
    """
    if not series:
        return "", ""
    defs: List[str] = []
    rules: List[str] = []
    for i, selector in enumerate(series):
        pid = f"{prefix}-{i}"
        tile = _FC_PATTERN_TILES[i % len(_FC_PATTERN_TILES)]
        # A 10-unit tile for dots, 8 for the rest; patternUnits keeps it stable
        # under the figure's own transforms.
        size = 10 if "circle" in tile else 8
        defs.append(
            f'<pattern id="{pid}" width="{size}" height="{size}" '
            f'patternUnits="userSpaceOnUse">{tile}</pattern>'
        )
        rules.append(f"{selector}{{fill:url(#{pid});forced-color-adjust:none;}}")
    style = "@media (forced-colors: active){\n  " + "\n  ".join(rules) + "\n}"
    return "".join(defs), style


def load_semantic_palette() -> Dict[str, Dict[str, Any]]:
    """Load the full semantic palette (base + emotion + concepts + psychology).

    Reads every column of ``sprezzature-colors/references/palette.csv``:
    ``Hexcode``, ``Base``, ``LightHex``, ``Emotion``, ``Concepts``,
    ``PsychologyPositive``, ``PsychologyNegative``. Documented at
    <https://harchaoui.org/warith/colors/>.

    Returns
    -------
    dict of str to dict
        Mapping ``{base_color_name: {"hex": "#RRGGBB", "light":
        "#RRGGBB", "emotion": str, "concepts": [str, ...],
        "psychology_positive": [str, ...],
        "psychology_negative": [str, ...]}}``.
    """
    csv_path = _sibling_palette_csv()
    if csv_path is None:
        return _fallback_semantic()

    out: Dict[str, Dict[str, Any]] = {}
    with csv_path.open("r", encoding="utf-8", newline="") as fh:
        reader = csv.DictReader(fh)
        for row in reader:
            base = (row.get("Base") or "").strip()
            hex_ = (row.get("Hexcode") or "").strip().upper()
            if not (base and hex_.startswith("#")):
                continue
            out[base] = {
                "hex": hex_,
                "light": (row.get("LightHex") or "").strip().upper() or hex_,
                "emotion": (row.get("Emotion") or "").strip(),
                "concepts": [c.strip() for c in (row.get("Concepts") or "").split(",") if c.strip()],
                "psychology_positive": [
                    c.strip() for c in (row.get("PsychologyPositive") or "").split(",") if c.strip()
                ],
                "psychology_negative": [
                    c.strip() for c in (row.get("PsychologyNegative") or "").split(",") if c.strip()
                ],
            }
    return out or _fallback_semantic()


def _fallback_semantic() -> Dict[str, Dict[str, Any]]:
    """Return a minimal semantic palette when the CSV is unavailable."""
    return {
        base: {
            "hex": hexv,
            "light": hexv,
            "emotion": next((e for e, h in _FALLBACK_EMOTIONS.items() if h == hexv), ""),
            "concepts": [],
            "psychology_positive": [],
            "psychology_negative": [],
        }
        for base, hexv in _FALLBACK_PALETTE.items()
    }


def emotion_to_hex(emotion: str) -> Optional[str]:
    """Return the curated hex for one of the palette's Emotion labels.

    Parameters
    ----------
    emotion : str
        Case-insensitive Emotion label from the palette CSV
        (``"Anger"``, ``"Joy"``, ``"Sadness"``, …).

    Returns
    -------
    str or None
        Hex string, or ``None`` when the label is not in the palette.
    """
    target = emotion.strip().lower()
    for base, meta in load_semantic_palette().items():
        if meta["emotion"].lower() == target:
            return meta["hex"]
    fallback = {k.lower(): v for k, v in _FALLBACK_EMOTIONS.items()}
    return fallback.get(target)


def concept_search(term: str) -> List[str]:
    """Return every palette hex whose ``Concepts`` column mentions ``term``.

    Parameters
    ----------
    term : str
        Case-insensitive concept term (``"Trust"``, ``"Bold"``,
        ``"Optimism"``, …).

    Returns
    -------
    list of str
        Hex strings, order-preserving.
    """
    target = term.strip().lower()
    matches: List[str] = []
    for meta in load_semantic_palette().values():
        joined = " ".join(meta.get("concepts", [])).lower()
        joined_pos = " ".join(meta.get("psychology_positive", [])).lower()
        if target in joined or target in joined_pos:
            matches.append(meta["hex"])
    return matches


def psychology_for(base: str) -> Dict[str, List[str]]:
    """Return the positive / negative psychology terms for a base color.

    Parameters
    ----------
    base : str
        Case-insensitive base color name (``"Red"``, ``"Green"``, …).

    Returns
    -------
    dict
        ``{"positive": [...], "negative": [...]}``. Empty lists if the
        palette CSV is unavailable.
    """
    target = base.strip().lower()
    for name, meta in load_semantic_palette().items():
        if name.lower() == target:
            return {
                "positive": meta.get("psychology_positive", []),
                "negative": meta.get("psychology_negative", []),
            }
    return {"positive": [], "negative": []}


# ------------------------------------------------------------------
# Categorical sequences for chart encodings
# ------------------------------------------------------------------
def qualitative_sequence(n: int = 8, theme: str = "corporate") -> List[str]:
    """Return the first ``n`` curated saturated hues.

    Parameters
    ----------
    n : int, optional
        How many colors to return (default 8). Cycles the base list
        when ``n`` exceeds the palette size.
    theme : str, optional
        Forwarded to :func:`load_palette`. Defaults to ``"corporate"``.
        Academic's palette has only 7 distinct chromatic hues (two corporate
        slots, Mint and Teal, share one Okabe-Ito hue each with Green/Blue's
        neighbours — see :data:`_ACADEMIC_PALETTE`); duplicates are dropped
        here so a caller never sees the same hex twice in a row.

    Returns
    -------
    list of str
        ``n`` hex strings, brand-order.
    """
    base = list(load_palette(theme=theme).values())
    # Skip the neutrals for a qualitative encoding, and de-duplicate (the
    # academic palette reuses one hex across two corporate-only hue slots).
    seen: set = set()
    saturated: List[str] = []
    for h in base:
        hu = h.upper()
        if hu in {"#000000", "#FFFFFF", "#8E8E93", "#A2845E"} or hu in seen:
            continue
        seen.add(hu)
        saturated.append(h)
    if n <= len(saturated):
        return saturated[:n]
    out: List[str] = []
    while len(out) < n:
        out.extend(saturated)
    return out[:n]


# ------------------------------------------------------------------
# Colour-blind-safe diverging pair for signed / +/- data
# ------------------------------------------------------------------
#: The habitual **red ↔ green** diverging is hostile to red-green colour
#: blindness (~8 % of men): under protanopia / deuteranopia the two ends both
#: drift to a muddy tan and collapse into one hue, so the sign of the data can no
#: longer be read from colour. The **blue ↔ red** axis stays discriminable — blue
#: survives, red darkens toward brown — so it is the default whenever the +/-
#: distinction must be legible *from colour*, not only from a sign or a label.
#: Blue also carries *Trust / Logic* and red *Danger / Warning* in the sprezzature-colors
#: concepts, which fits "positive vs negative". Verify any diverging choice on the
#: rendered pixels with ``simulate_cvd.py``. Source:
#: <https://harchaoui.org/warith/colors/>.
DIVERGING_CVD_SAFE = ("#007AFF", "#F2F4F6", "#FF3B30")  # (positive, neutral mid, negative)


def diverging_pair(cvd_safe: bool = True) -> tuple:
    """Return a ``(positive, negative)`` hex pair for signed / growth data.

    Parameters
    ----------
    cvd_safe : bool, optional
        When ``True`` (default) return the **blue ↔ red** pair, which survives
        red-green colour blindness. When ``False`` return the conventional
        **green ↔ red** pair (finance-idiomatic but not colour-blind-safe) —
        only pick it when the sign is *also* encoded another way (a +/- glyph,
        position above/below zero) and you have confirmed it in ``simulate_cvd``.

    Returns
    -------
    tuple of str
        ``(positive_hex, negative_hex)``.
    """
    if cvd_safe:
        return DIVERGING_CVD_SAFE[0], DIVERGING_CVD_SAFE[2]
    palette = load_palette()
    return palette.get("Green", "#28CD41"), palette.get("Red", "#FF3B30")


# ------------------------------------------------------------------
# Corners — the Sprezzature Corner Policy (see references/corners.md)
# ------------------------------------------------------------------
#: The house radius scale in user-space pixels (figures). The UI mirrors these
#: as rem tokens in studio/theme.py and sprezzature-ui's generated CSS.
CORNERS: Dict[str, float] = {
    "none": 0.0,       # measurements, grids, adjacent/baseline corners
    "hairline": 1.0,   # the MOST a grid cell may ever have
    "xs": 2.5,         # tiles (treemap/mosaic/waffle), arc segments, small chips
    "sm": 4.0,         # bar value-ends, legend swatches, small controls
    "md": 7.0,         # buttons, inputs, node boxes, badges, tooltips
    "lg": 12.0,        # cards, chart panels, the figure frame
    "xl": 16.0,        # large containers / hero panels
}

#: Per-family size coefficient and cap token for the sizing rule
#: ``radius = clamp(0, k * min(w, h), cap)``.
_FAMILY_RULE: Dict[str, Tuple[float, str]] = {
    "bar": (0.18, "sm"),      # round the value-end only; a flat enough cap to read
    "tile": (0.12, "xs"),     # treemap / mosaic / waffle; also clamp to gap/2 at call site
    "arc": (1.0, "xs"),       # pie / donut / sunburst / rose; gentle, subtle
    "box": (0.20, "md"),      # text/node boxes
    "panel": (1.0, "lg"),     # cards / chart frame (fixed, not size-scaled)
}


def corner_radius(width: float, height: float, family: str = "bar") -> float:
    """Radius in px for a data mark, per the Sprezzature Corner Policy.

    ``radius = clamp(0, k * min(width, height), cap)`` where ``k`` and the cap
    come from the mark ``family`` (see :data:`_FAMILY_RULE`). Small marks fall to
    ~0 by the cap, which is intended: crisp beats mushy. Grids and measurement
    marks must not call this at all — they stay square.
    """
    k, cap_token = _FAMILY_RULE.get(family, _FAMILY_RULE["bar"])
    cap = CORNERS[cap_token]
    return max(0.0, min(k * min(width, height), cap))


def inner_radius(outer: float, gap: float) -> float:
    """Concentric inner radius for a shape nested in a rounded container:
    ``max(0, outer - gap)`` (Apple's concentric-corner rule). If the gap is at
    least the outer radius, the inner corner is square."""
    return max(0.0, outer - gap)


# ------------------------------------------------------------------
# Polarity vocabulary
# ------------------------------------------------------------------
POLARITY_HINTS: Dict[str, str] = {
    # metric substring (lowercase) -> "higher-better" | "lower-better"
    "latency":       "lower-better",
    "response":      "lower-better",
    "response_time": "lower-better",
    "error":         "lower-better",
    "errors":        "lower-better",
    "bug":           "lower-better",
    "bugs":          "lower-better",
    "cost":          "lower-better",
    "churn":         "lower-better",
    "attrition":     "lower-better",
    "conversion":    "higher-better",
    "revenue":       "higher-better",
    "sales":         "higher-better",
    "retention":     "higher-better",
    "engagement":    "higher-better",
    "accuracy":      "higher-better",
    "f1":            "higher-better",
    "recall":        "higher-better",
    "precision":     "higher-better",
    "auc":           "higher-better",
    "roc_auc":       "higher-better",
    "r2":            "higher-better",
    "throughput":    "higher-better",
    "uptime":        "higher-better",
    "availability":  "higher-better",
    "mae":           "lower-better",
    "mse":           "lower-better",
    "rmse":          "lower-better",
    "loss":          "lower-better",
}


def infer_polarity(metric_name: str) -> Optional[str]:
    """Guess polarity from a metric name; return ``None`` when ambiguous.

    Parameters
    ----------
    metric_name : str
        The axis-title or column name to score.

    Returns
    -------
    str or None
        ``"higher-better"``, ``"lower-better"``, or ``None`` if no
        substring in :data:`POLARITY_HINTS` matched.
    """
    if not metric_name:
        return None
    lower = metric_name.lower()
    for substr, polarity in POLARITY_HINTS.items():
        # word-ish boundary: substring surrounded by non-alphanumerics or ends
        if substr in lower:
            return polarity
    return None


# ------------------------------------------------------------------
# Polarity → color mapping
# ------------------------------------------------------------------
#: Base color to reach for by polarity intent. Rationale:
#: **higher-better** and **lower-better** are both "goal-directed" —
#: readers want to see the metric move — so both map to Green
#: (psychology-positive: *Health*, *Hope*, *Growth*, *Prosperity*).
#: **target=** shifts to Blue (psychology-positive: *Trust*, *Logic*,
#: *Security*) — the metric is neutral; the frame is compliance.
#: The **breach** overlay uses Red (psychology-negative: *Warning*,
#: *Danger*) to flag SLA violations without co-opting the base
#: encoding. Source: <https://harchaoui.org/warith/colors/>.
POLARITY_COLOR: Dict[str, str] = {
    "higher-better": "Green",
    "lower-better":  "Green",
    "target":        "Blue",
    "breach":        "Red",
    "neutral":       "Gray",
}


def polarity_color(
    polarity: Optional[str],
    *,
    role: str = "primary",
    dark: bool = False,
) -> Optional[str]:
    """Return the house-style hex for a polarity intent.

    Never a substitute for the polarity text tag on the axis title —
    ~8 % of male viewers cannot read the color signal alone (see
    ``cvd-simulation.md``). Used as a *reinforcement* layer.

    Parameters
    ----------
    polarity : str or None
        One of ``"higher-better"``, ``"lower-better"``, or
        ``"target=<N>"``. Anything else returns ``None`` (caller keeps
        the qualitative palette).
    role : {'primary', 'breach'}, optional
        ``"primary"`` returns the goal color (Green or Blue);
        ``"breach"`` returns the SLA-violation overlay (Red).
    dark : bool, optional
        Currently unused — every curated base hex meets contrast on
        both background modes. Reserved for future light/dark variant
        selection.

    Returns
    -------
    str or None
        A hex string from the curated palette, or ``None`` when the
        polarity is not one the mapping recognises.
    """
    if not polarity:
        return None
    if role == "breach":
        base: str | None = POLARITY_COLOR["breach"]
    elif polarity.startswith("target="):
        base = POLARITY_COLOR["target"]
    else:
        base = POLARITY_COLOR.get(polarity)
    if base is None:
        return None
    palette = load_palette()
    return palette.get(base)


def polarity_tag(polarity: Optional[str], lang: str = "en") -> str:
    """Return the parenthesised polarity tag for an axis title.

    Parameters
    ----------
    polarity : {'higher-better', 'lower-better', None} or ``"target=<N>"``
        The polarity to render.
    lang : str, optional
        BCP-47 base tag; controls the translation.

    Returns
    -------
    str
        E.g. ``" (higher is better)"`` — includes the leading space so
        it can be safely appended to any axis title. Empty when
        polarity is ``None``.
    """
    if not polarity:
        return ""
    translations = {
        "higher-better": {"en": " (higher is better)", "fr": " (plus c’est haut, mieux c’est)", "de": " (höher ist besser)", "es": " (más alto es mejor)"},
        "lower-better":  {"en": " (lower is better)",  "fr": " (plus c’est bas, mieux c’est)",  "de": " (niedriger ist besser)", "es": " (más bajo es mejor)"},
    }
    if polarity.startswith("target="):
        n = polarity.split("=", 1)[1]
        return {
            "en": f" (target = {n})",
            "fr": f" (cible = {n})",
            "de": f" (Ziel = {n})",
            "es": f" (objetivo = {n})",
        }.get(lang, f" (target = {n})")
    return translations.get(polarity, {}).get(lang, translations.get(polarity, {}).get("en", ""))


# ──────────────────────────────────────────────────────────────────────────
# from _svg.py
# ──────────────────────────────────────────────────────────────────────────

import math
import textwrap
from typing import List as _List

# Function words that must never be left stranded at the end of a wrapped line
# (house rule: no line-end orphans, EN or FR). See references/corners.md's sibling
# typography note and the no-line-end-orphans memory.
_ORPHAN_WORDS = frozenset(
    "of the a an to and or for in on by with from is as than per vs "
    "le la les des du de un une et a au aux dans sur pour par".split()
)


def wrap_no_orphan(text: str, width: int) -> _List[str]:
    """Word-wrap ``text`` to ``width`` characters per line, then push any line
    that ends on a dangling function word (or an elided ``l'``) down to the next
    line, so no wrapped line ever ends on ``of the`` / ``the`` / ``l'`` ...
    """
    lines = textwrap.wrap(text, width=width) or [""]
    changed = True
    while changed:
        changed = False
        for i in range(len(lines) - 1):
            words = lines[i].split()
            if not words:
                continue
            last = words[-1].lower().rstrip(".,;:")
            if last in _ORPHAN_WORDS or words[-1].endswith(("l'", "l’")):
                moved = words.pop()
                lines[i] = " ".join(words)
                lines[i + 1] = f"{moved} {lines[i + 1]}"
                changed = True
    return [ln for ln in lines if ln] or [""]
from typing import Callable, Sequence, Tuple

try:
    pass  # bundled: already defined at module level
except ImportError:  # pragma: no cover - fonts.py is stdlib-only, always importable
    DEFAULT_SVG_FACES = ()

    def svg_font_defs(keys: Tuple[str, ...] = ()) -> str:  # type: ignore[misc]
        return ""


def xml_escape(text: str) -> str:
    """Escape the three XML metacharacters for safe inclusion in an SVG.

    Replaces ``&``, ``<`` and ``>`` with their entity forms, in that
    order (ampersand first so the ``&`` introduced by ``&lt;`` / ``&gt;``
    is not double-escaped). This is byte-identical to the private
    ``_xml`` / ``_esc`` helpers the generators previously carried; it is
    intentionally minimal (no quote escaping) because generator text only
    ever lands in element content, never inside an attribute value.

    Parameters
    ----------
    text : str
        Raw text (a label, place name, category, …) to embed as SVG
        element content.

    Returns
    -------
    str
        ``text`` with ``&`` → ``&amp;``, ``<`` → ``&lt;``, ``>`` →
        ``&gt;``.

    Examples
    --------
    >>> xml_escape("Tom & Jerry <3")
    'Tom &amp; Jerry &lt;3'
    """
    # Order matters: escape "&" first, otherwise the "&" in "&lt;" / "&gt;"
    # produced by the later replacements would itself get re-escaped.
    return text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def point_on_circle(cx: float, cy: float, r: float, theta_rad: float) -> Tuple[float, float]:
    """Cartesian point at radius ``r`` and angle ``theta_rad`` about a centre.

    Standard math convention: ``theta_rad = 0`` points along +x (3
    o'clock) and grows counter-clockwise in a conventional axis — but in
    SVG's y-down space it reads as clockwise. Callers that want "0 = up"
    pass a pre-rotated angle (e.g. ``math.radians(deg - 90.0)``); this
    helper does no rotation of its own, so it returns exactly the pair
    the inline ``cx + r*cos(theta), cy + r*sin(theta)`` produced.

    Parameters
    ----------
    cx : float
        Centre x-coordinate, in user-space pixels.
    cy : float
        Centre y-coordinate, in user-space pixels.
    r : float
        Radius (distance from the centre), in user-space pixels.
    theta_rad : float
        Angle **in radians** (already converted from degrees by the
        caller if needed).

    Returns
    -------
    tuple of float
        The ``(x, y)`` point. Unformatted floats — the caller keeps its
        own ``:.1f`` / ``:.2f`` formatting so output stays identical.

    Examples
    --------
    >>> x, y = point_on_circle(100.0, 100.0, 50.0, 0.0)
    >>> round(x, 6), round(y, 6)
    (150.0, 100.0)
    """
    return cx + r * math.cos(theta_rad), cy + r * math.sin(theta_rad)


def fmt_compact(v: float, decimals: int = 1) -> str:
    """Format a float compactly for SVG path data: fixed decimals, no trailing zero.

    Rounds to `decimals` places, then strips trailing ``0``s and a
    now-dangling ``.`` so ``12.0`` prints as ``12`` and ``12.30`` as
    ``12.3``. The default (`decimals=1`) is byte-identical to the private
    ``_fmt`` the streamgraph, difference-chart and bollinger generators
    each carried, and the callers pass it straight into
    :func:`catmull_rom_beziers`. `decimals=2` is byte-identical to a
    second private ``_fmt`` shape (icicle, imshow-interpolated, mosaic,
    spectrogram) that wanted the same trim behavior at finer precision.

    Parameters
    ----------
    v : float
        A pixel coordinate (or any path-data number).
    decimals : int, optional
        Decimal places to round to before trimming. Defaults to ``1``.

    Returns
    -------
    str
        The compact decimal string.

    Examples
    --------
    >>> fmt_compact(12.0)
    '12'
    >>> fmt_compact(12.34)
    '12.3'
    >>> fmt_compact(12.345, decimals=2)
    '12.34'
    """
    # Round to `decimals` first (so 12.345 -> "12.34" at decimals=2), then
    # drop trailing zeros and the orphaned dot they leave behind
    # ("12.00" -> "12", "12" stays "12").
    return f"{v:.{decimals}f}".rstrip("0").rstrip(".")


def fmt_number(v: float) -> str:
    """Format a float as an adaptive axis-tick / tooltip label.

    Whole numbers (of any magnitude) print with no decimals; otherwise
    precision scales down with magnitude, so a tick label stays readable
    across a chart's full data range without a caller having to reason
    about it. This reconciles the three near-identical ``_fmt`` helpers
    that ``make_bar.py``, ``make_scatter.py`` and ``make_line-multi.py``
    each hand-rolled — their branch orders differed but every one reduced
    to this same behavior once the redundant checks were collapsed, so
    adopting this changes no rendered output.

    Parameters
    ----------
    v : float
        The value to label (an axis tick, a tooltip number, ...).

    Returns
    -------
    str
        ``"0"`` for zero; ``"{v:.0f}"`` for any integral value or any
        value ``>= 10``; ``"{v:.1f}"`` for ``1 <= |v| < 10``;
        ``"{v:.2f}"`` for ``0.01 <= |v| < 1``; ``f"{v:g}"`` below that.

    Examples
    --------
    >>> fmt_number(0)
    '0'
    >>> fmt_number(12.3)
    '12'
    >>> fmt_number(4.5)
    '4.5'
    >>> fmt_number(0.031)
    '0.03'
    """
    if v == 0:
        return "0"
    av = abs(v)
    if av == int(av) or av >= 10:
        return f"{v:.0f}"
    if av >= 1:
        return f"{v:.1f}"
    if av >= 0.01:
        return f"{v:.2f}"
    return f"{v:g}"


def fmt_magnitude(v: float, lang: str = "en") -> str:
    """Format a large axis tick compactly: ``1200000`` becomes ``1.2M``.

    Why this exists. :func:`fmt_number` settles *precision* but never
    *magnitude*, so a revenue axis renders ``200000 / 400000 / 600000``. That
    is legible only after counting zeros, which is exactly the work a chart
    exists to remove — found by rendering a real revenue chart and looking at
    it rather than at its code.

    Below ``10_000`` this delegates to :func:`fmt_number` unchanged. Four
    digits and fewer are read at a glance, and a year (``2024``) must never
    become ``2k``.

    Parameters
    ----------
    v : float
        The value to label.
    lang : str
        ``"fr"`` uses the decimal comma and a space before the suffix, as
        French typography requires; anything else keeps the English form.

    Returns
    -------
    str
        A compact label, or :func:`fmt_number`'s output below the threshold.

    Examples
    --------
    >>> fmt_magnitude(1200000)
    '1.2M'
    >>> fmt_magnitude(800000)
    '800k'
    >>> fmt_magnitude(1200000, lang="fr")
    '1,2 M'
    >>> fmt_magnitude(2024)
    '2024'
    >>> fmt_magnitude(-1500000)
    '-1.5M'
    >>> fmt_magnitude(999999)
    '1M'
    """
    av = abs(v)
    if av < 10_000:
        return fmt_number(v)

    # The unit is picked from the value ROUNDED to one decimal, not from the raw
    # value: 999_999 rounds to 1000.0k, which should read "1M" and not "1000k".
    # Comparing before rounding put it one unit too low.
    for seuil, suffixe in ((1e12, "T"), (1e9, "G"), (1e6, "M"), (1e3, "k")):
        if round(av / seuil, 1) >= 1:
            reduit = v / seuil
            # One decimal only when it carries information: 1.2M is worth the
            # character, 1.0M is not.
            # The decimal is judged on the ROUNDED value, not the raw one:
            # 999_999 / 1e6 is 0.999999, which is not integral, yet its label
            # is "1M" and the ".0" carries nothing.
            arrondi = round(reduit, 1)
            texte = f"{reduit:.0f}" if abs(reduit) >= 100 or arrondi == int(arrondi) else f"{reduit:.1f}"
            if lang == "fr":
                return f"{texte.replace('.', ',')} {suffixe}"
            return f"{texte}{suffixe}"
    return fmt_number(v)


def rounded_rect_path(
    x: float, y: float, w: float, h: float,
    r_tl: float = 0.0, r_tr: float = 0.0, r_br: float = 0.0, r_bl: float = 0.0,
) -> str:
    """SVG path ``d`` for a rectangle with per-corner radii (SVG house config
    for the Sprezzature Corner Policy, see references/corners.md).

    Each radius is clamped to half the smaller side so a corner never overshoots.
    Zero-radius corners stay square. Use this (not a plain ``<rect rx>``) whenever
    only *some* corners round — bars, stacked segments, arc-adjacent tiles — so
    baseline and adjacent corners can stay crisp.
    """
    m = min(w, h) / 2.0
    tl, tr, br, bl = (max(0.0, min(v, m)) for v in (r_tl, r_tr, r_br, r_bl))
    f = fmt_compact
    return (
        f"M{f(x + tl)},{f(y)} "
        f"H{f(x + w - tr)} " + (f"A{f(tr)},{f(tr)} 0 0 1 {f(x + w)},{f(y + tr)} " if tr else "")
        + f"V{f(y + h - br)} " + (f"A{f(br)},{f(br)} 0 0 1 {f(x + w - br)},{f(y + h)} " if br else "")
        + f"H{f(x + bl)} " + (f"A{f(bl)},{f(bl)} 0 0 1 {f(x)},{f(y + h - bl)} " if bl else "")
        + f"V{f(y + tl)} " + (f"A{f(tl)},{f(tl)} 0 0 1 {f(x + tl)},{f(y)} " if tl else "")
        + "Z"
    )


def bar_path(x: float, y: float, w: float, h: float, r: float, side: str = "top") -> str:
    """SVG path ``d`` for a bar rounded on its value-end only (policy: the
    baseline corners stay square so the bar sits flat on the axis). ``side`` is
    the value-end: ``top`` / ``bottom`` for columns, ``left`` / ``right`` for
    horizontal bars."""
    sides = {
        "top": (r, r, 0.0, 0.0),
        "bottom": (0.0, 0.0, r, r),
        "right": (0.0, r, r, 0.0),
        "left": (r, 0.0, 0.0, r),
    }
    tl, tr, br, bl = sides.get(side, sides["top"])
    return rounded_rect_path(x, y, w, h, tl, tr, br, bl)


def tooltip_bubble(
    x: float,
    y: float,
    lines: Sequence[str],
    *,
    anchor: str = "middle",
    max_chars: int = 40,
    canvas_w: float | None = None,
    canvas_h: float | None = None,
    bg: str = "#FFFFFF",
    border: str = "#E5E5EA",
    ink: str = "#1D1D1F",
    secondary: str = "#6E6E73",
    font_size: float = 12.5,
    font_family: str = "",
    cls: str = "tip",
    elem_id: str | None = None,
) -> str:
    """Rounded-rect hover-info bubble, auto-sized to its (word-wrapped) content.

    A shared "bubble" for the `.hit:hover~.tip{opacity:1}` pattern several
    generators (and ``case-studies/financial-markets``, ``sprezzature-maps``)
    each hand-rolled slightly differently. This is a genuinely new, common
    capability — not a byte-identical extraction of existing inline code
    (see the module docstring's rule for those) — so callers switching to it
    will see their tooltip pixels change: real word-wrap via
    :func:`wrap_no_orphan` instead of a fixed line list, and canvas-edge
    clamping instead of letting the bubble run off the artboard.

    First line renders bold in `ink` (the headline); the rest render in
    `secondary` (supporting detail) — the convention every existing ad hoc
    tooltip already used.

    Parameters
    ----------
    x, y : float
        Anchor point (the bubble's top edge sits at `y`; horizontal
        position is resolved by `anchor`), in user-space pixels.
    lines : sequence of str
        One entry per logical line. Any entry longer than `max_chars` is
        word-wrapped (never mid-word) into multiple rendered lines.
    anchor : {"start", "middle", "end"}, optional
        Horizontal anchor of `x` relative to the bubble. Mirrors SVG
        `text-anchor` semantics. Defaults to ``"middle"``.
    max_chars : int, optional
        Wrap width in characters per line before word-wrap kicks in.
        Defaults to 40 — comfortable for a `font_size` around 12-13px.
    canvas_w, canvas_h : float or None, optional
        When given, the bubble is clamped (4px margin) to stay fully
        inside `[0, canvas_w] x [0, canvas_h]` — the artboard the caller
        is drawing into — instead of overflowing past a chart's edge.
    bg, border, ink, secondary : str, optional
        Hex colours for the card fill, card stroke, headline text and
        supporting-line text. Pass the caller's own house tokens so the
        bubble matches the current corporate/academic theme.
    font_size : float, optional
        Body text size in px. Also drives the glyph-width estimate used
        to size the card.
    font_family : str, optional
        CSS font stack for the bubble's text. Empty (default) inherits
        whatever `font-family` the enclosing `<svg>` root already set via
        :func:`svg_open` — pass one explicitly only when the bubble must
        differ from the chart's own chrome font.
    cls : str, optional
        CSS class on the wrapping `<g>` (default ``"tip"``, matching the
        house `.hit:hover~.tip` hover-reveal pattern). Give each bubble a
        distinct class only if several coexist under one `.hit` sibling
        selector and must not all reveal together.
    elem_id : str or None, optional
        ``id`` attribute on the wrapping `<g>`. Set this (paired with a
        matching ``id`` on the hover mark, and :func:`foreground_tip_css`
        for the CSS) whenever more than a couple of bubbles can visually
        overlap, e.g. a dense scatter, a hemicycle, a network, a treemap:
        SVG has no z-index, so a bubble drawn right next to its own mark
        is covered by any mark drawn *after* it in the document, no
        matter which one is hovered. The fix is to draw every mark first
        and every bubble last (see :func:`foreground_tip_css`'s
        docstring for the full pattern); once bubbles no longer sit next
        to their own mark, only a unique id pair can still tell the CSS
        which bubble belongs to which mark.

    Returns
    -------
    str
        A `<g>` element: the rounded-rect background plus one `<text>`
        per wrapped line. No positioning side effects — purely a string
        the caller appends into its own `parts` list, exactly like every
        other primitive in this module.
    """
    wrapped: _List[str] = []
    for raw in lines:
        wrapped.extend(wrap_no_orphan(raw, max_chars) if len(raw) > max_chars else [raw])
    if not wrapped:
        wrapped = [""]

    pad = 9.0
    lh = font_size * 1.28
    char_w = font_size * 0.56  # average glyph width heuristic for a Roboto-ish sans at font_size
    fw = max(len(s) for s in wrapped) * char_w + 2 * pad
    fh = lh * len(wrapped) + 2 * pad - (lh - font_size)

    if anchor == "end":
        bx = x - fw
    elif anchor == "start":
        bx = x
    else:
        bx = x - fw / 2.0
    by = y

    if canvas_w is not None:
        bx = max(4.0, min(bx, canvas_w - fw - 4.0))
    if canvas_h is not None:
        by = max(4.0, min(by, canvas_h - fh - 4.0))

    f = fmt_compact
    id_attr = f' id="{elem_id}"' if elem_id else ""
    parts = [
        f'<g{id_attr} class="{cls}">',
        f'<rect x="{f(bx)}" y="{f(by)}" width="{f(fw)}" height="{f(fh)}" rx="9" '
        f'fill="{bg}" stroke="{border}" stroke-width="1.2"/>',
    ]
    ff_attr = f' font-family="{xml_escape(font_family)}"' if font_family else ""
    for i, s in enumerate(wrapped):
        weight = "700" if i == 0 else "400"
        col = ink if i == 0 else secondary
        parts.append(
            f'<text x="{f(bx + pad)}" y="{f(by + pad + font_size + i * lh)}" '
            f'font-size="{f(font_size)}" font-weight="{weight}" fill="{col}"{ff_attr}>'
            f"{xml_escape(s)}</text>"
        )
    parts.append("</g>")
    return "".join(parts)


def foreground_tip_css(count: int, *, mark_prefix: str = "hit", tip_prefix: str = "tip") -> str:
    """CSS that reveals each mark's own bubble, keeping every bubble on top.

    SVG paints strictly in document order and has no z-index: an element
    drawn later always covers one drawn earlier, hover state or not. The
    old, simpler house pattern (a single rule, ``.hit:hover+.tip``) relied
    on each bubble sitting *immediately next to* its own mark, so it broke
    the instant another mark was drawn afterward nearby: hovering a seat
    near the start of a hemicycle, a node near the start of a network,
    could reveal a bubble that every later mark then painted over.

    The fix is a two-part house pattern this function is the second half
    of: (1) the caller draws every mark first, then appends every bubble
    afterward (see :func:`tooltip_bubble`'s ``elem_id``) so the front-most
    bubble is always the hovered one, no matter where in the drawing order
    its own mark sits; (2) because a mark and its bubble are no longer
    next-door neighbours, a *shared* class can no longer tell them apart,
    so each pair needs a unique id (``hit-0``/``tip-0``, ``hit-1``/
    ``tip-1``, ...) and its own CSS rule — this function generates exactly
    that block, one rule per pair, so no caller hand-rolls the loop (or
    drifts from a sibling generator's id-naming) itself.

    Parameters
    ----------
    count : int
        Number of mark/bubble pairs, i.e. ``id="{mark_prefix}-0"`` through
        ``id="{mark_prefix}-{count - 1}"`` and the same range for
        `tip_prefix`. Must match the number of marks actually drawn.
    mark_prefix, tip_prefix : str, optional
        The id stem shared with the caller's own ``id="{mark_prefix}-{i}"``
        marks and ``tooltip_bubble(..., elem_id=f"{tip_prefix}-{i}")``
        bubbles. Defaults ``"hit"``/``"tip"`` match the class names
        already used everywhere for the underlying hover mark (``.hit``)
        and bubble (``.tip``).

    Returns
    -------
    str
        `count` concatenated CSS rules, e.g. for ``count=2``:
        ``"#hit-0:hover~#tip-0,#hit-0:focus~#tip-0{opacity:1}"
        "#hit-1:hover~#tip-1,#hit-1:focus~#tip-1{opacity:1}"``.
        Drop this in place of the old ``.hit:hover+.tip,.hit:focus+.tip
        {opacity:1}`` rule; ``.tip{opacity:0;...}`` and the
        ``prefers-reduced-motion`` override stay as they were.

    Examples
    --------
    >>> foreground_tip_css(2)
    '#hit-0:hover~#tip-0,#hit-0:focus~#tip-0{opacity:1}#hit-1:hover~#tip-1,#hit-1:focus~#tip-1{opacity:1}'
    """
    return "".join(
        f"#{mark_prefix}-{i}:hover~#{tip_prefix}-{i},#{mark_prefix}-{i}:focus~#{tip_prefix}-{i}{{opacity:1}}"
        for i in range(count)
    )


def catmull_rom_beziers(
    pts: Sequence[Tuple[float, float]],
    fmt: Callable[[float], str],
    tension: float = 6.0,
) -> str:
    """Return SVG ``C`` commands for a smooth Catmull-Rom spline through ``pts``.

    The caller has already emitted the ``M`` (or ``M``/``L``) to
    ``pts[0]``; this appends the cubic-Bézier segments that flow through
    every later point. End tangents are clamped to the terminal points so
    the curve neither drifts nor over-shoots off the ends. Below three
    points it degrades to plain ``L`` line-tos, exactly as the inline
    ``_catmull_rom`` did.

    The float formatter is injected (rather than hard-coded) so the
    emitted string is byte-for-byte identical to each caller's private
    copy: the streamgraph, difference-chart and bollinger generators all
    pass :func:`fmt_compact`, so the ``C``/``L`` numbers match what they
    produced before the extraction.

    Parameters
    ----------
    pts : sequence of (float, float)
        The sample points, in pixel coordinates. ``pts[0]`` is assumed to
        have already been emitted by the caller (as an ``M``/``L``).
    fmt : callable
        The float-to-string formatter to apply to every coordinate — the
        caller's own ``_fmt`` (typically :func:`fmt_compact`). Injecting
        it keeps the output identical to the inline code.
    tension : float, optional
        Catmull-Rom denominator; ``6`` is the standard uniform spline.

    Returns
    -------
    str
        A run of SVG ``C`` path commands (a plain line-to run when fewer
        than three points are supplied).
    """
    n = len(pts)
    # Fewer than three points cannot form a spline — fall back to straight
    # line-tos through the tail (the caller already emitted pts[0]).
    if n < 3:
        return "".join(f" L{fmt(x)},{fmt(y)}" for x, y in pts[1:])
    seg = []
    for i in range(n - 1):
        # p0..p3 are the four points the uniform Catmull-Rom segment needs;
        # the ends are clamped (repeat the terminal point) so the curve does
        # not swing past the first/last sample.
        p0 = pts[i - 1] if i > 0 else pts[i]
        p1, p2 = pts[i], pts[i + 1]
        p3 = pts[i + 2] if i + 2 < n else pts[i + 1]
        # Catmull-Rom -> Bézier control points: the tangent at each anchor is
        # the neighbour-difference scaled by 1/tension.
        c1x, c1y = p1[0] + (p2[0] - p0[0]) / tension, p1[1] + (p2[1] - p0[1]) / tension
        c2x, c2y = p2[0] - (p3[0] - p1[0]) / tension, p2[1] - (p3[1] - p1[1]) / tension
        seg.append(
            f" C{fmt(c1x)},{fmt(c1y)} {fmt(c2x)},{fmt(c2y)} {fmt(p2[0])},{fmt(p2[1])}"
        )
    return "".join(seg)


def svg_open(
    width: object,
    height: object,
    title_id: str,
    desc_id: str,
    *,
    font_family: str = "Roboto, system-ui, sans-serif",
    embed_fonts: bool = True,
) -> str:
    """Return the responsive, accessible ``<svg>`` opening tag the figures share.

    Nearly every ``make_<id>.py`` generator opens its document with the *same*
    root element: an explicit ``width``/``height`` for a sensible intrinsic
    size, a ``viewBox="0 0 width height"`` so the graphic scales fluidly to any
    container (this is what makes the SVG **responsive** — a viewer can set
    ``width:100%`` and the coordinates rescale), the house ``font-family``, and
    ``role="img"`` + ``aria-labelledby`` wiring the ``<title>``/``<desc>`` pair
    that follows into one accessible name for screen readers. The ``<title>``
    also surfaces as the browser's native hover tooltip.

    This returns exactly the string those generators assembled inline, so
    adopting it leaves the rendered bytes unchanged. The ``<title>`` and
    ``<desc>`` elements themselves stay in the caller (their text is
    figure-specific); this helper only emits the root tag that references them
    by the two ids passed here.

    Parameters
    ----------
    width : object
        Canvas width in user-space pixels. Stringified as-is (an ``int`` prints
        without a decimal point), matching the inline ``f"{width}"``.
    height : object
        Canvas height in user-space pixels. Stringified as-is.
    title_id : str
        The ``id`` of the ``<title>`` element the caller emits next (e.g.
        ``"vn-title"``); becomes the first token of ``aria-labelledby``.
    desc_id : str
        The ``id`` of the ``<desc>`` element (e.g. ``"vn-desc"``); the second
        ``aria-labelledby`` token.
    font_family : str, optional
        CSS font stack for the whole document. Defaults to the house stack
        ``"Roboto, system-ui, sans-serif"``; pass a different string for the
        (few) generators that inject their own.
    embed_fonts : bool, optional
        When true (the default), the returned string also carries a
        ``<defs><style>@font-face…</style></defs>`` block embedding the
        bundled Roboto + Roboto Mono WOFF2 faces as base64 data URIs (see
        ``sprezzature_figures.fonts``), so the SVG renders the house
        typography correctly wherever it is opened -- no dependency on the
        viewer having Roboto installed. Pass ``False`` for a lighter,
        font-independent tag (e.g. tests, or a caller that already emits
        its own ``<defs>``).

    Returns
    -------
    str
        The ``<svg ...>`` opening tag, optionally followed by an embedded
        ``<defs>`` font block.

    Examples
    --------
    >>> svg_open(800, 600, "vn-title", "vn-desc", embed_fonts=False)
    '<svg xmlns="http://www.w3.org/2000/svg" width="800" height="600" viewBox="0 0 800 600" font-family="Roboto, system-ui, sans-serif" role="img" aria-labelledby="vn-title vn-desc">'
    """
    # One f-string so the emitted bytes match the generators' multi-fragment
    # concatenation exactly; the viewBox mirrors width/height so the graphic
    # scales to its container without distortion.
    tag = (
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" '
        f'height="{height}" viewBox="0 0 {width} {height}" '
        f'font-family="{font_family}" role="img" '
        f'aria-labelledby="{title_id} {desc_id}">'
    )
    if embed_fonts and DEFAULT_SVG_FACES:
        tag += svg_font_defs(DEFAULT_SVG_FACES)
    return tag


#: Canonical viridis anchor stops (position in ``[0, 1]``, ``#RRGGBB``),
#: sampled from the reference colormap: dark purple -> teal -> green ->
#: yellow. Perceptually uniform and colour-vision-deficiency safe by
#: construction (it never relies on a red/green contrast), the standard
#: recommended sequential colormap for scientific figures. Lifted verbatim
#: from ``make_spectrogram.py``'s original ``_VIRIDIS``, the first generator
#: to use it (see that module's history) -- this is now the shared source,
#: and that module imports it rather than keeping its own copy.
VIRIDIS_STOPS: Tuple[Tuple[float, str], ...] = (
    (0.00, "#440154"),
    (0.15, "#472D7B"),
    (0.30, "#3B528B"),
    (0.45, "#2C728E"),
    (0.60, "#21908C"),
    (0.72, "#27AD81"),
    (0.85, "#5DC863"),
    (0.93, "#AADC32"),
    (1.00, "#FDE725"),
)


def color_ramp(t: float, stops: Sequence[Tuple[float, str]]) -> str:
    """Sample a multi-stop sRGB colour ramp at position ``t`` in ``[0, 1]``.

    Linear per-channel interpolation between the two anchor stops that
    bracket ``t``; ``t`` is clamped to ``[0, 1]`` first, so out-of-range
    inputs saturate to the first/last stop rather than raising.

    Parameters
    ----------
    t : float
        Position along the ramp.
    stops : sequence of (float, str)
        Ordered ``(position, "#RRGGBB")`` anchor stops; ``position`` must be
        non-decreasing.

    Returns
    -------
    str
        The interpolated colour as ``#RRGGBB``.

    Examples
    --------
    >>> color_ramp(0.0, VIRIDIS_STOPS)
    '#440154'
    >>> color_ramp(1.0, VIRIDIS_STOPS)
    '#FDE725'
    """
    t = min(1.0, max(0.0, t))
    for (lo_t, lo_c), (hi_t, hi_c) in zip(stops, stops[1:]):
        if lo_t <= t <= hi_t:
            local = (t - lo_t) / (hi_t - lo_t) if hi_t > lo_t else 0.0
            ar, ag, ab = hex_to_rgb(lo_c)
            br, bg, bb = hex_to_rgb(hi_c)
            r = round(ar + (br - ar) * local)
            g = round(ag + (bg - ag) * local)
            b = round(ab + (bb - ab) * local)
            return f"#{r:02X}{g:02X}{b:02X}"
    return stops[-1][1]


def viridis(t: float) -> str:
    """Sample the canonical viridis colormap at position ``t`` in ``[0, 1]``.

    Convenience wrapper around :func:`color_ramp` with :data:`VIRIDIS_STOPS`
    -- the academic theme's sequential ramp (see
    :func:`sprezzature_figures.fonts.chrome_stack_for_theme` for the same
    theme axis applied to fonts). Corporate-theme generators keep their own
    tuned single-hue ramp unchanged; pass ``theme="academic"`` through to
    swap to this one.

    Parameters
    ----------
    t : float
        Position along the ramp (e.g. a normalised data value), clamped to
        ``[0, 1]``.

    Returns
    -------
    str
        The interpolated colour as ``#RRGGBB``.

    Examples
    --------
    >>> viridis(0.0)
    '#440154'
    >>> viridis(1.0)
    '#FDE725'
    """
    return color_ramp(t, VIRIDIS_STOPS)


def hex_to_rgb(hexv: str) -> Tuple[int, int, int]:
    """Convert a ``#RRGGBB`` string to an ``(r, g, b)`` integer triple.

    Strips an optional leading ``#`` then reads the three hex byte pairs.
    Byte-identical to the private ``_hex_to_rgb`` the hexbin-map,
    binned-grid-map and circle-packing generators each carried (one used
    the parameter name ``h``, but the returned triple is the same).

    Parameters
    ----------
    hexv : str
        A colour as ``#RRGGBB`` (the leading ``#`` is optional).

    Returns
    -------
    tuple of int
        The ``(r, g, b)`` channels, each ``0..255``.

    Examples
    --------
    >>> hex_to_rgb("#FF9500")
    (255, 149, 0)
    """
    h = hexv.lstrip("#")
    return int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)


# ──────────────────────────────────────────────────────────────────────────
# from _labels.py
# ──────────────────────────────────────────────────────────────────────────

from typing import List, Optional


# House neutrals used as the two text-contrast anchors.
_INK = "#1D1D1F"
_WHITE = "#FFFFFF"
# Per-character advance as a fraction of the font size. Roboto proportional text
# averages ~0.56; the mono face is wider at ~0.62. Used only to size the cell,
# so a small over-estimate (padding) is safer than an under-estimate (clipping).
_ADVANCE = 0.58
_ADVANCE_MONO = 0.62


def relative_luminance(hex_colour: str) -> float:
    """Return the WCAG relative luminance of ``hex_colour`` in ``[0, 1]``.

    Parameters
    ----------
    hex_colour : str
        A ``#RRGGBB`` colour.

    Returns
    -------
    float
        Relative luminance; ~0 for black, ~1 for white. Used to decide whether
        white or ink text reads better on a given fill.
    """
    r, g, b = (c / 255.0 for c in hex_to_rgb(hex_colour))

    def _lin(c: float) -> float:
        # sRGB → linear light, the WCAG transfer curve.
        return c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4

    return 0.2126 * _lin(r) + 0.7152 * _lin(g) + 0.0722 * _lin(b)


def best_text_colour(fill_hex: str, *, light: str = _WHITE, dark: str = _INK) -> str:
    """Choose the higher-contrast text colour (``light`` or ``dark``) for a fill.

    Parameters
    ----------
    fill_hex : str
        The cell fill the text sits on.
    light, dark : str, optional
        The two candidate text colours (default white and ink).

    Returns
    -------
    str
        Whichever of ``light`` / ``dark`` contrasts better with ``fill_hex``.
        The 0.42 threshold on luminance matches where white stops winning on the
        mid-saturation Apple hues (e.g. Apple Blue → white, Yellow → ink).
    """
    return dark if relative_luminance(fill_hex) > 0.42 else light


def readable_on_white(hex_colour: str, *, max_lum: float = 0.5) -> str:
    """Darken a hue just enough to read as text on white.

    Light house hues (Yellow above all, then Mint / Teal) are too pale to use as
    *text* on a white ground. This blends the colour toward ink in small steps
    until its relative luminance falls to ``max_lum``, so a ``tint`` / ``ghost``
    label keeps its hue identity while staying legible. Colours that are already
    dark enough (Blue, Red, Purple, …) are returned unchanged.

    Parameters
    ----------
    hex_colour : str
        The hue to make readable.
    max_lum : float, optional
        Target upper bound on relative luminance (default 0.5).

    Returns
    -------
    str
        A ``#RRGGBB`` colour at or below ``max_lum`` luminance.
    """
    r, g, b = hex_to_rgb(hex_colour)
    ir, ig, ib = hex_to_rgb(_INK)
    cur = hex_colour
    for _ in range(8):
        if relative_luminance(cur) <= max_lum:
            break
        r = round(r + (ir - r) * 0.25)
        g = round(g + (ig - g) * 0.25)
        b = round(b + (ib - b) * 0.25)
        cur = f"#{r:02X}{g:02X}{b:02X}"
    return cur


def _text_width(text: str, size: float, mono: bool) -> float:
    """Estimate rendered text width in px (slightly generous, to avoid clipping)."""
    return len(text) * size * (_ADVANCE_MONO if mono else _ADVANCE)


def label_cell(
    x: float,
    y: float,
    text: str,
    fill: str,
    *,
    variant: str = "tint",
    size: float = 13.0,
    weight: str = "700",
    anchor: str = "start",
    mono: bool = False,
    keyline: bool = True,
    font: str = "Roboto, system-ui, sans-serif",
    mono_font: str = "Roboto Mono, ui-monospace, monospace",
    text_colour: Optional[str] = None,
    pad_x: Optional[float] = None,
) -> str:
    """Return a rounded "cell around text" as a self-contained SVG ``<g>``.

    The cell is vertically centred on ``y`` and horizontally placed by
    ``anchor`` relative to ``x`` (``start`` = ``x`` is the left edge, ``middle``
    = ``x`` is the centre, ``end`` = ``x`` is the right edge). Its width follows
    the text; its height and corner radius follow the font size (a full pill).

    Parameters
    ----------
    x, y : float
        Anchor point, in user-space pixels (``y`` is the cell's vertical centre).
    text : str
        The label text (escaped internally).
    fill : str
        The input colour that drives the whole cell — the wash, the solid fill or
        the border, depending on ``variant``.
    variant : {'tint', 'solid', 'ghost'}, optional
        The cell style (see the module docstring).
    size : float, optional
        Font size in px; also sets the cell height and radius.
    weight : str, optional
        Font weight for the text.
    anchor : {'start', 'middle', 'end'}, optional
        How ``x`` positions the cell horizontally.
    mono : bool, optional
        Use the monospace face (for numeric values); also widens the sizing.
    keyline : bool, optional
        For ``solid``, draw a thin white keyline so the cell lifts off any
        background. Never a dark ring.
    font, mono_font : str, optional
        Font stacks.
    text_colour : str, optional
        Override the automatic text colour.
    pad_x : float, optional
        Horizontal padding; defaults to ``0.75 * size``.

    Returns
    -------
    str
        An SVG ``<g>`` containing the cell ``<rect>`` and the ``<text>``.
    """
    if variant not in ("tint", "solid", "ghost"):
        raise ValueError(f"unknown variant {variant!r}")
    pad = 0.75 * size if pad_x is None else pad_x
    h = size + 0.8 * size            # comfortable vertical breathing room
    w = _text_width(text, size, mono) + 2 * pad
    rx = h / 2.0                     # full pill

    # Left edge from the anchor.
    if anchor == "middle":
        left = x - w / 2.0
    elif anchor == "end":
        left = x - w
    else:
        left = x
    top = y - h / 2.0
    face = mono_font if mono else font

    # Resolve the three roles (rect fill / rect stroke / text) per variant.
    stroke = ""
    if variant == "tint":
        rect = f'fill="{fill}" fill-opacity="0.14"'
        # Text sits on a near-white wash, so darken pale hues to keep it legible.
        txt = readable_on_white(fill) if text_colour is None else text_colour
    elif variant == "solid":
        rect = f'fill="{fill}"'
        txt = best_text_colour(fill) if text_colour is None else text_colour
        if keyline:
            stroke = f' stroke="{_WHITE}" stroke-width="2"'
    else:  # ghost
        rect = f'fill="{_WHITE}"'
        stroke = f' stroke="{fill}" stroke-width="1.5"'
        txt = readable_on_white(fill) if text_colour is None else text_colour

    def _f(v: float) -> str:
        return f"{v:.1f}".rstrip("0").rstrip(".")

    parts: List[str] = [f'<g transform="translate({_f(left)},{_f(top)})">']
    parts.append(
        f'<rect x="0" y="0" width="{_f(w)}" height="{_f(h)}" rx="{_f(rx)}" '
        f'{rect}{stroke}/>'
    )
    # Vertical baseline nudge: ~0.35·size below centre optically centres the cap
    # height for these UI-scale sizes.
    parts.append(
        f'<text x="{_f(w / 2)}" y="{_f(h / 2 + 0.35 * size)}" text-anchor="middle" '
        f'font-family="{face}" font-size="{_f(size)}" font-weight="{weight}" '
        f'fill="{txt}">{xml_escape(text)}</text>'
    )
    parts.append("</g>")
    return "".join(parts)


# ──────────────────────────────────────────────────────────────────────────
# from _interactive.py
# ──────────────────────────────────────────────────────────────────────────

#: The three supported interactivity modes (see the module docstring).
MODES = ("self-contained", "external", "static")

#: Generic fullscreen script, identical for every figure. No on-canvas icon —
#: the whole figure is the hit target, so it stays clean at thumbnail size.
#: Stands down inside a page-module-managed card (``[data-fs-target]``) and
#: never runs at all inside an ``<img>``-embedded SVG (browsers don't execute
#: scripts there).
#:
#: Three contexts, told apart by ``window.frameElement``:
#:
#: * **Gallery card** (embedded as a live ``<object>``, ``window.parent`` is
#:   the host page, not the lightbox's own object): a click anywhere on the
#:   figure can never bubble to the host page — ``<object>`` is a real,
#:   isolated document. So a click posts a message instead; ``lightbox.js`` in
#:   the web repo opens the modal on receipt. This keeps the card's own
#:   ``pointer-events:auto`` (native hover/``<title>`` tooltips stay live).
#: * **Lightbox's own enlarged object** (``data-lb-obj``): the figure is
#:   already shown at modal size, so a click on it does nothing extra.
#: * **Standalone** (opened as its own file/tab, or inlined outside the
#:   gallery — no ``frameElement`` at all): there is no host page to hand off
#:   to, so a click (or Enter/Space once focused) toggles the browser's own
#:   Fullscreen API directly on the SVG.
_FS_SCRIPT = (
    "(function(){"
    "var me=document.currentScript,svg=me.ownerSVGElement||me.parentNode;"
    # A page module owns this figure (dashboard): let it drive; do nothing here.
    "if(svg.closest&&svg.closest('[data-fs-target]'))return;"
    "var fe=null;try{fe=window.frameElement}catch(err){}"
    "if(fe&&fe.hasAttribute('data-lb-obj'))return;"      # already full-size in the lightbox
    "if(fe&&window.parent!==window){"
    "svg.addEventListener('click',function(){"
    "window.parent.postMessage({szFig:1,type:'open-fullscreen'},'*');"
    "});"
    "return;"
    "}"
    "var req=svg.requestFullscreen||svg.webkitRequestFullscreen;"
    "if(!req)return;"
    "var t=function(){var f=document.fullscreenElement||document.webkitFullscreenElement;"
    "if(f===svg)(document.exitFullscreen||document.webkitExitFullscreen).call(document);"
    "else req.call(svg);};"
    "svg.style.cursor='pointer';"
    "svg.setAttribute('tabindex','0');"
    "svg.addEventListener('click',t);"
    "svg.addEventListener('keydown',function(e){if(e.key==='Enter'||e.key===' '){e.preventDefault();t();}});"
    "})();"
)


def fullscreen_control(
    width: float,
    height: float,
    mode: str = "self-contained",
    *,
    inset: float = 14.0,
) -> str:
    """Return the fullscreen wiring script for a figure, per interactivity mode.

    Append the result just before the closing ``</svg>`` of a generator's
    document. In ``"self-contained"`` mode it is the generic wiring script
    (see :data:`_FS_SCRIPT`) — no on-canvas button, the whole figure is the
    hit target. In ``"external"`` and ``"static"`` modes it is the empty
    string, so nothing ships.

    Parameters
    ----------
    width, height : float
        The SVG canvas size. Unused now that there is no button to place, but
        kept in the signature so the ~90 existing call sites (and any future
        placement need) stay source-compatible.
    mode : str, optional
        One of :data:`MODES`. Defaults to ``"self-contained"``.
    inset : float, optional
        Unused now that there is no button to place; kept for the same
        call-site-compatibility reason as ``width``/``height``.

    Returns
    -------
    str
        The ``<script>`` fragment, or ``""`` for the non-self-contained modes.

    Raises
    ------
    ValueError
        If ``mode`` is not one of :data:`MODES`.

    Examples
    --------
    >>> fullscreen_control(800, 600, "static")
    ''
    >>> fullscreen_control(800, 600, "external")
    ''
    >>> "<script>" in fullscreen_control(800, 600)
    True
    """
    if mode not in MODES:
        raise ValueError(f"mode must be one of {MODES}, got {mode!r}")
    # External mode defers to the page module; static ships no interactivity.
    if mode != "self-contained":
        return ""
    _ = width, height, inset  # kept for call-site compatibility; see docstring.
    return f'<script><![CDATA[{_FS_SCRIPT}]]></script>'


def hover_isolate_css(class_name: str, count: int, *, dim: float = 0.35) -> str:
    """Return the "hover one mark, dim the rest" CSS block shared by figures
    with N repeated marks (bars, bands, arcs, nodes, edges, ...).

    Every hand-authored generator with a small multiple of marks (one per
    category/series/node) wants the same interaction: hovering or focusing
    *any* mark dims all the others so the hovered one reads clearly. Rather
    than every generator hand-writing this CSS block (it was drifting
    slightly differently across files), this is the one shared source.

    Expects each mark to carry both a shared class (``class_name``) and an
    index-suffixed class (``f"{class_name}-{i}"`` for ``i`` in
    ``range(count)``) — e.g. ``class="band band-2"`` for the third band. The
    figure-specific parts (the marks themselves, tooltips, colors) stay in
    the generator; only this interaction pattern is shared.

    Parameters
    ----------
    class_name : str
        The shared class every mark carries (e.g. ``"band"``, ``"node"``).
    count : int
        How many marks there are (indices ``0..count-1``).
    dim : float, optional
        Opacity applied to non-hovered marks while any mark is hovered/focused
        (default ``0.35``).

    Returns
    -------
    str
        A ``<style>``-ready CSS string (no surrounding ``<style>`` tags).

    Examples
    --------
    >>> css = hover_isolate_css("band", 3)
    >>> ".band{transition:opacity .15s ease;}" in css
    True
    >>> "svg:has(.band-2:hover,.band-2:focus) .band-2{opacity:1;}" in css
    True
    """
    per_mark = "".join(
        f"svg:has(.{class_name}-{i}:hover,.{class_name}-{i}:focus) .{class_name}-{i}{{opacity:1;}}"
        for i in range(count)
    )
    return (
        f".{class_name}{{transition:opacity .15s ease;}}"
        f"svg:hover .{class_name},svg:focus-within .{class_name}{{opacity:{dim};}}"
        f"{per_mark}"
        "@media (prefers-reduced-motion: reduce){"
        f".{class_name}{{transition:none;}}"
        "}"
    )



# ──────────────────────────────────────────────────────────────────────────
# Typography
# ──────────────────────────────────────────────────────────────────────────

#: The house stacks. The bundled repo embeds these faces as base64 WOFF2;
#: a kit links them (see GOOGLE_FONTS_IMPORT) and keeps the SVG small.
_THEME_STACKS: Dict[str, Dict[str, str]] = {
    "corporate": {
        "chrome": "Roboto, system-ui, -apple-system, 'Helvetica Neue', Arial, sans-serif",
        "mono": "'Roboto Mono', ui-monospace, SFMono-Regular, Menlo, monospace",
    },
    "academic": {
        "chrome": "'LM Roman', 'Latin Modern Roman', Georgia, 'Times New Roman', serif",
        "mono": "'LM Mono', 'Latin Modern Mono', ui-monospace, Menlo, monospace",
    },
}

#: Pulled from Google Fonts rather than embedded. This only fetches when the
#: SVG *is* the document — opened directly, or embedded via <object> /
#: <iframe>. Inside an <img> tag the browser blocks external requests and the
#: next family in the stack renders instead, which is why every stack above
#: ends in a system face rather than a bare generic.
#:
#: The ampersands are written ``&amp;``, and that is not optional: an SVG is
#: XML, so a bare ``&`` is an unterminated entity reference and the whole
#: document fails to parse. A browser shows "EntityRef: expecting ';'" and
#: renders nothing at all — not a missing font, a blank figure.
GOOGLE_FONTS_IMPORT: str = (
    "@import url('https://fonts.googleapis.com/css2?"
    "family=Roboto:ital,wght@0,100..900;1,100..900&amp;"
    "family=Roboto+Mono:ital,wght@0,100..700;1,100..700&amp;display=swap');"
)

#: Kept for call-signature parity with the repo's font module.
DEFAULT_SVG_FACES: Tuple[str, ...] = ("sans", "mono")


def chrome_stack_for_theme(theme: str = "corporate") -> str:
    """CSS font stack for titles, labels and axis text."""
    return _THEME_STACKS.get(theme, _THEME_STACKS["corporate"])["chrome"]


def mono_stack_for_theme(theme: str = "corporate") -> str:
    """CSS font stack for tick values and numeric labels."""
    return _THEME_STACKS.get(theme, _THEME_STACKS["corporate"])["mono"]


def svg_font_defs(keys: Sequence[str] = DEFAULT_SVG_FACES) -> str:
    """A ``<defs>`` block linking the house faces, ready to splice into an SVG."""
    del keys
    return f"<defs><style>{GOOGLE_FONTS_IMPORT}</style></defs>"


def svg_faces_for_theme(theme: str = "corporate") -> Tuple[str, ...]:
    """Face keys to declare for `theme`. One link covers both stacks here."""
    del theme
    return DEFAULT_SVG_FACES


# ──────────────────────────────────────────────────────────────────────────
# Reading the data
# ──────────────────────────────────────────────────────────────────────────


def load_rows(
    path: "str | Path" = "data.csv",
    *,
    text_columns: Sequence[str] = (),
) -> List[Dict[str, Any]]:
    """
    Read ``data.csv`` back into the row dicts the generator expects.

    Round-trips what :mod:`csv` flattens. Numbers come back as ``int`` or
    ``float`` rather than strings, ``true`` / ``false`` as booleans, an empty
    cell as ``None``, and a cell holding a JSON array or object (a few charts
    carry a list per row — a bullet chart's qualitative bands, a horizon
    chart's series, a set-membership list) is parsed back into that list or
    dict. Anything else stays the string it was.

    Parameters
    ----------
    path : str or pathlib.Path, optional
        CSV to read. Defaults to ``data.csv`` beside the generator.
    text_columns : sequence of str, optional
        Columns to leave as text even when they look numeric. A year used as
        a category label ("2023") is the usual case: CSV cannot distinguish
        it from the number 2023, and the chart wants the label.

    Returns
    -------
    list of dict
        One dict per data row, keyed by the CSV header.
    """
    source = Path(path)
    if not source.is_absolute():
        source = Path(__file__).resolve().parent / source
    keep = set(text_columns)
    with source.open(newline="", encoding="utf-8") as handle:
        return [
            {key: (value if key in keep else _coerce(value)) for key, value in row.items()}
            for row in csv.DictReader(handle)
        ]


def _coerce(raw: "str | None") -> Any:
    """Turn one CSV cell back into the Python value it was written from."""
    if raw is None or raw == "":
        return None
    if raw[0] in "[{":
        try:
            return json.loads(raw)
        except ValueError:
            return raw
    lowered = raw.lower()
    if lowered in ("true", "false"):
        return lowered == "true"
    try:
        return int(raw)
    except ValueError:
        pass
    try:
        return float(raw)
    except ValueError:
        return raw


# ──────────────────────────────────────────────────────────────────────────
# Writing the figure
# ──────────────────────────────────────────────────────────────────────────


def svg_example_path(script_file: str, figure_id: str) -> Path:
    """The default output path: ``<figure_id>.svg`` beside the generator."""
    return Path(script_file).resolve().parent / f"{figure_id}.svg"


def write_svg(out: Path, svg: str, *, embed_fonts: bool = True, theme: str = "corporate") -> Path:
    """
    Write `svg` to `out`, splicing in the font link, and report where it went.

    Parameters
    ----------
    out : pathlib.Path
        Destination ``.svg`` path.
    svg : str
        The complete SVG document.
    embed_fonts : bool, optional
        Add the ``@font-face`` link block when the document has none.
    theme : str, optional
        Accepted for parity with the generators; both themes link the same
        stylesheet here.

    Returns
    -------
    pathlib.Path
        `out` unchanged.
    """
    del theme
    if embed_fonts and "@import" not in svg and svg.lstrip().startswith("<svg"):
        insert_at = svg.index(">") + 1
        svg = svg[:insert_at] + svg_font_defs() + svg[insert_at:]
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(svg, encoding="utf-8")
    print(f"wrote {out}")
    return out


def write_raster_companions(svg: str, script_file: str, figure_id: str, *, zoom: float = 2.0) -> None:
    """
    No-op: a kit ships vector only.

    The repo writes a PNG beside the SVG for places that cannot take vector
    art. Rasterising needs a renderer far outside this kit's dependency
    budget, so the kit stops at the SVG — open it in a browser and use "Save
    as image" if a raster is what you need.
    """
    del svg, script_file, figure_id, zoom


# ──────────────────────────────────────────────────────────────────────────
# the command line, from _render.py
# ──────────────────────────────────────────────────────────────────────────

import argparse
import inspect
import os
from pathlib import Path
from typing import Callable
















def _parse_float_pair(raw: str) -> tuple:
    """Parse a ``"lo,hi"`` CLI value into a ``(float, float)`` domain tuple.

    Used as an :data:`_OPTIONAL_FLAGS` ``type`` for ``x_domain``/``y_domain``
    parameters, whose Python-API shape (a 2-tuple) argparse cannot infer on
    its own.
    """
    lo, hi = raw.split(",")
    return (float(lo), float(hi))


#: Extra ``build_svg`` parameters :func:`render_cli` will expose as flags
#: *when the target generator declares them* — each entry is
#: ``name -> (flag, type, help)``. This is what lets a bespoke-argparse
#: generator move onto :func:`render_cli` without losing a flag it used to
#: define by hand, and lets any generator gain, say, ``--log-y`` for free
#: just by adding a ``log_y: bool = False`` parameter to its ``build_svg``.
_OPTIONAL_FLAGS: dict = {
    "width": ("--width", int, "canvas width in pixels"),
    "height": ("--height", int, "canvas height in pixels"),
    "title": ("--title", str, "chart title (default: the generator's own)"),
    "subtitle": ("--subtitle", str, "chart subtitle (default: the generator's own)"),
    "seed": ("--seed", int, "random seed, for generators with a stochastic demo layout"),
    "bin_count": ("--bin-count", int, "number of histogram bins"),
    "x_label": ("--x-label", str, "x-axis title (default: the generator's own)"),
    "y_label": ("--y-label", str, "y-axis title (default: the generator's own)"),
    "log_x": ("--log-x", "flag", "use a logarithmic x-axis"),
    "log_y": ("--log-y", "flag", "use a logarithmic y-axis"),
    "vmin": ("--vmin", float, "explicit color-scale minimum (default: this call's own data min)"),
    "vmax": ("--vmax", float, "explicit color-scale maximum (default: this call's own data max)"),
    "x_domain": ("--x-domain", _parse_float_pair, "explicit 'lo,hi' x-axis bounds (default: data min/max)"),
    "y_domain": ("--y-domain", _parse_float_pair, "explicit 'lo,hi' y-axis bounds (default: a 0-anchored nice ceiling)"),
    "x_tick_step": ("--x-tick-step", float, "explicit x tick spacing (requires --x-domain)"),
    "y_tick_step": ("--y-tick-step", float, "explicit y tick spacing (requires --y-domain)"),
    "y_minor_step": ("--y-minor-step", float, "unlabeled minor gridline spacing (requires --y-domain)"),
}


def render_cli(
    script_file: str,
    figure_id: str,
    build_svg: Callable[[], str],
    *,
    description: str,
) -> None:
    """Run the standard command line for an SVG generator.

    Wraps the argparse boilerplate the generators shared: a single optional
    ``--out`` argument that defaults to the canonical :func:`svg_example_path`,
    the fixed ``--mode``/``--accessibility``/``--language`` trio, and — new —
    any of :data:`_OPTIONAL_FLAGS` that the target `build_svg` happens to
    declare, followed by a :func:`write_svg` of ``build_svg()``'s result. A
    generator gains a flag automatically by adding the matching keyword
    parameter to its ``build_svg``; nothing else here needs to change. The
    default path and the ``wrote <path>`` output are unchanged from the
    inline version, so behaviour is preserved for every generator that has
    not adopted any of the optional parameters.

    Parameters
    ----------
    script_file : str
        The calling generator's ``__file__`` (used to resolve the default
        output path).
    figure_id : str
        The figure's short identifier; sets both the default file name and the
        wording of the ``--out`` help text.
    build_svg : callable
        Function returning the complete SVG document string, called with
        only the keyword arguments its own signature accepts (see
        :data:`_OPTIONAL_FLAGS`). Called only after arguments parse, so
        ``--help`` stays cheap.
    description : str
        One-line description shown at the top of ``--help``.

    Returns
    -------
    None
        The SVG is written as a side effect; nothing is returned.
    """
    default_out = svg_example_path(script_file, figure_id)
    parser = argparse.ArgumentParser(description=description)
    parser.add_argument(
        "--out",
        type=Path,
        default=default_out,
        help=f"output SVG path (default: the skill's svg-examples/{figure_id}.svg)",
    )
    parser.add_argument(
        "--mode",
        choices=("self-contained", "external", "static"),
        default="self-contained",
        help="interactivity mode of the emitted SVG (default: self-contained)",
    )
    parser.add_argument(
        "--accessibility",
        choices=(
            "universal", "high-contrast", "monochrome",
            "deuteranopia", "protanopia", "tritanopia",
        ),
        default="universal",
        help="palette accessibility level (default: universal, the CVD-safe standard)",
    )
    parser.add_argument(
        "--language",
        choices=("en", "fr"),
        default="en",
        help="chrome-text language for title/subtitle/legend (default: en).",
    )
    params = inspect.signature(build_svg).parameters
    if "theme" in params:
        parser.add_argument(
            "--theme",
            choices=("corporate", "academic"),
            default="corporate",
            help="visual theme: corporate (default, Roboto) or academic (LaTeX-style Latin Modern)",
        )
    # Build lazily (after parsing) so ``--help`` never runs the figure code.
    # Every flag below — fixed trio and optional alike — is passed only to
    # generators whose ``build_svg`` declares the matching parameter, so this
    # helper keeps working unchanged for generators that accept none of them.
    for name, (flag, type_, help_text) in _OPTIONAL_FLAGS.items():
        if name not in params:
            continue
        if type_ == "flag":
            parser.add_argument(flag, action="store_true", help=help_text)
        else:
            default = params[name].default
            parser.add_argument(
                flag, type=type_, default=None,
                help=f"{help_text} (default: {default!r})",
            )
    args = parser.parse_args()
    kwargs = {}
    if "mode" in params:
        kwargs["mode"] = args.mode
    if "accessibility" in params:
        kwargs["accessibility"] = args.accessibility
    if "language" in params:
        kwargs["language"] = args.language
    theme = "corporate"
    if "theme" in params:
        theme = args.theme
        kwargs["theme"] = theme
    for name in _OPTIONAL_FLAGS:
        if name not in params:
            continue
        value = getattr(args, name)
        # A ``None`` optional value means "not passed on the CLI" -- fall
        # through to build_svg's own default rather than overriding it with
        # None. Flags default to False, which is build_svg's default too.
        if value is not None:
            kwargs[name] = value
    write_svg(args.out, build_svg(**kwargs), theme=theme)


if __name__ == "__main__":  # pragma: no cover - smoke check, not a generator
    # This module is a library for the generators, not a generator itself.
    # Running it directly just proves the path helper resolves sensibly.
    print(svg_example_path(__file__, "example"))
