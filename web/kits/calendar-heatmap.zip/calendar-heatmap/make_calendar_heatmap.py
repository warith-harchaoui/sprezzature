#!/usr/bin/env python3
"""
make_calendar-heatmap — a house-styled GitHub-style calendar heatmap as hand-authored SVG.

Encodes a daily count as cell colour on a week-by-day grid: columns are
weeks, rows are the seven days, and each cell's fill is a single
pale-to-navy blue ramp, a monotone lightness sweep so the pattern
survives greyscale and every colour-vision deficiency without a second
encoding. Typical uses: commit activity, daily active users, habit
tracking, any daily count viewed over months at a glance.

This module builds the ``<svg>`` grid by hand. Grid cells
never round (Sprezzature Corner Policy: grids stay square) and every
cell carries a native ``<title>`` tooltip with its exact count.

Author
------
`Warith Harchaoui, Ph.D. <https://www.linkedin.com/in/warith-harchaoui/>`_
"""

from __future__ import annotations

import random
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from sprezzature_svg import fullscreen_control  # noqa: E402
from sprezzature_svg import render_cli, svg_example_path, write_svg  # noqa: E402
from sprezzature_svg import foreground_tip_css, svg_open, tooltip_bubble, viridis, xml_escape  # noqa: E402
from sprezzature_svg import BG, GRIDLINE, INK, SECONDARY  # noqa: E402
from sprezzature_svg import chrome_stack_for_theme  # noqa: E402


DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]

# Sequential blue ramp — pale sky -> system blue -> deep navy, mono-hue so
# magnitude reads by lightness alone (same ramp make_heatmap.py uses).
_RAMP: Tuple[Tuple[float, str], ...] = (
    (0.00, "#EAF3FF"),
    (0.62, "#007AFF"),
    (1.00, "#0A4DA0"),
)


def _ramp_hex(t: float, theme: str = "corporate") -> str:
    """Sample the sequential ramp at position ``t`` in ``[0, 1]``.

    ``theme="academic"`` swaps to the shared viridis colormap
    (:func:`_svg.viridis`); the default (``"corporate"``) keeps this
    generator's own tuned blue ramp, unchanged.
    """
    if theme == "academic":
        return viridis(t)
    t = min(1.0, max(0.0, t))
    for (lo_t, lo_c), (hi_t, hi_c) in zip(_RAMP, _RAMP[1:]):
        if lo_t <= t <= hi_t:
            local = (t - lo_t) / (hi_t - lo_t) if hi_t > lo_t else 0.0
            ar, ag, ab = int(lo_c[1:3], 16), int(lo_c[3:5], 16), int(lo_c[5:7], 16)
            br, bg, bb = int(hi_c[1:3], 16), int(hi_c[3:5], 16), int(hi_c[5:7], 16)
            r = round(ar + (br - ar) * local)
            g = round(ag + (bg - ag) * local)
            b = round(ab + (bb - ab) * local)
            return f"#{r:02X}{g:02X}{b:02X}"
    return _RAMP[-1][1]


def _make_demo_data() -> List[Dict[str, Any]]:
    rng = random.Random(5)
    rows: List[Dict[str, Any]] = []
    for week in range(18):
        for dow, day in enumerate(DAYS):
            is_weekend = dow >= 5
            base = 2 if is_weekend else 6
            spike = 5 if rng.random() < 0.12 else 0
            rows.append({"week": week, "day": day, "count": max(0, round(rng.gauss(base, 2.2) + spike))})
    return rows


DEMO_DATA: List[Dict[str, Any]] = _make_demo_data()


def build_svg(
    data: Optional[List[Dict[str, Any]]] = None,
    title: str = "Daily Activity",
    subtitle: str = "Events per day over 18 weeks",
    width: int = 620,
    height: int = 300,
    mode: str = "self-contained",
    accessibility: str = "universal",
    theme: str = "corporate",
    week_prefix: str = "Wk ",
    scale_low_label: str = "Less",
    scale_high_label: str = "More",
) -> str:
    """Assemble the full calendar heatmap SVG document as a string.

    Parameters
    ----------
    data : list of dict or None
        Rows with keys ``week`` (int), ``day`` (str, Mon-Sun), ``count``
        (numeric). Defaults to :data:`DEMO_DATA`.
    title, subtitle : str
        Chart text.
    width, height : int
        Canvas size in pixels.
    mode : str, optional
        Forwarded to :func:`_interactive.fullscreen_control`.
    accessibility : str, optional
        Accepted for CLI parity but a documented no-op: the ramp is a
        single mono-hue blue scale, already colour-vision-deficiency-safe
        by construction (magnitude reads by lightness alone).
    theme : str, optional
        Visual theme: ``"corporate"`` (default, Roboto -- byte-identical to
        the pre-theme render) or ``"academic"`` (LaTeX-style Latin Modern).
        See :func:`sprezzature_figures.fonts.chrome_stack_for_theme`.

    Returns
    -------
    str
        A complete, standalone SVG document.
    """
    _ = accessibility
    rows = data if data else DEMO_DATA
    weeks = sorted({int(r["week"]) for r in rows})
    lookup: Dict[Tuple[int, str], float] = {(int(r["week"]), r["day"]): float(r["count"]) for r in rows}
    max_val = max(lookup.values()) if lookup else 1.0

    plot_x, plot_y = 76.0, 96.0
    right_margin, bottom_reserved = 24.0, 60.0
    plot_w = width - plot_x - right_margin
    plot_h = height - plot_y - bottom_reserved
    n_weeks = len(weeks)
    cell_w = plot_w / n_weeks if n_weeks else plot_w
    cell_h = plot_h / len(DAYS)
    gap = min(cell_w, cell_h) * 0.14

    parts: List[str] = []
    parts.append(svg_open(width, height, "cal-title", "cal-desc", font_family=chrome_stack_for_theme(theme)))
    parts.append(f'<title id="cal-title">{xml_escape(title)}</title>')
    total = sum(lookup.values())
    parts.append(
        f'<desc id="cal-desc">Calendar heatmap over {n_weeks} weeks, {total:,.0f} events total, '
        f'busiest day {max_val:.0f}. Hover or focus a cell for its exact count.</desc>'
    )
    parts.append(
        "<style>"
        ".cell{transition:stroke-width .1s ease;}"
        ".cell:hover,.cell:focus{stroke:#1D1D1F;stroke-width:1.5;outline:none;}"
        ".tip{opacity:0;pointer-events:none;transition:opacity .12s ease}"
        + foreground_tip_css(len(weeks) * len(DAYS)) +
        "@media (prefers-reduced-motion: reduce){.cell{transition:none;}"
        ".tip{transition:none}}"
        "</style>"
    )
    parts.append(f'<rect width="{width}" height="{height}" fill="{BG}"/>')
    parts.append(
        f'<text x="40" y="42" font-size="20" font-weight="700" fill="{INK}" '
        f'letter-spacing="-0.3">{xml_escape(title)}</text>'
    )
    parts.append(f'<text x="40" y="64" font-size="13" fill="{SECONDARY}">{xml_escape(subtitle)}</text>')

    # ---- day-of-week row labels (Mon/Wed/Fri only, GitHub convention) ----
    for di, day in enumerate(DAYS):
        if day not in ("Mon", "Wed", "Fri"):
            continue
        ty = plot_y + di * cell_h + cell_h / 2 + 4
        parts.append(
            f'<text x="{plot_x - 10:.1f}" y="{ty:.1f}" font-size="11" fill="{SECONDARY}" '
            f'text-anchor="end">{xml_escape(day)}</text>'
        )

    # ---- week-index column labels ----
    # The data model carries only a ``week`` index, not a real calendar date
    # (see the ``data`` parameter docs), so this generator cannot show real
    # month names the way GitHub's contribution graph does -- doing so would
    # mean fabricating dates the caller never supplied. What it *can* give a
    # reader is which of the n_weeks columns they're looking at, so the chart
    # isn't left with zero temporal reference across its horizontal axis.
    # Every 4th week (~monthly cadence) plus the last, mirroring the sparse
    # month-label spacing convention without inventing month names.
    label_weeks = list(range(0, n_weeks, 4)) if n_weeks else []
    # Only tack on the final week if it isn't crowding the previous label
    # (e.g. 18 weeks: periodic labels land on 1/5/9/13/17 -- 18 would sit
    # right next to 17 and collide).
    if n_weeks and (not label_weeks or n_weeks - 1 - label_weeks[-1] >= 2):
        label_weeks.append(n_weeks - 1)
    for wi in label_weeks:
        tx = plot_x + wi * cell_w + cell_w / 2
        parts.append(
            f'<text x="{tx:.1f}" y="{plot_y - 8:.1f}" font-size="10" fill="{SECONDARY}" '
            f'text-anchor="middle">{xml_escape(week_prefix)}{weeks[wi] + 1}</text>'
        )

    # ---- cells (grid marks: never rounded, per Sprezzature Corner Policy) ----
    # Every cell is drawn first, then every hover card is appended afterward
    # (see _svg.foreground_tip_css): SVG paints in document order regardless
    # of hover state, so a card sitting right next to its own cell would be
    # covered by any cell drawn later in the grid.
    tip_cards: List[str] = []
    idx = 0
    for wi, week in enumerate(weeks):
        for di, day in enumerate(DAYS):
            count = lookup.get((week, day), 0.0)
            t = count / max_val if max_val else 0.0
            x = plot_x + wi * cell_w + gap / 2
            y = plot_y + di * cell_h + gap / 2
            w = cell_w - gap
            h = cell_h - gap
            tip = f"Week {week + 1}, {day}: {count:.0f} events"
            parts.append(
                f'<rect id="hit-{idx}" class="cell hit" tabindex="0" x="{x:.1f}" y="{y:.1f}" width="{w:.1f}" height="{h:.1f}" '
                f'fill="{_ramp_hex(t, theme)}" stroke="{BG}" stroke-width="1">'
                f'<title>{xml_escape(tip)}</title></rect>'
            )
            share = count / total * 100.0 if total else 0.0
            tip_cards.append(
                tooltip_bubble(
                    x + w / 2, y - 6,
                    [f"Week {week + 1}, {day}", f"{count:.0f} events", f"{share:.1f}% of total"],
                    anchor="middle", canvas_w=width, canvas_h=height,
                    ink=INK, secondary=SECONDARY, border=GRIDLINE,
                    elem_id=f"tip-{idx}",
                )
            )
            idx += 1
    parts.extend(tip_cards)

    # ---- legend: Less -> More ramp swatches ----
    ly = height - 28.0
    parts.append(f'<text x="{plot_x:.1f}" y="{ly:.1f}" font-size="11" fill="{SECONDARY}">{xml_escape(scale_low_label)}</text>')
    swatch_x = plot_x + 34.0
    for i in range(5):
        t = i / 4.0
        parts.append(f'<rect x="{swatch_x + i * 16:.1f}" y="{ly - 11:.1f}" width="12" height="12" fill="{_ramp_hex(t, theme)}"/>')
    parts.append(f'<text x="{swatch_x + 5 * 16 + 8:.1f}" y="{ly:.1f}" font-size="11" fill="{SECONDARY}">{xml_escape(scale_high_label)}</text>')

    parts.append(fullscreen_control(width, height, mode))
    parts.append("</svg>")
    return "\n".join(parts)


def make_calendar_heatmap(
    data: Optional[List[Dict[str, Any]]] = None,
    *,
    out: Optional[Path | str] = None,
    title: str = "Daily Activity",
    subtitle: str = "Events per day over 18 weeks",
    width: int = 620,
    height: int = 300,
    mode: str = "self-contained",
    accessibility: str = "universal",
    theme: str = "corporate",
    week_prefix: str = "Wk ",
    scale_low_label: str = "Less",
    scale_high_label: str = "More",
) -> Path:
    """Render a hand-authored calendar heatmap and write the SVG to *out*.

    Parameters
    ----------
    data : list[dict[str, Any]] or None
        Rows with keys ``week`` (int), ``day`` (str), ``count`` (float).
        Defaults to DEMO_DATA.
    out : Path, str, or None
        Output path (.svg). Defaults to
        ``assets/svg-examples/calendar-heatmap.svg``.
    title, subtitle : str
        Chart text.
    width, height : int
        Canvas size in pixels.
    mode, accessibility : str
        Forwarded to :func:`build_svg`.
    theme : str, optional
        Visual theme. Forwarded to :func:`build_svg`.

    Returns
    -------
    Path
        Absolute path to the written SVG file.

    Examples
    --------
    >>> p = make_calendar_heatmap()
    >>> p.exists()
    True
    """
    svg = build_svg(data, title=title, subtitle=subtitle, width=width, height=height,
                     mode=mode, accessibility=accessibility, theme=theme, week_prefix=week_prefix, scale_low_label=scale_low_label, scale_high_label=scale_high_label)
    dest = Path(out) if out else svg_example_path(__file__, "calendar-heatmap")
    return write_svg(dest, svg, theme=theme)


def main() -> None:
    """CLI entry point: build the SVG and write it to disk."""
    render_cli(__file__, "calendar-heatmap", build_svg, description="Generate a GitHub-style calendar heatmap.")



# ── kit: the data comes from data.csv ─────────────────────────────────────
# The generator keeps its own DEMO_DATA above as a fallback and as a record
# of the expected column names. When data.csv is present (it ships with this
# kit), it wins: edit the CSV, re-run this file, and the figure changes.
from sprezzature_svg import load_rows  # noqa: E402

try:
    DEMO_DATA = load_rows("data.csv") or DEMO_DATA
except FileNotFoundError:
    pass


if __name__ == "__main__":
    main()
