#!/usr/bin/env python3
"""
make_columnrange — a house-styled range (floating bar) chart as hand-authored SVG.

A column-range chart, also called a floating bar or range chart, draws a
vertical bar for each category from a low value to a high value rather than
from zero to a single value. It communicates an interval, not an absolute
quantity. Typical uses: temperature ranges by month, confidence intervals
for survey estimates, salary bands by role, and any situation where the
viewer needs to compare spans rather than point values.

This module builds the ``<svg>`` markup by hand, so every floating
bar carries a native ``<title>`` tooltip and rounds both free ends per the
Sprezzature Corner Policy (a range bar has no baseline, both ends are free).

Author
------
`Warith Harchaoui, Ph.D. <https://www.linkedin.com/in/warith-harchaoui/>`_
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

from sprezzature_svg import fullscreen_control  # noqa: E402
from sprezzature_svg import render_cli, svg_example_path, write_svg  # noqa: E402
from sprezzature_svg import nice_ticks_range  # noqa: E402
from sprezzature_svg import BG, GRIDLINE, INK, SECONDARY, cycle_hues  # noqa: E402
from sprezzature_svg import foreground_tip_css, svg_open, tooltip_bubble, xml_escape  # noqa: E402
from sprezzature_svg import chrome_stack_for_theme, mono_stack_for_theme  # noqa: E402


MONTHS = ["Jan", "Apr", "Jul", "Oct"]
CITIES = ["Madrid", "Berlin", "Lisbon", "Stockholm", "Athens"]

DEMO_DATA: List[Dict[str, Any]] = [
    {"city": "Madrid", "month": "Jan", "low": 2, "high": 11, "sort": 1},
    {"city": "Madrid", "month": "Apr", "low": 8, "high": 18, "sort": 4},
    {"city": "Madrid", "month": "Jul", "low": 18, "high": 33, "sort": 7},
    {"city": "Madrid", "month": "Oct", "low": 10, "high": 21, "sort": 10},
    {"city": "Berlin", "month": "Jan", "low": -3, "high": 3, "sort": 1},
    {"city": "Berlin", "month": "Apr", "low": 4, "high": 14, "sort": 4},
    {"city": "Berlin", "month": "Jul", "low": 14, "high": 24, "sort": 7},
    {"city": "Berlin", "month": "Oct", "low": 6, "high": 14, "sort": 10},
    {"city": "Lisbon", "month": "Jan", "low": 8, "high": 15, "sort": 1},
    {"city": "Lisbon", "month": "Apr", "low": 12, "high": 21, "sort": 4},
    {"city": "Lisbon", "month": "Jul", "low": 19, "high": 29, "sort": 7},
    {"city": "Lisbon", "month": "Oct", "low": 14, "high": 23, "sort": 10},
    {"city": "Stockholm", "month": "Jan", "low": -5, "high": 1, "sort": 1},
    {"city": "Stockholm", "month": "Apr", "low": 2, "high": 11, "sort": 4},
    {"city": "Stockholm", "month": "Jul", "low": 13, "high": 22, "sort": 7},
    {"city": "Stockholm", "month": "Oct", "low": 4, "high": 10, "sort": 10},
    {"city": "Athens", "month": "Jan", "low": 6, "high": 14, "sort": 1},
    {"city": "Athens", "month": "Apr", "low": 11, "high": 22, "sort": 4},
    {"city": "Athens", "month": "Jul", "low": 22, "high": 34, "sort": 7},
    {"city": "Athens", "month": "Oct", "low": 15, "high": 25, "sort": 10},
]


def _city_colors(
    cities: List[str], accessibility: str = "universal", theme: str = "corporate"
) -> Dict[str, str]:
    return cycle_hues(cities, accessibility, hues=['Blue', 'Purple', 'Green', 'Orange', 'Red'], theme=theme)


def build_svg(
    data: Optional[List[Dict[str, Any]]] = None,
    title: str = "Monthly Temperature Range by City",
    subtitle: str = "",
    y_axis_title: str = "Value",
    x_axis_title: str = "Month",
    legend_title: str = "Series",
    unit: str = "",
    width: int = 845,
    height: int = 519,
    mode: str = "self-contained",
    accessibility: str = "universal",
    theme: str = "corporate",
) -> str:
    """Assemble the full column-range chart SVG document as a string.

    Parameters
    ----------
    data : list of dict or None
        Rows with keys ``city`` (the series/group label — despite the name,
        any grouping category, not necessarily a city), ``month`` (the
        x-axis position label — any ordered category, not necessarily a
        calendar month), ``low``, ``high``, and optionally ``sort`` (an
        orderable key controlling x-axis position; falls back to calendar-
        month ordering when every row omits it, for :data:`DEMO_DATA`
        backward compatibility). Defaults to :data:`DEMO_DATA`.
    title, subtitle : str
        Chart text. ``subtitle`` defaults to empty — the original hardcoded
        weather caption ("Mean daily low to mean daily high...") leaked into
        every non-weather chart until this was generalised; pass it
        explicitly when actually plotting temperature ranges.
    y_axis_title : str
        Y-axis label (was hardcoded ``"Temperature (°C)"``).
    legend_title : str
        Legend header above the series swatches (was hardcoded ``"City"``).
    x_axis_title : str
        X-axis label under the group ticks. Defaults to ``"Month"`` (the
        historical default, since ``month`` is still the row key for x-axis
        position); pass an explicit label when the x-axis is not calendar
        months.
    unit : str
        Appended to values in tooltips/hover cards (e.g. ``"°C"``, ``"€"``).
        Empty by default (was hardcoded ``"°C"``).
    width, height : int
        Canvas size in pixels.
    mode, accessibility : str, optional
        Forwarded to :func:`_interactive.fullscreen_control` /
        :func:`_style.load_palette`.
    theme : str, optional
        Visual theme: ``"corporate"`` (default, Roboto -- byte-identical to
        the pre-theme render) or ``"academic"`` (LaTeX-style Latin Modern).
        See :func:`sprezzature_figures.fonts.chrome_stack_for_theme`.

    Returns
    -------
    str
        A complete, standalone SVG document.
    """
    mono_family = mono_stack_for_theme(theme)
    rows = data if data else DEMO_DATA
    if data is None:
        # DEMO_DATA is specifically European city temperature ranges — fill
        # in the weather-flavoured captions when the caller didn't override
        # them, rather than showing an empty subtitle/generic "Value"/unit-
        # less tooltip on the one dataset where the domain-specific text is
        # actually correct. Any caller passing real `data` gets the general
        # defaults untouched.
        subtitle = subtitle or "Mean daily low to mean daily high, degrees Celsius, 30-year climate normal"
        if y_axis_title == "Value":
            y_axis_title = "Temperature (°C)"
        if legend_title == "Series":
            legend_title = "City"
        unit = unit or "°C"
    seen_cities: List[str] = []
    for r in rows:
        if r["city"] not in seen_cities:
            seen_cities.append(r["city"])
    cities = [c for c in CITIES if c in seen_cities] + [c for c in seen_cities if c not in CITIES]
    if rows and all("sort" in r for r in rows):
        # Real ordering key, not a guess: without it, any x-axis label outside
        # the demo's ["Jan","Apr","Jul","Oct"] silently sorted by dict/set
        # iteration order (Python's set has no defined order) — reproduced
        # for real with ISO date labels ("2026-07-01" etc.), rendered as
        # Jul/Sep/Aug instead of Jul/Aug/Sep.
        sort_by_month = {r["month"]: r["sort"] for r in rows}
        months = sorted({r["month"] for r in rows}, key=lambda m: sort_by_month[m])
    else:
        months = sorted({r["month"] for r in rows}, key=lambda m: MONTHS.index(m) if m in MONTHS else 0)
    colors = _city_colors(cities, accessibility, theme=theme)

    lookup: Dict[tuple, tuple] = {(r["city"], r["month"]): (float(r["low"]), float(r["high"])) for r in rows}
    lows = [v[0] for v in lookup.values()]
    highs = [v[1] for v in lookup.values()]
    y_min, y_max = min(lows), max(highs)
    pad = (y_max - y_min) * 0.08
    y0, y1 = y_min - pad, y_max + pad

    # Left margin sized to the actual tick labels, not a fixed 60px: a fixed
    # margin fit "Temperature (°C)" + 2-3 digit values, but collided with the
    # rotated y-axis title on wide values (6-digit currency amounts) —
    # reproduced for real (data_dataviz.py::_columnrange_data, sev7n) with
    # "300000"-style labels overlapping "Chiffre d'affaires (€)". Computed
    # once here (reused below for the actual gridlines) rather than after
    # plot_x is already fixed.
    y_tick_vals = [t for t in nice_ticks_range(y0, y1, n=6) if y0 - 1e-9 <= t <= y1 + 1e-9]
    max_tick_chars = max((len(f"{v:.0f}") for v in y_tick_vals), default=4)
    tick_label_w = max_tick_chars * 6.5  # ~monospace digit width at font-size 11
    title_band_w = 24.0  # rotated y-axis title occupies a narrow vertical band, not zero-width
    plot_x = max(60.0, title_band_w + tick_label_w + 16.0)
    plot_y = 150.0
    right_margin, bottom_reserved = 30.0, 70.0
    plot_w = width - plot_x - right_margin
    plot_h = height - plot_y - bottom_reserved
    n_groups = len(months)
    group_w = plot_w / n_groups if n_groups else plot_w
    bar_w = max(3.0, group_w / (len(cities) + 1.4))

    def y_for(v: float) -> float:
        return plot_y + plot_h - (v - y0) / (y1 - y0) * plot_h

    parts: List[str] = []
    parts.append(svg_open(width, height, "cr-title", "cr-desc", font_family=chrome_stack_for_theme(theme)))
    parts.append(f'<title id="cr-title">{xml_escape(title)}</title>')
    parts.append(
        f'<desc id="cr-desc">Floating-bar range chart of {len(cities)} series across '
        f'{n_groups} positions, each bar spanning its low to high value{" in " + unit if unit else ""}. '
        f'Range: {y_min:.0f} to {y_max:.0f}.</desc>'
    )

    parts.append(
        "<style>"
        ".rangebar{transition:filter .15s ease;}"
        ".rangebar:hover,.rangebar:focus{filter:brightness(1.1);outline:none;}"
        ".tip{opacity:0;pointer-events:none;transition:opacity .12s ease}"
        + foreground_tip_css(len(months) * len(cities)) +
        "@media (prefers-reduced-motion: reduce){.rangebar{transition:none;}"
        ".tip{transition:none}}"
        "</style>"
    )

    parts.append(f'<rect width="{width}" height="{height}" fill="{BG}"/>')
    parts.append(
        f'<text x="40" y="46" font-size="24" font-weight="700" fill="{INK}" '
        f'letter-spacing="-0.3">{xml_escape(title)}</text>'
    )
    parts.append(f'<text x="40" y="70" font-size="14" fill="{SECONDARY}">{xml_escape(subtitle)}</text>')

    # ---- legend ----
    lx, ly = 40.0, 100.0
    parts.append(f'<text x="{lx:.1f}" y="{ly:.1f}" font-size="13" font-weight="700" fill="{INK}">{xml_escape(legend_title)}</text>')
    cursor = lx
    ly2 = ly + 22
    for c in cities:
        parts.append(
            f'<rect x="{cursor:.1f}" y="{ly2 - 11:.1f}" width="12" height="12" rx="2" fill="{colors[c]}"/>'
        )
        parts.append(f'<text x="{cursor + 18:.1f}" y="{ly2:.1f}" font-size="12" fill="{INK}">{xml_escape(c)}</text>')
        cursor += 18 + 7.2 * len(c) + 20

    # ---- y-axis gridlines ----
    # y_tick_vals computed earlier (alongside plot_x sizing) — nice round
    # tick values (see _scale.nice_ticks_range) instead of raw sixths of the
    # padded [y0, y1] span, which produced labels like -8/-1/7/14/22/30/37.
    for val in y_tick_vals:
        ty = y_for(val)
        parts.append(
            f'<line x1="{plot_x:.1f}" y1="{ty:.1f}" x2="{plot_x + plot_w:.1f}" y2="{ty:.1f}" '
            f'stroke="{GRIDLINE}" stroke-width="1"/>'
        )
        parts.append(
            f'<text x="{plot_x - 10:.1f}" y="{ty + 4:.1f}" font-size="11" font-family="{mono_family}" '
            f'fill="{SECONDARY}" text-anchor="end">{val:.0f}</text>'
        )
    parts.append(
        f'<text x="18" y="{plot_y + plot_h / 2:.1f}" font-size="13" fill="{INK}" '
        f'text-anchor="middle" transform="rotate(-90 18 {plot_y + plot_h / 2:.1f})">'
        f'{xml_escape(y_axis_title)}</text>'
    )

    # ---- floating bars, grouped by month ----
    # Every bar is drawn first, then every hover card is appended
    # afterward (see _svg.foreground_tip_css): SVG paints in document
    # order regardless of hover state, so a card sitting right next to its
    # own bar would be covered by any bar drawn later.
    tip_cards: List[str] = []
    idx = 0
    for gi, m in enumerate(months):
        group_x0 = plot_x + gi * group_w
        offset0 = (group_w - bar_w * len(cities)) / 2
        for ci, c in enumerate(cities):
            low, high = lookup.get((c, m), (0.0, 0.0))
            x = group_x0 + offset0 + ci * bar_w
            y_top, y_bot = y_for(high), y_for(low)
            h = max(1.0, y_bot - y_top)
            r = min(bar_w / 2.0, 4.0)
            tip = f"{c}, {m}: {low:.0f}{unit} to {high:.0f}{unit}"
            parts.append(
                f'<rect id="hit-{idx}" class="rangebar hit" tabindex="0" x="{x:.1f}" y="{y_top:.1f}" '
                f'width="{bar_w:.1f}" height="{h:.1f}" rx="{r:.1f}" '
                f'fill="{colors[c]}" fill-opacity="0.85"><title>{xml_escape(tip)}</title></rect>'
            )
            tip_cards.append(
                tooltip_bubble(
                    x + bar_w / 2, y_top - 10,
                    [f"{c}, {m}", f"low {low:.0f}{unit} — high {high:.0f}{unit}", f"span {high - low:.0f}{unit}"],
                    anchor="middle", canvas_w=width, canvas_h=height,
                    ink=INK, secondary=SECONDARY, border=GRIDLINE,
                    elem_id=f"tip-{idx}",
                )
            )
            idx += 1
    parts.extend(tip_cards)

    # ---- x-axis (month group labels) ----
    axis_y = plot_y + plot_h
    parts.append(
        f'<line x1="{plot_x:.1f}" y1="{axis_y:.1f}" x2="{plot_x + plot_w:.1f}" y2="{axis_y:.1f}" '
        f'stroke="{INK}" stroke-width="1.2"/>'
    )
    for gi, m in enumerate(months):
        tx = plot_x + gi * group_w + group_w / 2
        parts.append(
            f'<text x="{tx:.1f}" y="{axis_y + 20:.1f}" font-size="13" fill="{INK}" '
            f'text-anchor="middle">{xml_escape(m)}</text>'
        )
    parts.append(
        f'<text x="{plot_x + plot_w / 2:.1f}" y="{axis_y + 44:.1f}" font-size="13" '
        f'fill="{INK}" text-anchor="middle">{xml_escape(x_axis_title)}</text>'
    )

    parts.append(fullscreen_control(width, height, mode))
    parts.append("</svg>")
    return "\n".join(parts)


def make_columnrange(
    data: Optional[List[Dict[str, Any]]] = None,
    *,
    out: Optional[Path | str] = None,
    title: str = "Monthly Temperature Range by City",
    subtitle: str = "",
    y_axis_title: str = "Value",
    x_axis_title: str = "Month",
    legend_title: str = "Series",
    unit: str = "",
    width: int = 845,
    height: int = 519,
    mode: str = "self-contained",
    accessibility: str = "universal",
    theme: str = "corporate",
) -> Path:
    """Render a hand-authored column-range chart and write the SVG to *out*.

    Parameters
    ----------
    data : list[dict[str, Any]] or None
        Rows with keys ``city``, ``month``, ``low``, ``high``, optionally
        ``sort``. Defaults to DEMO_DATA (European city temperature ranges).
    out : Path, str, or None
        Output path (.svg). Defaults to ``assets/svg-examples/columnrange.svg``.
    title, subtitle : str
        Chart text. ``subtitle`` defaults to empty (see :func:`build_svg`).
    y_axis_title, x_axis_title, legend_title, unit : str
        Forwarded to :func:`build_svg` — see there for the generalisation
        this makes over the original weather-only hardcoded strings.
    width, height : int
        Canvas size in pixels.
    mode, accessibility : str
        Forwarded to :func:`build_svg`.
    theme : str, optional
        Visual theme. Forwarded to :func:`build_svg`.

    Returns
    -------
    Path
        Absolute path to the written SVG file.

    Examples
    --------
    >>> p = make_columnrange()
    >>> p.exists()
    True
    """
    svg = build_svg(data, title=title, subtitle=subtitle, y_axis_title=y_axis_title,
                     x_axis_title=x_axis_title, legend_title=legend_title, unit=unit,
                     width=width, height=height, mode=mode, accessibility=accessibility, theme=theme)
    dest = Path(out) if out else svg_example_path(__file__, "columnrange")
    return write_svg(dest, svg, theme=theme)


def main() -> None:
    """CLI entry point: build the SVG and write it to disk."""
    render_cli(__file__, "columnrange", build_svg, description="Generate a column-range (floating bar) chart.")



# ── kit: the data comes from data.csv ─────────────────────────────────────
# The generator keeps its own DEMO_DATA above as a fallback and as a record
# of the expected column names. When data.csv is present (it ships with this
# kit), it wins: edit the CSV, re-run this file, and the figure changes.
from sprezzature_svg import load_rows  # noqa: E402

try:
    DEMO_DATA = load_rows("data.csv") or DEMO_DATA
except FileNotFoundError:
    pass


if __name__ == "__main__":
    main()
