#!/usr/bin/env python3
"""
make_dotplot — a Wilkinson dot plot rendered as a hand-authored SVG.

A **Wilkinson dot plot** shows one dot per observation, binned into
equal-width intervals along the value axis and stacked vertically
within each bin (Wilkinson, *The American Statistician*, 1999). Unlike
a histogram, every data point stays visible: the reader can count
individual observations, and the silhouette still reveals the shape of
the distribution. It shines for small-to-medium samples (a few dozen
observations) where a histogram's bars would hide the sample size.

This generator builds the SVG string by hand so the binning and
stacking geometry is fully under our control, and matches the sprezzature-* house style: Roboto, the
Apple-ish palette, rounded corners, ink ``#1D1D1F``, secondary
``#6E6E73``, white background. The figure is a **static** poster-size
panel: a Wilkinson dot plot already shows the whole distribution in a
single still, so no motion is added (it would reveal nothing a reader
cannot already see). Each dot carries a native ``<title>`` tooltip.

The final artifact is always an SVG written to
``sprezzature-figures/assets/svg-examples/dotplot.svg``.

Author
------
`Warith Harchaoui, Ph.D. <https://www.linkedin.com/in/warith-harchaoui/>`_
"""

from __future__ import annotations

import math
import random
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

# The house-style palette lives one directory up, in _style.py.
from sprezzature_svg import GRIDLINE, load_palette, os_adaptive_style, os_dark_style  # noqa: E402
from sprezzature_svg import fullscreen_control  # noqa: E402
from sprezzature_svg import render_cli, svg_example_path, write_svg  # noqa: E402
from sprezzature_svg import foreground_tip_css, svg_open, tooltip_bubble  # noqa: E402
from sprezzature_svg import chrome_stack_for_theme  # noqa: E402


# ------------------------------------------------------------------
# Communicative fake data
# ------------------------------------------------------------------
def _response_hours(n: int = 68, seed: int = 11) -> List[float]:
    """Return a right-skewed sample of first-response times, in hours.

    A dot plot only earns its keep when the sample is large enough to
    build a silhouette: a mound of fast replies with a thin tail of
    stragglers. The values are drawn from a log-normal (the canonical
    shape for waiting times — most tickets clear quickly, a few drag on)
    with a fixed seed, so the figure is illustrative yet fully
    deterministic and byte-stable across renders.

    Parameters
    ----------
    n : int, optional
        Number of tickets to sample.
    seed : int, optional
        Seed for the deterministic generator.

    Returns
    -------
    list of float
        ``n`` response times in hours, sorted ascending, rounded to 0.1 h
        and clamped to a plausible ``[0.3, 8.6]`` support window.
    """
    rng = random.Random(seed)
    vals = [
        round(min(max(math.exp(rng.gauss(math.log(2.0), 0.52)), 0.3), 8.6), 1)
        for _ in range(n)
    ]
    return sorted(vals)


#: First-response times (in hours) for a fortnight of inbound support
#: tickets at a small SaaS help desk. Most tickets are answered within
#: the first few hours; a handful drag into a long tail — the story the
#: dot plot makes obvious at a glance. Values are illustrative.
RESPONSE_HOURS: List[float] = _response_hours()

#: Row-record view of :data:`RESPONSE_HOURS`, the shape the ``make_<kind>``
#: contract asks for: one dict per ticket with its first-response time.
DEMO_DATA: List[Dict[str, Any]] = [{"hours": h} for h in RESPONSE_HOURS]


# ------------------------------------------------------------------
# Wilkinson binning
# ------------------------------------------------------------------
def wilkinson_bins(values: List[float], bin_width: float) -> List[Tuple[float, List[float]]]:
    """Assign each observation to an equal-width bin and stack it.

    Implements the classic Wilkinson dot-plot binning: sort the data,
    then sweep left to right opening a new bin whenever the next point
    lies more than ``bin_width`` from the bin's first point. Every dot
    in a bin is drawn at the bin's centre and stacked vertically, so
    the column height equals the bin count.

    Parameters
    ----------
    values : list of float
        The raw observations.
    bin_width : float
        The width of each bin in data units. Dots within this distance
        of a bin's opening point share the bin.

    Returns
    -------
    list of (float, list of float)
        One ``(centre, members)`` tuple per bin, left to right. The
        ``centre`` is the mean of the bin's members (dot-density
        placement); ``members`` are the observations in that bin.
    """
    bins: List[Tuple[float, List[float]]] = []
    members: List[float] = []
    anchor: float = 0.0
    for v in sorted(values):
        if members and (v - anchor) > bin_width:
            centre = sum(members) / len(members)
            bins.append((centre, members))
            members = []
        if not members:
            anchor = v
        members.append(v)
    if members:
        centre = sum(members) / len(members)
        bins.append((centre, members))
    return bins


# ------------------------------------------------------------------
# SVG assembly
# ------------------------------------------------------------------
def build_svg(
    data: Optional[List[Dict[str, Any]]] = None,
    mode: str = "self-contained",
    accessibility: str = "universal",
    theme: str = "corporate",
    within_label: str = "Within target",
    tail_label: str = "Long tail",
) -> str:
    """Assemble the full Wilkinson dot-plot SVG string.

    Parameters
    ----------
    data : list of dict or None
        Rows with an ``hours`` key (first-response time). Defaults to
        :data:`DEMO_DATA` (equivalently, :data:`RESPONSE_HOURS`).
    within_label, tail_label : str, optional
        Legend labels for the two dot colours (was hardcoded
        ``"Within target"`` / ``"Long tail"``).
    mode : str, optional
        Interactivity mode passed to :func:`_interactive.fullscreen_control`
        (``"self-contained"``, ``"external"`` or ``"static"``). Controls
        whether the emitted SVG carries its own fullscreen button; the raster
        output is unaffected. Defaults to ``"self-contained"``.
    accessibility : str, optional
        Palette accessibility level forwarded to :func:`_style.load_palette`
        (``"universal"``, ``"high-contrast"``, ``"monochrome"``,
        ``"deuteranopia"``, ``"protanopia"`` or ``"tritanopia"``). The default
        ``"universal"`` is the identity, so the shipped figure is unchanged.
    theme : str, optional
        Visual theme: ``"corporate"`` (default, Roboto -- byte-identical to
        the pre-theme render) or ``"academic"`` (LaTeX-style Latin Modern).
        See :func:`sprezzature_figures.fonts.chrome_stack_for_theme`.

    Returns
    -------
    str
        A complete, standalone SVG document.
    """
    response_hours: List[float] = (
        [float(r["hours"]) for r in data] if data else RESPONSE_HOURS
    )
    palette: Dict[str, str] = load_palette(accessibility, theme=theme)
    blue = palette.get("Blue", "#007AFF")
    red = palette.get("Red", "#FF3B30")
    ink = "#1D1D1F"
    secondary = "#6E6E73"

    # --- canvas geometry -----------------------------------------
    # Poster-size panel: a generous canvas so the dots read large and
    # the figure holds up at gallery scale. Height is sized to the
    # tallest bin so the stacked columns fill the panel instead of
    # floating over a sea of white space.
    width = 1200
    m_left, m_right = 96, 48
    m_top, m_bottom = 150, 108
    plot_w = width - m_left - m_right

    # --- value axis ----------------------------------------------
    x_min, x_max = 0.0, 9.0
    bin_width = 0.4
    ticks = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

    def sx(v: float) -> float:
        """Map a data value to an x pixel coordinate."""
        return m_left + (v - x_min) / (x_max - x_min) * plot_w

    # Dot radius and vertical pitch. Pitch is a hair larger than the
    # diameter so stacked dots read as separate observations.
    r = 11.0
    pitch = 2 * r + 2.5

    bins = wilkinson_bins(response_hours, bin_width)

    # Fit the canvas to the tallest stack so columns fill the panel.
    tallest = max(len(members) for _, members in bins)
    plot_h = tallest * pitch + r
    height = m_top + int(plot_h) + m_bottom
    baseline_y = height - m_bottom

    # Service-level target: tickets answered within 4 hours are "on
    # time". Dots at or before the line are Blue; the long tail past it
    # is Red — a reinforcement layer, always paired with the text label.
    target = 4.0

    parts: List[str] = []
    n = len(response_hours)
    within = sum(1 for v in response_hours if v <= target)
    pct_within = round(100 * within / n)

    parts.append(svg_open(width, height, "dp-title", "dp-desc", font_family=chrome_stack_for_theme(theme)))
    parts.append(
        '<title id="dp-title">Support ticket first-response times, one dot per '
        'ticket</title>'
    )
    parts.append(
        f'<desc id="dp-desc">Wilkinson dot plot of {n} first-response times in '
        f'hours. Each dot is one ticket, binned every {bin_width} h and stacked. '
        f'{pct_within}% of tickets were answered within the 4-hour target '
        f'(blue); the {n - within} past it form the long tail (red).</desc>'
    )

    # Focus ring for keyboard users landing on an interactive dot. The
    # figure is static (no animation), so there is no motion to guard.
    #
    # OS-adaptive overrides (additive; the default render is byte-identical
    # because every rule below lives inside an @media query and a class rule
    # only outranks the inline fill when the query matches). The two dot
    # categories — "within target" (blue) and "long tail" (red) — deepen to
    # their high-contrast hues under prefers-contrast. forced-colors is opt-in
    # here (forced=True): category identity survives with no colour because the
    # dashed 4-hour target line splits the panel into the two regions and both
    # categories carry an always-visible legend label.
    style_rows = [
        ".dot{cursor:pointer}",
        ".dot:hover,.dot:focus{stroke:#FFFFFF;stroke-width:2.5}",
        ".dot:focus{outline:none}",
        ".tip{opacity:0;pointer-events:none;transition:opacity .12s ease}",
        foreground_tip_css(n),
        "@media (prefers-reduced-motion:reduce){.tip{transition:none}}",
    ]
    dot_series = {".dot-within": blue, ".dot-tail": red}
    style_rows.append(os_adaptive_style(dot_series, role="fill", forced=True))
    # Additive dark mode: flip paper + the two ink tiers (data hues untouched).
    style_rows.append(os_dark_style())
    parts.append("<style>" + "".join(style_rows) + "</style>")

    # --- background ----------------------------------------------
    parts.append(f'<rect width="{width}" height="{height}" fill="#FFFFFF"/>')

    # --- title + subtitle (the takeaway) -------------------------
    parts.append(
        f'<text x="{m_left}" y="60" font-size="32" font-weight="700" '
        f'fill="{ink}">Most tickets get a reply within hours</text>'
    )
    parts.append(
        f'<text x="{m_left}" y="96" font-size="20" fill="{secondary}">'
        f'{pct_within}% of {n} support tickets clear the 4-hour target; a '
        f'thin red tail drags on</text>'
    )

    # --- target line + label -------------------------------------
    tx = sx(target)
    parts.append(
        f'<line x1="{tx:.1f}" y1="{m_top - 12:.1f}" x2="{tx:.1f}" '
        f'y2="{baseline_y:.1f}" stroke="{secondary}" stroke-width="1.5" '
        f'stroke-dasharray="6 6"/>'
    )
    parts.append(
        f'<text x="{tx + 10:.1f}" y="{m_top - 14:.1f}" font-size="17" '
        f'fill="{secondary}">4-hour target</text>'
    )

    # --- baseline (value axis) -----------------------------------
    parts.append(
        f'<line x1="{m_left}" y1="{baseline_y:.1f}" x2="{m_left + plot_w}" '
        f'y2="{baseline_y:.1f}" stroke="{ink}" stroke-width="1.5"/>'
    )
    for t in ticks:
        px = sx(t)
        parts.append(
            f'<text x="{px:.1f}" y="{baseline_y + 34:.1f}" font-size="18" '
            f'font-family="Roboto Mono, monospace" fill="{ink}" '
            f'text-anchor="middle">{t}</text>'
        )
    parts.append(
        f'<text x="{m_left + plot_w / 2:.1f}" y="{baseline_y + 72:.1f}" '
        f'font-size="20" fill="{ink}" text-anchor="middle">'
        f'First-response time (hours, lower is better)</text>'
    )

    # --- the dots ------------------------------------------------
    # Draw each bin as a stacked column of dots, bottom to top. Fully
    # drawn in the still — the Wilkinson silhouette *is* the chart, so
    # no motion is added. A thin white halo keeps stacked same-category
    # dots distinct where they touch.
    dot_tips: List[str] = []
    dot_i = 0
    for centre, members in bins:
        cx = sx(centre)
        for j, v in enumerate(members):
            cy = baseline_y - r - j * pitch
            over = v > target
            fill = red if over else blue
            cat = "dot-tail" if over else "dot-within"
            # Native tooltip: exact value, one decimal.
            tip = f"Ticket answered in {v:.1f} h"
            parts.append(
                f'<circle id="hit-{dot_i}" class="dot {cat} hit" cx="{cx:.1f}" cy="{cy:.1f}" '
                f'r="{r:.1f}" fill="{fill}" fill-opacity="0.92" '
                f'stroke="#FFFFFF" stroke-width="1.5" tabindex="0" '
                f'role="img" aria-label="{tip}">'
                f'<title>{tip}</title>'
                f'</circle>'
            )
            dot_tips.append(
                tooltip_bubble(
                    cx + r + 8, cy - 20, anchor="start",
                    lines=[f"{v:.1f} h response time", "past 4-hour target" if over else "within 4-hour target"],
                    canvas_w=width, canvas_h=height, ink=ink, secondary=secondary, border=GRIDLINE,
                    elem_id=f"tip-{dot_i}",
                )
            )
            dot_i += 1
    # Every dot's bubble drawn only after every dot in the whole plot, so a
    # dot stacked above it in a later bin can never cover an earlier bubble.
    parts.extend(dot_tips)

    # --- legend ---------------------------------------------------
    # Anchored top-right inside the panel; pure fills (no dark ring),
    # labels in ink to the right of each disk.
    lr = 9.0
    ly = m_top + 4
    lx_blue = m_left + plot_w - 292
    lx_red = m_left + plot_w - 118
    parts.append(
        f'<circle class="dot-within" cx="{lx_blue:.1f}" cy="{ly:.1f}" '
        f'r="{lr:.1f}" fill="{blue}"/>'
    )
    parts.append(
        f'<text x="{lx_blue + 16:.1f}" y="{ly + 6:.1f}" font-size="18" '
        f'fill="{ink}">{within_label}</text>'
    )
    parts.append(
        f'<circle class="dot-tail" cx="{lx_red:.1f}" cy="{ly:.1f}" '
        f'r="{lr:.1f}" fill="{red}"/>'
    )
    parts.append(
        f'<text x="{lx_red + 16:.1f}" y="{ly + 6:.1f}" font-size="18" '
        f'fill="{ink}">{tail_label}</text>'
    )

    # Fullscreen control per interactivity mode, just before the close.
    parts.append(fullscreen_control(width, height, mode))
    parts.append("</svg>")
    return "\n".join(parts)


def make_dotplot(
    data: Optional[List[Dict[str, Any]]] = None,
    *,
    out: Optional[Path | str] = None,
    title: str = "",
    within_label: str = "Within target",
    tail_label: str = "Long tail",
    mode: str = "self-contained",
    accessibility: str = "universal",
    theme: str = "corporate",
) -> Path:
    """Render the Wilkinson dot-plot SVG and write it to ``out``.

    The standard ``make_<kind>`` entry the figure registry dispatches to.

    Parameters
    ----------
    data : list[dict[str, Any]] or None
        Rows with an ``hours`` key. Defaults to :data:`DEMO_DATA`.
    out : Path, str, or None
        Output path (.svg). Defaults to ``assets/svg-examples/dotplot.svg``.
    title : str, optional
        Accepted for dispatcher/CLI parity; unused, since the chart's
        title is fixed prose.
    within_label, tail_label : str, optional
        Forwarded to :func:`build_svg`.
    mode, accessibility : str
        Forwarded to :func:`build_svg`.
    theme : str, optional
        Visual theme. Forwarded to :func:`build_svg`.

    Returns
    -------
    Path
        Absolute path to the written SVG file.
    """
    _ = title  # accepted for dispatcher parity; see docstring
    svg = build_svg(
        data, mode=mode, accessibility=accessibility, theme=theme,
        within_label=within_label, tail_label=tail_label,
    )
    dest = Path(out) if out else svg_example_path(__file__, "dotplot")
    return write_svg(dest, svg, theme=theme)


def main() -> None:
    """Write the dot-plot SVG to the canonical assets path.

    The ``--mode`` flag (via :func:`_render.render_cli`) selects the
    interactivity mode threaded into :func:`build_svg`.
    """
    render_cli(
        __file__,
        "dotplot",
        build_svg,
        description="Write the house-style Wilkinson dot-plot SVG example.",
    )



# ── kit: the data comes from data.csv ─────────────────────────────────────
# The generator keeps its own DEMO_DATA above as a fallback and as a record
# of the expected column names. When data.csv is present (it ships with this
# kit), it wins: edit the CSV, re-run this file, and the figure changes.
from sprezzature_svg import load_rows  # noqa: E402

try:
    DEMO_DATA = load_rows("data.csv") or DEMO_DATA
except FileNotFoundError:
    pass


if __name__ == "__main__":
    main()
