#!/usr/bin/env python3
"""
make_errorbar — a house-styled error bar chart as hand-authored SVG.

Plots a point estimate per category with a capped vertical bar spanning
its uncertainty interval: a 95% confidence interval, a standard
deviation, a min-max range, whatever the caller's ``lo``/``hi`` mean.
The default chart for "here's the number, and here's how sure we are"
across a handful of groups: A/B test lifts, experiment arms, survey
means by cohort.

This module paints the whisker, caps, and point by hand. Every error
bar carries a native ``<title>`` tooltip with the mean and interval.

Author
------
`Warith Harchaoui, Ph.D. <https://www.linkedin.com/in/warith-harchaoui/>`_
"""

from __future__ import annotations

import math
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

from sprezzature_svg import fullscreen_control  # noqa: E402
from sprezzature_svg import render_cli, svg_example_path, write_svg  # noqa: E402
from sprezzature_svg import foreground_tip_css, svg_open, tooltip_bubble, xml_escape  # noqa: E402
from sprezzature_svg import BG, GRIDLINE, INK, SECONDARY  # noqa: E402
from sprezzature_svg import chrome_stack_for_theme, mono_stack_for_theme  # noqa: E402

COLOR_POINT = "#007AFF"


def _nice_step(span: float, target_ticks: int = 5) -> float:
    """Pick a 1/2/5-times-a-power-of-ten step so ``span / step`` ~= `target_ticks`.

    This axis doesn't start at 0 (it's a padded min/max window around the
    confidence intervals), so ``_scale.nice_ticks`` -- which always builds
    ``[0, step, 2*step, ...]`` -- doesn't apply directly. Rounding the step
    itself to a "nice" 1/2/5 x 10**k value (Heckbert 1990) turns a naive
    ``span / 5`` divide -- which used to land on tick labels like
    ``28``/``39``/``50``/``61``/``72``/``83`` -- into a round, scannable step.
    """
    if span <= 0:
        return 1.0
    raw_step = span / target_ticks
    exponent = math.floor(math.log10(raw_step))
    fraction = raw_step / (10.0**exponent)
    nice_fraction = 1.0 if fraction < 1.5 else 2.0 if fraction < 3 else 5.0 if fraction < 7 else 10.0
    return nice_fraction * (10.0**exponent)

DEMO_DATA: List[Dict[str, Any]] = [
    {"g": "A", "mean": 40, "lo": 34, "hi": 46},
    {"g": "B", "mean": 55, "lo": 47, "hi": 63},
    {"g": "C", "mean": 48, "lo": 43, "hi": 53},
    {"g": "D", "mean": 67, "lo": 57, "hi": 77},
]


def build_svg(
    data: Optional[List[Dict[str, Any]]] = None,
    title: str = "Mean with 95% Interval",
    subtitle: str = "Point estimate per group, capped bar spans the confidence interval",
    y_axis_title: str = "Value",
    x_axis_title: str = "Group",
    width: int = 620,
    height: int = 420,
    mode: str = "self-contained",
    accessibility: str = "universal",
    theme: str = "corporate",
) -> str:
    """Assemble the full error bar chart SVG document as a string.

    Parameters
    ----------
    data : list of dict or None
        Rows with keys ``g`` (str), ``mean``, ``lo``, ``hi`` (numeric).
        Defaults to :data:`DEMO_DATA`.
    title, subtitle : str
        Chart text.
    y_axis_title, x_axis_title : str
        Axis labels (were hardcoded ``"Value"`` / ``"Group"``).
    width, height : int
        Canvas size in pixels.
    mode : str, optional
        Forwarded to :func:`_interactive.fullscreen_control`.
    accessibility : str, optional
        Accepted for CLI parity but a documented no-op: a single house-
        blue point/whisker, no categorical hues to re-level.
    theme : str, optional
        Visual theme: ``"corporate"`` (default, Roboto -- byte-identical to
        the pre-theme render) or ``"academic"`` (LaTeX-style Latin Modern).
        See :func:`sprezzature_figures.fonts.chrome_stack_for_theme`.

    Returns
    -------
    str
        A complete, standalone SVG document.
    """
    _ = accessibility
    mono_family = mono_stack_for_theme(theme)
    rows = data if data else DEMO_DATA
    los = [float(r["lo"]) for r in rows]
    his = [float(r["hi"]) for r in rows]
    v_min, v_max = min(los), max(his)
    pad = (v_max - v_min) * 0.15 or 1.0

    plot_x, plot_y = 64.0, 118.0
    right_margin, bottom_reserved = 30.0, 60.0
    plot_w = width - plot_x - right_margin
    plot_h = height - plot_y - bottom_reserved
    n = len(rows)
    bin_w = plot_w / n if n else plot_w
    cap_w = min(28.0, bin_w * 0.3)

    def y_for(v: float) -> float:
        return plot_y + plot_h - (v - (v_min - pad)) / ((v_max + pad) - (v_min - pad)) * plot_h

    parts: List[str] = []
    parts.append(svg_open(width, height, "eb-title", "eb-desc", font_family=chrome_stack_for_theme(theme)))
    parts.append(f'<title id="eb-title">{xml_escape(title)}</title>')
    parts.append(
        f'<desc id="eb-desc">Error bar chart of {n} groups. Hover or focus a bar for its '
        f'exact mean and interval.</desc>'
    )
    parts.append(
        "<style>"
        ".errbar{transition:opacity .15s ease;}"
        ".errbar:hover,.errbar:focus{opacity:.72;outline:none;}"
        "@media (prefers-reduced-motion: reduce){.errbar{transition:none;}}"
        ".tip{opacity:0;pointer-events:none;transition:opacity .12s ease}"
        + foreground_tip_css(len(rows), mark_prefix="errbar", tip_prefix="errbartip")
        + "@media (prefers-reduced-motion:reduce){.tip{transition:none}}"
        "</style>"
    )
    parts.append(f'<rect width="{width}" height="{height}" fill="{BG}"/>')
    parts.append(
        f'<text x="40" y="46" font-size="22" font-weight="700" fill="{INK}" '
        f'letter-spacing="-0.3">{xml_escape(title)}</text>'
    )
    parts.append(f'<text x="40" y="70" font-size="14" fill="{SECONDARY}">{xml_escape(subtitle)}</text>')

    # ---- y-axis gridlines (round "nice" steps, not a naive 5-way split) ----
    axis_lo, axis_hi = v_min - pad, v_max + pad
    step = _nice_step(axis_hi - axis_lo, 5)
    val = math.floor(axis_lo / step) * step
    while val <= axis_hi + 1e-9:
        if val >= axis_lo - 1e-9:
            ty = y_for(val)
            parts.append(
                f'<line x1="{plot_x:.1f}" y1="{ty:.1f}" x2="{plot_x + plot_w:.1f}" y2="{ty:.1f}" '
                f'stroke="{GRIDLINE}" stroke-width="1"/>'
            )
            parts.append(
                f'<text x="{plot_x - 10:.1f}" y="{ty + 4:.1f}" font-size="12" font-family="{mono_family}" '
                f'fill="{SECONDARY}" text-anchor="end">{val:.0f}</text>'
            )
        val += step
    parts.append(
        f'<text x="18" y="{plot_y + plot_h / 2:.1f}" font-size="13" fill="{INK}" '
        f'text-anchor="middle" transform="rotate(-90 18 {plot_y + plot_h / 2:.1f})">{xml_escape(y_axis_title)}</text>'
    )

    # ---- error bars ----
    errbar_tips: List[str] = []
    for i, r in enumerate(rows):
        cx = plot_x + i * bin_w + bin_w / 2
        y_lo, y_hi = y_for(float(r["lo"])), y_for(float(r["hi"]))
        y_mean = y_for(float(r["mean"]))
        tip = f"{r['g']}: mean {float(r['mean']):.0f} (95% CI {float(r['lo']):.0f}-{float(r['hi']):.0f})"
        parts.append(f'<g id="errbar-{i}" class="errbar hit" tabindex="0">')
        parts.append(f'<title>{xml_escape(tip)}</title>')
        parts.append(f'<line x1="{cx:.1f}" y1="{y_lo:.1f}" x2="{cx:.1f}" y2="{y_hi:.1f}" stroke="{INK}" stroke-width="1.5"/>')
        parts.append(f'<line x1="{cx - cap_w / 2:.1f}" y1="{y_lo:.1f}" x2="{cx + cap_w / 2:.1f}" y2="{y_lo:.1f}" stroke="{INK}" stroke-width="1.5"/>')
        parts.append(f'<line x1="{cx - cap_w / 2:.1f}" y1="{y_hi:.1f}" x2="{cx + cap_w / 2:.1f}" y2="{y_hi:.1f}" stroke="{INK}" stroke-width="1.5"/>')
        parts.append(f'<circle cx="{cx:.1f}" cy="{y_mean:.1f}" r="6" fill="{COLOR_POINT}" stroke="{BG}" stroke-width="1.5"/>')
        parts.append("</g>")
        errbar_tips.append(
            tooltip_bubble(
                cx, y_hi - 14,
                [str(r["g"]), f"mean {float(r['mean']):.0f}", f"95% CI {float(r['lo']):.0f}-{float(r['hi']):.0f}"],
                anchor="middle", canvas_w=width, canvas_h=height,
                ink=INK, secondary=SECONDARY, border=GRIDLINE,
                elem_id=f"errbartip-{i}",
            )
        )
    # Every error-bar bubble drawn only after every error bar.
    parts.extend(errbar_tips)

    # ---- x-axis ----
    axis_y = plot_y + plot_h
    parts.append(
        f'<line x1="{plot_x:.1f}" y1="{axis_y:.1f}" x2="{plot_x + plot_w:.1f}" y2="{axis_y:.1f}" '
        f'stroke="{INK}" stroke-width="1.2"/>'
    )
    for i, r in enumerate(rows):
        tx = plot_x + i * bin_w + bin_w / 2
        parts.append(
            f'<text x="{tx:.1f}" y="{axis_y + 20:.1f}" font-size="13" fill="{INK}" '
            f'text-anchor="middle">{xml_escape(str(r["g"]))}</text>'
        )
    parts.append(
        f'<text x="{plot_x + plot_w / 2:.1f}" y="{axis_y + 42:.1f}" font-size="13" '
        f'fill="{INK}" text-anchor="middle">{xml_escape(x_axis_title)}</text>'
    )

    parts.append(fullscreen_control(width, height, mode))
    parts.append("</svg>")
    return "\n".join(parts)


def make_errorbar(
    data: Optional[List[Dict[str, Any]]] = None,
    *,
    out: Optional[Path | str] = None,
    title: str = "Mean with 95% Interval",
    subtitle: str = "Point estimate per group, capped bar spans the confidence interval",
    y_axis_title: str = "Value",
    x_axis_title: str = "Group",
    width: int = 620,
    height: int = 420,
    mode: str = "self-contained",
    accessibility: str = "universal",
    theme: str = "corporate",
) -> Path:
    """Render a hand-authored error bar chart and write the SVG to *out*.

    Parameters
    ----------
    data : list[dict[str, Any]] or None
        Rows with keys ``g`` (str), ``mean``, ``lo``, ``hi`` (float).
        Defaults to DEMO_DATA.
    out : Path, str, or None
        Output path (.svg). Defaults to ``assets/svg-examples/errorbar.svg``.
    title, subtitle : str
        Chart text.
    y_axis_title, x_axis_title : str
        Axis labels. Forwarded to :func:`build_svg`.
    width, height : int
        Canvas size in pixels.
    mode, accessibility : str
        Forwarded to :func:`build_svg`.
    theme : str, optional
        Visual theme. Forwarded to :func:`build_svg`.

    Returns
    -------
    Path
        Absolute path to the written SVG file.

    Examples
    --------
    >>> p = make_errorbar()
    >>> p.exists()
    True
    """
    svg = build_svg(data, title=title, subtitle=subtitle, y_axis_title=y_axis_title, x_axis_title=x_axis_title,
                     width=width, height=height, mode=mode, accessibility=accessibility, theme=theme)
    dest = Path(out) if out else svg_example_path(__file__, "errorbar")
    return write_svg(dest, svg, theme=theme)


def main() -> None:
    """CLI entry point: build the SVG and write it to disk."""
    render_cli(__file__, "errorbar", build_svg, description="Generate an error bar chart.")



# ── kit: the data comes from data.csv ─────────────────────────────────────
# The generator keeps its own DEMO_DATA above as a fallback and as a record
# of the expected column names. When data.csv is present (it ships with this
# kit), it wins: edit the CSV, re-run this file, and the figure changes.
from sprezzature_svg import load_rows  # noqa: E402

try:
    DEMO_DATA = load_rows("data.csv") or DEMO_DATA
except FileNotFoundError:
    pass


if __name__ == "__main__":
    main()
