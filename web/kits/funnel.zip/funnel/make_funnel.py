#!/usr/bin/env python3
"""
make_funnel — a conversion funnel chart rendered as a hand-authored SVG.

A funnel chart shows how a population shrinks stage by stage through a
sequential process. Each stage is a trapezoid whose width is proportional
to the count entering that stage. The taper from left to right makes it
immediately obvious where the biggest drops occur, which is the primary
question in any conversion or retention analysis. A label on each stage
shows the absolute count and the conversion rate from the previous stage.

The typical use is marketing pipeline analysis (website visitors to trial
to paying customers), clinical trial enrolment, or any process where
participants drop out at each step.

Author
------
`Warith Harchaoui, Ph.D. <https://www.linkedin.com/in/warith-harchaoui/>`_
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Any, Dict, List, Optional
from xml.sax.saxutils import escape

from sprezzature_svg import render_cli, svg_example_path, write_svg  # noqa: E402
from sprezzature_svg import fullscreen_control  # noqa: E402
from sprezzature_svg import BG, GRIDLINE, INK, SECONDARY  # noqa: E402
from sprezzature_svg import foreground_tip_css, tooltip_bubble  # noqa: E402
from sprezzature_svg import chrome_stack_for_theme, mono_stack_for_theme  # noqa: E402

# ---------------------------------------------------------------------------
# Canvas constants
# ---------------------------------------------------------------------------
WIDTH = 900
HEIGHT = 600
MARGIN_H = 60     # left and right margin
MARGIN_V = 120    # top and bottom margin
# Horizontal room reserved on each side for the outside stage labels (name on
# the left, count on the right). The widest trapezoid stops short of the canvas
# edge by this much so its labels never spill past the viewBox.
LABEL_GUTTER = 160

# House palette — six distinct hues, darker at the top to guide the eye
STAGE_COLORS = [
    # Adjacent stages in a funnel share an edge (there's no gap between
    # trapezoids, unlike a bar chart), so any two consecutive colours here
    # need to stay distinguishable under colour-vision deficiency. Red and
    # Green -- the one pair that collapses under protanopia/deuteranopia --
    # used to sit at positions 4 and 5 (directly touching); Red is moved to
    # the end so it instead borders Turquoise, a safe pair under every CVD
    # type, and Green now borders Turquoise on its other side too.
    "#007AFF",   # Blue (top: largest audience)
    "#AF52DE",   # Purple
    "#FF9500",   # Orange
    "#28CD41",   # Green
    "#79DBDC",   # Turquoise
    "#FF3B30",   # Red (bottom: smallest group)
]


# ---------------------------------------------------------------------------
# Demo data: SaaS product-led growth funnel, Q3-2024.
# Each stage records the count entering that stage.
# ---------------------------------------------------------------------------
DEMO_DATA: List[Dict[str, Any]] = [
    {"stage": "Website visits",    "count": 124800},
    {"stage": "Trial sign-ups",    "count": 18720},
    {"stage": "Activated users",   "count": 9360},
    {"stage": "Feature adoption",  "count": 4212},
    {"stage": "Upgrade intent",    "count": 1684},
    {"stage": "Paying customers",  "count": 842},
]


def build_svg(
    data: Optional[List[Dict[str, Any]]] = None,
    *,
    title: str = "Product-Led Growth Funnel — Q3 2024",
    subtitle: str = "Count of users reaching each conversion stage",
    theme: str = "corporate",
) -> str:
    """Render the funnel chart as an SVG string.

    Parameters
    ----------
    data : list[dict[str, Any]] or None
        Rows with keys ``stage`` (str) and ``count`` (int or float).
        Must have at least two rows. Defaults to :data:`DEMO_DATA`.
    title : str
        Chart headline.
    subtitle : str
        One-line subtitle displayed beneath the title.
    theme : str, optional
        Visual theme: ``"corporate"`` (default, Roboto -- byte-identical to
        the pre-theme render) or ``"academic"`` (LaTeX-style Latin Modern).
        See :func:`sprezzature_figures.fonts.chrome_stack_for_theme`.

    Returns
    -------
    str
        A complete, self-contained SVG document.
    """
    chrome_family = chrome_stack_for_theme(theme)
    mono_family = mono_stack_for_theme(theme)
    data = data if data is not None else DEMO_DATA
    counts = [float(row["count"]) for row in data]
    max_count = max(counts)
    n = len(data)

    plot_h = HEIGHT - 2 * MARGIN_V
    # Widest half-width the funnel may reach, leaving a gutter for outside labels.
    half_max = WIDTH / 2.0 - LABEL_GUTTER
    # Each stage occupies an equal vertical slice
    slice_h = plot_h / n

    fs_ctrl = fullscreen_control(WIDTH, HEIGHT)

    lines: List[str] = []
    lines.append(
        f'<svg role="img" aria-label="{escape(title)}" '
        f'width="{WIDTH}" height="{HEIGHT}" '
        f'viewBox="0 0 {WIDTH} {HEIGHT}" '
        f'xmlns="http://www.w3.org/2000/svg" '
        f'font-family="{chrome_family}" '
        f'style="background:{BG};max-width:100%;height:auto">'
    )
    lines.append(f'<desc>{escape(subtitle)}</desc>')
    lines.append(
        "<style>"
        ".tip{opacity:0;pointer-events:none;transition:opacity .12s ease}"
        + foreground_tip_css(len(data), mark_prefix="stage", tip_prefix="stagetip")
        + "@media (prefers-reduced-motion:reduce){.tip{transition:none}}"
        "</style>"
    )
    lines.append(f'<rect width="{WIDTH}" height="{HEIGHT}" fill="{BG}"/>')

    # Title and subtitle
    lines.append(
        f'<text x="{WIDTH // 2}" y="52" font-size="26" font-weight="600" '
        f'fill="{INK}" text-anchor="middle" letter-spacing="-0.3">'
        f'{escape(title)}</text>'
    )
    lines.append(
        f'<text x="{WIDTH // 2}" y="80" font-size="14" fill="{SECONDARY}" '
        f'text-anchor="middle">{escape(subtitle)}</text>'
    )

    # Funnel trapezoids
    cx = WIDTH / 2.0   # horizontal center
    funnel_tips: List[str] = []
    for i, row in enumerate(data):
        count = float(row["count"])
        stage = row["stage"]
        color = STAGE_COLORS[i % len(STAGE_COLORS)]

        # Half-width of the top and bottom edges of this trapezoid
        half_top = (count / max_count) * half_max
        if i + 1 < n:
            next_count = float(data[i + 1]["count"])
            half_bot = (next_count / max_count) * half_max
        else:
            # Last stage has no "next" count to taper to, so it gets a small
            # flat bottom instead of tapering to a knife-edge point. Capped
            # at `half_top` (never wider): an uncapped fixed 30px flat bottom
            # made the final segment visually *flare outward* whenever its
            # own top was already narrower than 30px -- which is the common
            # case, since the last funnel stage is usually the smallest count
            # by far (here, 842 users vs. a 124,800-user first stage put
            # half_top around 3px, so a flat 30px bottom drew a bulging
            # onion-dome shape that read as "this stage grew," the opposite
            # of what a monotonically-shrinking funnel should ever show).
            half_bot = min(30.0, half_top)

        y_top = MARGIN_V + i * slice_h
        y_bot = y_top + slice_h

        # Smooth funnel: each side is a cubic Bézier that leaves the top edge and
        # arrives at the bottom edge vertically, so neighbouring stages meet with
        # a shared vertical tangent and the whole silhouette reads as one curved
        # funnel rather than a stack of straight-sided (polygonal) trapezoids.
        ctrl = slice_h * 0.5
        lt, rt = cx - half_top, cx + half_top
        lb, rb = cx - half_bot, cx + half_bot
        d = (
            f"M{lt:.1f},{y_top:.1f} L{rt:.1f},{y_top:.1f} "
            f"C{rt:.1f},{y_top + ctrl:.1f} {rb:.1f},{y_bot - ctrl:.1f} {rb:.1f},{y_bot:.1f} "
            f"L{lb:.1f},{y_bot:.1f} "
            f"C{lb:.1f},{y_bot - ctrl:.1f} {lt:.1f},{y_top + ctrl:.1f} {lt:.1f},{y_top:.1f} Z"
        )
        conv_str = ""
        if i > 0:
            rate = count / float(data[i - 1]["count"]) * 100
            conv_str = f" ({rate:.1f}% conversion)"
        tooltip = f"{stage}: {count:,.0f}{conv_str}"
        lines.append(
            f'<path id="stage-{i}" class="hit" tabindex="0" d="{d}" fill="{color}" opacity="0.88">'
            f'<title>{escape(tooltip)}</title></path>'
        )
        bubble_lines = [str(stage), f"{count:,.0f} users"]
        if i > 0:
            rate = count / float(data[i - 1]["count"]) * 100
            bubble_lines.append(f"{rate:.1f}% conversion from prior stage")
        share = count / counts[0] * 100 if counts[0] else 0.0
        bubble_lines.append(f"{share:.1f}% of stage 1")
        funnel_tips.append(
            tooltip_bubble(
                cx, (y_top + y_bot) / 2.0 - 12, bubble_lines,
                anchor="middle", canvas_w=WIDTH, canvas_h=HEIGHT,
                ink=INK, secondary=SECONDARY, border=GRIDLINE,
                elem_id=f"stagetip-{i}",
            )
        )

        # Stage label: name on the left, count on the right
        label_y = (y_top + y_bot) / 2.0 + 5
        lines.append(
            f'<text x="{cx - half_top - 10:.1f}" y="{label_y:.1f}" '
            f'font-size="13" fill="{INK}" text-anchor="end">'
            f'{escape(stage)}</text>'
        )
        count_txt = f"{count:,.0f}"
        if i > 0:
            rate = count / float(data[i - 1]["count"]) * 100
            count_txt += f"  ({rate:.1f}%)"
        lines.append(
            f'<text x="{cx + half_top + 10:.1f}" y="{label_y:.1f}" '
            f'font-size="13" fill="{INK}" text-anchor="start" '
            f'font-family="{mono_family}">{escape(count_txt)}</text>'
        )

    # Every stage's bubble drawn only after every trapezoid and label, so a
    # narrower stage lower in the funnel can never cover a wider stage's
    # bubble above it -- SVG has no z-index.
    lines.extend(funnel_tips)
    lines.append(fs_ctrl)
    lines.append("</svg>")
    return "\n".join(lines)


def make_funnel(
    data: List[Dict[str, Any]] | None = None,
    *,
    out: Path | str | None = None,
    title: str = "Product-Led Growth Funnel — Q3 2024",
    subtitle: str = "Count of users reaching each conversion stage",
    width: int = WIDTH,
    height: int = HEIGHT,
    theme: str = "corporate",
) -> Path:
    """Render a conversion funnel chart and write the SVG to *out*.

    Parameters
    ----------
    data : list[dict[str, Any]] or None
        Rows with keys ``stage`` (str) and ``count`` (int or float).
        Defaults to DEMO_DATA (a SaaS PLG funnel).
    out : Path, str, or None
        Output file path (.svg). Defaults to the canonical
        ``assets/svg-examples/funnel.svg``.
    title : str
        Chart headline.
    subtitle : str
        One-line subtitle.
    width : int
        Ignored (fixed canvas; kept for API parity).
    height : int
        Ignored.
    theme : str, optional
        Visual theme. Forwarded to :func:`build_svg`.

    Returns
    -------
    Path
        Absolute path to the written SVG file.

    Examples
    --------
    >>> p = make_funnel()
    >>> p.exists()
    True
    """
    if data is None:
        data = DEMO_DATA
    svg = build_svg(data, title=title, subtitle=subtitle, theme=theme)
    dest = Path(out) if out else svg_example_path(__file__, "funnel")
    return write_svg(dest, svg, theme=theme)


def main() -> None:
    """CLI entry point: build the SVG and write it to disk."""
    render_cli(__file__, "funnel", build_svg, description="Generate a conversion funnel chart.")



# ── kit: the data comes from data.csv ─────────────────────────────────────
# The generator keeps its own DEMO_DATA above as a fallback and as a record
# of the expected column names. When data.csv is present (it ships with this
# kit), it wins: edit the CSV, re-run this file, and the figure changes.
from sprezzature_svg import load_rows  # noqa: E402

try:
    DEMO_DATA = load_rows("data.csv") or DEMO_DATA
except FileNotFoundError:
    pass


if __name__ == "__main__":
    main()
