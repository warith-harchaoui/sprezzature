# histogram — figure autonome

La figure `histogram` de la galerie Sprezzature, avec de quoi la refabriquer et
la modifier. Rien à compiler, pas de compte, pas de framework.

## Contenu

| Fichier | Rôle |
|---|---|
| `make_histogram.py` | Le générateur. C'est le fichier intéressant : il calcule la géométrie et écrit le SVG balise par balise. |
| `sprezzature_svg.py` | Le moteur de dessin : échelles, chemins SVG, palette, placement des étiquettes, survol. |
| `data.csv` | Les données. Modifiez-les, relancez, la figure change. |
| `histogram.svg` | La figure déjà produite, interactive. |
| `requirements.txt` | Versions épinglées, exactement celles vérifiées. |

## Lancer

```sh
# nothing to install — the standard library is enough
python3 make_histogram.py
# → wrote histogram.svg
```

## Regarder le résultat

Le SVG s'ouvre **dans un navigateur**, comme une page :

```sh
open histogram.svg        # macOS
xdg-open histogram.svg    # Linux
start histogram.svg       # Windows
```

C'est là que la figure prend vie : les infobulles au survol sont écrites dans
le SVG lui-même, en CSS, sans une ligne de JavaScript. Un double-clic depuis
l'explorateur de fichiers marche aussi. Pour l'intégrer dans une page web,
utilisez `<object data="histogram.svg"></object>` ou collez le SVG directement
dans le HTML.

**Le seul piège** : dans une balise `<img>`, le navigateur bloque les requêtes
externes, donc les polices Google Fonts liées par le SVG ne se chargent pas et
la figure retombe sur une police système. Tout le reste s'affiche normalement.

## Modifier

Changez les nombres de `data.csv` et relancez. Pour aller plus loin,
`python3 make_histogram.py --help` liste les options disponibles (titre, dimensions,
niveau d'accessibilité, thème…).

---

Extrait de [sprezzature-figures](https://github.com/warith-harchaoui/sprezzature-figures) ·
Galerie complète : <https://sprezzature.ai/figures.html> ·
Warith Harchaoui, Ph.D.
