#!/usr/bin/env python3
"""
make_kde1d — a house-styled 1-D kernel density estimate as hand-authored SVG.

A **kernel density estimate** (KDE) turns a handful of numbers into a smooth
curve: centre a small bell shape (a Gaussian kernel) on every observation,
then add all the bells together. Where observations cluster, the bells
overlap and stack up into a hill; where they thin out, the curve sinks
towards zero. It gives the same "where does this sample concentrate?"
reading as a histogram, without a histogram's arbitrary choice of bin
edges: the only knob left is the bandwidth, how wide each bell is drawn.
A vertical gradient fill (pale at the baseline, full house blue at the
curve) keeps the shape readable without a legend. Typical use: any single
numeric sample where a histogram's bin edges would distract from the
shape itself.

This module computes the kernel density estimate itself and paints the
filled curve by hand, with no scipy. The curve carries a native
``<title>`` tooltip.

Author
------
`Warith Harchaoui, Ph.D. <https://www.linkedin.com/in/warith-harchaoui/>`_
"""

from __future__ import annotations

import math
import random
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

from sprezzature_svg import fullscreen_control  # noqa: E402
from sprezzature_svg import render_cli, svg_example_path, write_svg  # noqa: E402
from sprezzature_svg import nice_ticks, nice_ticks_range  # noqa: E402
from sprezzature_svg import svg_open, xml_escape  # noqa: E402
from sprezzature_svg import BG, GRIDLINE, INK, SECONDARY  # noqa: E402
from sprezzature_svg import chrome_stack_for_theme, mono_stack_for_theme  # noqa: E402

COLOR_TOP = "#007AFF"
COLOR_BOTTOM = "#EAF3FF"


def _make_demo_data() -> List[Dict[str, Any]]:
    rng = random.Random(17)
    rows: List[Dict[str, Any]] = []
    for _ in range(90):
        rows.append({"x": round(rng.gauss(6.3, 0.85), 2)})
    return rows


DEMO_DATA: List[Dict[str, Any]] = _make_demo_data()


def _gaussian_kde(samples: List[float], x_eval: List[float], bandwidth: float) -> List[float]:
    """Evaluate a Gaussian-kernel density estimate of *samples* at *x_eval*."""
    n = len(samples)
    norm = 1.0 / (n * bandwidth * math.sqrt(2.0 * math.pi))
    density: List[float] = []
    for x in x_eval:
        total = sum(math.exp(-0.5 * ((x - s) / bandwidth) ** 2) for s in samples)
        density.append(norm * total)
    return density


def _silverman_bandwidth(samples: List[float]) -> float:
    """Silverman's rule-of-thumb bandwidth for a Gaussian KDE."""
    n = len(samples)
    mean = sum(samples) / n
    std = math.sqrt(sum((s - mean) ** 2 for s in samples) / max(1, n - 1)) or 1.0
    return 0.9 * std * n ** (-1.0 / 5.0)


def build_svg(
    data: Optional[List[Dict[str, Any]]] = None,
    title: str = "Estimated Density",
    subtitle: str = "Gaussian kernel density estimate",
    y_axis_title: str = "Density",
    width: int = 620,
    height: int = 380,
    mode: str = "self-contained",
    accessibility: str = "universal",
    theme: str = "corporate",
) -> str:
    """Assemble the full 1-D KDE SVG document as a string.

    Parameters
    ----------
    data : list of dict or None
        Rows with key ``x`` (numeric). Defaults to :data:`DEMO_DATA`.
    title, subtitle : str
        Chart text.
    y_axis_title : str
        Y-axis label (was hardcoded ``"Density"``, no override).
    width, height : int
        Canvas size in pixels.
    mode : str, optional
        Forwarded to :func:`_interactive.fullscreen_control`.
    accessibility : str, optional
        Accepted for CLI parity but a documented no-op: a single
        house-blue gradient fill, no categorical hues to re-level.
    theme : str, optional
        Visual theme: ``"corporate"`` (default, Roboto -- byte-identical to
        the pre-theme render) or ``"academic"`` (LaTeX-style Latin Modern).
        See :func:`sprezzature_figures.fonts.chrome_stack_for_theme`.

    Returns
    -------
    str
        A complete, standalone SVG document.
    """
    _ = accessibility
    mono_family = mono_stack_for_theme(theme)
    rows = data if data else DEMO_DATA
    samples = [float(r["x"]) for r in rows]
    bandwidth = _silverman_bandwidth(samples)
    s_min, s_max = min(samples), max(samples)
    span = (s_max - s_min) or 1.0
    x_lo, x_hi = s_min - span * 0.3, s_max + span * 0.3

    n_points = 200
    step = (x_hi - x_lo) / (n_points - 1)
    x_eval = [x_lo + i * step for i in range(n_points)]
    density = _gaussian_kde(samples, x_eval, bandwidth)
    # Nice, round y-tick values (Heckbert 1990, shared with bar/area/etc.)
    # instead of raw_max/4 fractions — the old `peak * i / 4` scheme produced
    # unreadable labels like 0.434/0.326/0.217/0.109. An 8% pre-pad before
    # rounding guarantees the curve's true peak always sits under the top
    # gridline with a sliver of headroom, even when the raw max already
    # lands exactly on a nice number.
    y_tick_vals = nice_ticks(max(density) * 1.08, 4)
    peak = y_tick_vals[-1]

    plot_x, plot_y = 60.0, 118.0
    right_margin, bottom_reserved = 30.0, 60.0
    plot_w = width - plot_x - right_margin
    plot_h = height - plot_y - bottom_reserved

    def x_for(v: float) -> float:
        return plot_x + (v - x_lo) / (x_hi - x_lo) * plot_w

    def y_for(v: float) -> float:
        return plot_y + plot_h - (v / peak * plot_h)

    parts: List[str] = []
    parts.append(svg_open(width, height, "kde-title", "kde-desc", font_family=chrome_stack_for_theme(theme)))
    parts.append(f'<title id="kde-title">{xml_escape(title)}</title>')
    parts.append(
        f'<desc id="kde-desc">Kernel density estimate of {len(samples)} observations, '
        f'bandwidth {bandwidth:.2f}, ranging {s_min:.1f} to {s_max:.1f}.</desc>'
    )
    parts.append(
        f'<defs><linearGradient id="kdeGrad" x1="0" y1="1" x2="0" y2="0">'
        f'<stop offset="0" stop-color="{COLOR_BOTTOM}"/>'
        f'<stop offset="1" stop-color="{COLOR_TOP}"/>'
        f'</linearGradient></defs>'
    )
    parts.append(f'<rect width="{width}" height="{height}" fill="{BG}"/>')
    parts.append(
        f'<text x="40" y="46" font-size="22" font-weight="700" fill="{INK}" '
        f'letter-spacing="-0.3">{xml_escape(title)}</text>'
    )
    parts.append(f'<text x="40" y="70" font-size="14" fill="{SECONDARY}">{xml_escape(subtitle)}</text>')

    # ---- gridlines ----
    for val in y_tick_vals:
        ty = y_for(val)
        parts.append(
            f'<line x1="{plot_x:.1f}" y1="{ty:.1f}" x2="{plot_x + plot_w:.1f}" y2="{ty:.1f}" '
            f'stroke="{GRIDLINE}" stroke-width="1"/>'
        )
        parts.append(
            f'<text x="{plot_x - 10:.1f}" y="{ty + 4:.1f}" font-size="10" font-family="{mono_family}" '
            f'fill="{SECONDARY}" text-anchor="end">{val:.3f}</text>'
        )
    parts.append(
        f'<text x="18" y="{plot_y + plot_h / 2:.1f}" font-size="13" fill="{INK}" '
        f'text-anchor="middle" transform="rotate(-90 18 {plot_y + plot_h / 2:.1f})">{xml_escape(y_axis_title)}</text>'
    )

    # ---- filled curve ----
    axis_y = plot_y + plot_h
    top_pts = [(x_for(x), y_for(d)) for x, d in zip(x_eval, density)]
    path_d = "M " + " L ".join(f"{x:.1f},{y:.1f}" for x, y in top_pts)
    path_d += f" L {top_pts[-1][0]:.1f},{axis_y:.1f} L {top_pts[0][0]:.1f},{axis_y:.1f} Z"
    tip = f"KDE of {len(samples)} observations, bandwidth {bandwidth:.2f}"
    parts.append(
        f'<path tabindex="0" d="{path_d}" fill="url(#kdeGrad)" fill-opacity="0.85" '
        f'stroke="{COLOR_TOP}" stroke-width="2"><title>{xml_escape(tip)}</title></path>'
    )

    # ---- x-axis ----
    parts.append(
        f'<line x1="{plot_x:.1f}" y1="{axis_y:.1f}" x2="{plot_x + plot_w:.1f}" y2="{axis_y:.1f}" '
        f'stroke="{INK}" stroke-width="1.2"/>'
    )
    # Nice, round x-tick values (shared _scale.nice_ticks_range helper,
    # already adopted by make_beeswarm.py) instead of the old
    # x_lo + span*i/7 fractions, which produced unreadable labels like
    # 3.1/4.3/6.6/7.7/8.9. Ticks landing outside the padded [x_lo, x_hi]
    # window are dropped, matching the beeswarm call site's own filter.
    for val in nice_ticks_range(x_lo, x_hi, 7):
        if val < x_lo - 1e-9 or val > x_hi + 1e-9:
            continue
        tx = x_for(val)
        parts.append(
            f'<text x="{tx:.1f}" y="{axis_y + 20:.1f}" font-size="11" font-family="{mono_family}" '
            f'fill="{SECONDARY}" text-anchor="middle">{val:.3g}</text>'
        )
    parts.append(
        f'<text x="{plot_x + plot_w / 2:.1f}" y="{axis_y + 42:.1f}" font-size="13" '
        f'fill="{INK}" text-anchor="middle">x</text>'
    )

    parts.append(fullscreen_control(width, height, mode))
    parts.append("</svg>")
    return "\n".join(parts)


def make_kde1d(
    data: Optional[List[Dict[str, Any]]] = None,
    *,
    out: Optional[Path | str] = None,
    title: str = "Estimated Density",
    subtitle: str = "Gaussian kernel density estimate",
    y_axis_title: str = "Density",
    width: int = 620,
    height: int = 380,
    mode: str = "self-contained",
    accessibility: str = "universal",
    theme: str = "corporate",
) -> Path:
    """Render a hand-authored 1-D KDE and write the SVG to *out*.

    Parameters
    ----------
    data : list[dict[str, Any]] or None
        Rows with key ``x`` (float). Defaults to DEMO_DATA.
    out : Path, str, or None
        Output path (.svg). Defaults to ``assets/svg-examples/kde1d.svg``.
    title, subtitle : str
        Chart text.
    y_axis_title : str
        Forwarded to :func:`build_svg` (see there).
    width, height : int
        Canvas size in pixels.
    mode, accessibility : str
        Forwarded to :func:`build_svg`.
    theme : str, optional
        Visual theme. Forwarded to :func:`build_svg`.

    Returns
    -------
    Path
        Absolute path to the written SVG file.

    Examples
    --------
    >>> p = make_kde1d()
    >>> p.exists()
    True
    """
    svg = build_svg(data, title=title, subtitle=subtitle, y_axis_title=y_axis_title, width=width, height=height,
                     mode=mode, accessibility=accessibility, theme=theme)
    dest = Path(out) if out else svg_example_path(__file__, "kde1d")
    return write_svg(dest, svg, theme=theme)


def main() -> None:
    """CLI entry point: build the SVG and write it to disk."""
    render_cli(__file__, "kde1d", build_svg, description="Generate a 1-D kernel density estimate.")



# ── kit: the data comes from data.csv ─────────────────────────────────────
# The generator keeps its own DEMO_DATA above as a fallback and as a record
# of the expected column names. When data.csv is present (it ships with this
# kit), it wins: edit the CSV, re-run this file, and the figure changes.
from sprezzature_svg import load_rows  # noqa: E402

try:
    DEMO_DATA = load_rows("data.csv") or DEMO_DATA
except FileNotFoundError:
    pass


if __name__ == "__main__":
    main()
