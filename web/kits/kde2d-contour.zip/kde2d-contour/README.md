# kde2d-contour — standalone figure

The `kde2d-contour` figure from the Sprezzature gallery, with everything needed to
rebuild and change it. Nothing to compile, no account, no framework.

## What is in here

| File | Role |
|---|---|
| `make_kde2d_contour.py` | The generator. This is the interesting one: it computes the geometry and writes the SVG tag by tag. |
| `sprezzature_svg.py` | The drawing engine: scales, SVG paths, palette, label placement, hover chrome. |
| `data.csv` | The data. Edit it, re-run, the figure changes. |
| `kde2d-contour.svg` | The figure as built, interactive. |
| `requirements.txt` | Pinned to the exact versions this was verified against. |

## Run it

```sh
python3 -m pip install -r requirements.txt
python3 make_kde2d_contour.py
# → wrote kde2d-contour.svg
```

## Look at the result

The SVG opens **in a browser**, like a page:

```sh
open kde2d-contour.svg        # macOS
xdg-open kde2d-contour.svg    # Linux
start kde2d-contour.svg       # Windows
```

That is where the figure comes alive: the hover tooltips are written into the
SVG itself, in CSS, with no JavaScript at all. Double-clicking it from a file
manager works too. To put it in a web page, use
`<object data="kde2d-contour.svg"></object>` or paste the SVG straight into the HTML.

**The one gotcha**: inside an `<img>` tag a browser blocks external requests,
so the Google Fonts the SVG links will not load and the figure falls back to a
system typeface. Everything else renders normally.

## Change it

Edit the numbers in `data.csv` and run it again. Beyond that,
`python3 make_kde2d_contour.py --help` lists the options available (title, dimensions,
accessibility level, theme, …).

---

From [sprezzature-figures](https://github.com/warith-harchaoui/sprezzature-figures) ·
Full gallery: <https://sprezzature.ai/figures.html> ·
Warith Harchaoui, Ph.D.
