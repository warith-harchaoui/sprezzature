#!/usr/bin/env python3
"""Generate a publication-quality **mosaic / Marimekko** chart as a standalone SVG.

A mosaic (Marimekko) plot shows how a whole splits along *two* categorical
dimensions at once. Each **column** is a first-level category whose *width*
encodes that category's share of the grand total; within a column the stacked
**segments** encode a second categorical proportion by *height*. The area of any
tile is therefore proportional to a joint frequency (width times height), which
lets a reader compare both marginals and the cells in a single view.

Rect widths are data-driven off a running cumulative on the same axis,
so the figure is assembled as a hand-authored SVG string. The output
matches the sprezzature-figures
house style: Roboto typography, the Apple-system palette from
:mod:`_style`, ink ``#1D1D1F`` on a white ground, rounded corners, native
``<title>`` tooltips, and a CSS ``:hover`` lift with a ``prefers-reduced-motion``
guard.

The final artifact is always the SVG at
``assets/svg-examples/mosaic.svg``; running this module writes it.

Usage
-----
    python make_mosaic.py            # writes assets/svg-examples/mosaic.svg
    python make_mosaic.py --out x.svg

Style rules: numpy docstrings, full typing, dict-as-record over ad-hoc classes.

Author
------
`Warith Harchaoui, Ph.D. <https://www.linkedin.com/in/warith-harchaoui/>`_
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Any, Dict, List, Optional
from xml.sax.saxutils import escape

from sprezzature_svg import (  # noqa: E402
    forced_color_patterns,
    load_palette,
    os_adaptive_style,
    os_dark_style,
)
from sprezzature_svg import render_cli, svg_example_path, write_svg  # noqa: E402
from sprezzature_svg import fmt_compact, foreground_tip_css, svg_open, tooltip_bubble, xml_escape  # noqa: E402
from sprezzature_svg import fullscreen_control  # noqa: E402
from sprezzature_svg import chrome_stack_for_theme  # noqa: E402


# --------------------------------------------------------------------------- #
# Communicative fake data                                                       #
# --------------------------------------------------------------------------- #
# One quarter of online-store checkouts, split by the device a shopper used
# (column width = share of all orders) and by how they paid (segment height =
# share within that device). The story: on phones, wallets (Apple / Google Pay)
# already beat cards — the reason the mobile column leans toward the wallet hue.

#: First-level categories (columns). ``share`` is the fraction of all orders.
DEVICES: List[Dict[str, Any]] = [
    {"name": "Mobile", "share": 0.54},
    {"name": "Desktop", "share": 0.31},
    {"name": "Tablet", "share": 0.15},
]

#: Second-level categories (stacked segments). Order = paint / legend order.
METHODS: List[str] = ["Wallet", "Card", "Buy-now-pay-later", "Bank transfer"]

#: Within-column composition: {device -> {method -> fraction (sums to 1)}}.
COMPOSITION: Dict[str, Dict[str, float]] = {
    "Mobile":  {"Wallet": 0.48, "Card": 0.32, "Buy-now-pay-later": 0.15, "Bank transfer": 0.05},
    "Desktop": {"Wallet": 0.22, "Card": 0.55, "Buy-now-pay-later": 0.14, "Bank transfer": 0.09},
    "Tablet":  {"Wallet": 0.30, "Card": 0.47, "Buy-now-pay-later": 0.15, "Bank transfer": 0.08},
}

TITLE = "On phones, wallets have overtaken cards"
SUBTITLE = "Share of online-store checkouts by device and payment method"


# --------------------------------------------------------------------------- #
# Palette                                                                       #
# --------------------------------------------------------------------------- #
def method_colors(accessibility: str = "universal", theme: str = "corporate") -> Dict[str, str]:
    """Map each payment method to a house-palette hex.

    Wallet (the story's hero) takes the brand Blue; the rest read as a calm,
    CVD-distinguishable spread so the eye lands on Wallet first.

    Parameters
    ----------
    accessibility : str, optional
        Palette accessibility level threaded to :func:`load_palette`
        (``"universal"``, ``"high-contrast"``, ``"monochrome"``,
        ``"deuteranopia"``, ``"protanopia"`` or ``"tritanopia"``). Defaults
        to ``"universal"``, the colour-vision-safe standard.
    theme : str, optional
        Forwarded to :func:`load_palette`. Defaults to ``"corporate"``.

    Returns
    -------
    dict of str to str
        ``{method_name: "#RRGGBB"}`` for every entry in :data:`METHODS`.
    """
    pal = load_palette(accessibility, theme=theme)
    return {
        "Wallet":            pal.get("Blue", "#007AFF"),
        "Card":              pal.get("Teal", "#5AC8FA"),
        "Buy-now-pay-later": pal.get("Orange", "#FF9500"),
        "Bank transfer":     pal.get("Gray", "#8E8E93"),
    }


# --------------------------------------------------------------------------- #
# Geometry helpers                                                              #
# --------------------------------------------------------------------------- #


def _method_slug(method: str) -> str:
    """Slugify a payment-method name into a stable CSS class token.

    Lower-cases the name and replaces every run of non-alphanumerics with a
    single hyphen, so ``"Buy-now-pay-later"`` becomes ``"buy-now-pay-later"``
    and ``"Bank transfer"`` becomes ``"bank-transfer"``. Used to give each tile
    a per-method class (``tile-wallet`` …) that the OS-adaptive rule can target.

    Parameters
    ----------
    method : str
        A payment-method name from :data:`METHODS`.

    Returns
    -------
    str
        A CSS-safe slug of the method name.
    """
    out = []
    prev_dash = False
    for ch in method.lower():
        if ch.isalnum():
            out.append(ch)
            prev_dash = False
        elif not prev_dash:
            out.append("-")
            prev_dash = True
    return "".join(out).strip("-")


def build_tiles(
    plot_x: float,
    plot_y: float,
    plot_w: float,
    plot_h: float,
    gap: float,
    accessibility: str = "universal",
    devices: Optional[List[Dict[str, Any]]] = None,
    composition: Optional[Dict[str, Dict[str, float]]] = None,
    theme: str = "corporate",
) -> List[Dict[str, Any]]:
    """Compute one rect record per (device, method) mosaic tile.

    Parameters
    ----------
    plot_x, plot_y : float
        Top-left corner of the plotting area, in SVG user units.
    plot_w, plot_h : float
        Width and height of the plotting area.
    gap : float
        Horizontal white gap drawn between adjacent columns.
    accessibility : str, optional
        Palette accessibility level threaded to :func:`method_colors`
        (``"universal"``, ``"high-contrast"``, ``"monochrome"``,
        ``"deuteranopia"``, ``"protanopia"`` or ``"tritanopia"``). Defaults
        to ``"universal"``, the colour-vision-safe standard.
    devices, composition : optional
        Override :data:`DEVICES` / :data:`COMPOSITION`; see
        :func:`render_svg`.
    theme : str, optional
        Forwarded to :func:`method_colors`. Defaults to ``"corporate"``.

    Returns
    -------
    list of dict
        Each record carries ``x``, ``y``, ``w``, ``h`` (tile geometry),
        ``device``, ``method``, ``color``, and ``pct`` (within-column share, in
        percent) so the renderer can draw and label without recomputing.
    """
    devices = devices if devices else DEVICES
    composition = composition if composition else COMPOSITION
    colors = method_colors(accessibility, theme=theme)
    n_gaps = len(devices) - 1
    inner_w = plot_w - gap * n_gaps  # width available to the columns themselves
    total_share = sum(d["share"] for d in devices)

    tiles: List[Dict[str, Any]] = []
    cursor_x = plot_x
    for dev in devices:
        col_w = inner_w * (dev["share"] / total_share)
        comp = composition.get(dev["name"], {})
        cursor_y = plot_y
        for method in METHODS:
            frac = comp.get(method, 0.0)
            seg_h = plot_h * frac
            tiles.append({
                "x": cursor_x,
                "y": cursor_y,
                "w": col_w,
                "h": seg_h,
                "device": dev["name"],
                "method": method,
                "color": colors[method],
                "pct": frac * 100.0,
                "share": dev["share"] * 100.0,
            })
            cursor_y += seg_h
        cursor_x += col_w + gap
    return tiles


# --------------------------------------------------------------------------- #
# SVG assembly                                                                  #
# --------------------------------------------------------------------------- #
def render_svg(
    devices: Optional[List[Dict[str, Any]]] = None,
    composition: Optional[Dict[str, Dict[str, float]]] = None,
    y_axis_title: str = "Share within device",
    legend_title: str = "Payment method",
    mode: str = "self-contained",
    accessibility: str = "universal",
    theme: str = "corporate",
) -> str:
    """Assemble the full mosaic SVG document as a string.

    Parameters
    ----------
    devices : list of dict or None
        First-level (column) categories, each ``{"name": str, "share":
        float}``. Defaults to :data:`DEVICES`.
    composition : dict of str to dict or None
        Within-column composition, ``{device_name: {method_name: fraction}}``
        (fractions should sum to ~1 per device). Defaults to
        :data:`COMPOSITION`; only the payment methods already in
        :data:`METHODS` are drawn (a custom device missing a method is
        simply treated as 0 for that segment).
    y_axis_title : str, optional
        Vertical axis label (was hardcoded ``"Share within device"``).
    legend_title : str, optional
        Legend heading (was hardcoded ``"Payment method"``).
    mode : str, optional
        Interactivity mode for the shared fullscreen control (see
        :mod:`_interactive`). Three modes: ``"self-contained"`` (default) ships
        a self-carrying fullscreen button and its wiring script; ``"external"``
        ships no internal button and defers to a page-level module; ``"static"``
        ships no interactivity at all. The static PNG raster is byte-identical
        across modes because the button starts hidden.
    accessibility : str, optional
        Palette accessibility level (``"universal"``, ``"high-contrast"``,
        ``"monochrome"``, ``"deuteranopia"``, ``"protanopia"`` or
        ``"tritanopia"``). Defaults to ``"universal"``, the
        colour-vision-safe standard, which leaves the shipped palette
        unchanged.
    theme : str, optional
        Visual theme: ``"corporate"`` (default, Roboto -- byte-identical to
        the pre-theme render) or ``"academic"`` (LaTeX-style Latin Modern).
        See :func:`sprezzature_figures.fonts.chrome_stack_for_theme`.

    Returns
    -------
    str
        A complete, standalone ``<svg>`` document (house style, accessible
        ``<title>``/``<desc>``, native tooltips, CSS hover lift).
    """
    # Canvas + plotting frame. Poster-scale so tiles and labels read from a
    # distance; the right rail holds the legend, the top rail the title.
    width, height = 1120, 820
    plot_x, plot_y = 96.0, 216.0
    plot_w, plot_h = width - plot_x - 300.0, 520.0  # leave room for a right legend
    gap = 16.0

    ink = "#1D1D1F"
    muted = "#6E6E73"
    hairline = "#E5E5EA"

    devices = devices if devices else DEVICES
    composition = composition if composition else COMPOSITION
    tiles = build_tiles(
        plot_x, plot_y, plot_w, plot_h, gap, accessibility,
        devices=devices, composition=composition, theme=theme,
    )

    parts: List[str] = []
    parts.append(svg_open(width, height, "mosaic-t", "mosaic-d", font_family=chrome_stack_for_theme(theme)))
    parts.append(f'<title id="mosaic-t">{escape(TITLE)}</title>')
    parts.append(
        '<desc id="mosaic-d">Marimekko mosaic: column widths are each device\'s share of all '
        'online checkouts (Mobile widest at 54 percent), and each column stacks payment methods '
        'by their within-device share. On Mobile, Wallet is the tallest segment, overtaking Card.</desc>'
    )

    # Style block: hover lift + focus ring, guarded by reduced-motion. The
    # OS-adaptive block is appended last (additive; every rule lives inside a
    # media query, so the default render is byte-for-byte unchanged). Under
    # prefers-contrast the four payment-method tile fills deepen to their
    # high-contrast hues; deepening only strengthens the white in-tile labels
    # and leaves Card's ink label readable.
    method_hex = method_colors(accessibility)
    tile_series = {
        ".tile-wallet": method_hex["Wallet"],
        ".tile-card": method_hex["Card"],
        ".tile-buy-now-pay-later": method_hex["Buy-now-pay-later"],
        ".tile-bank-transfer": method_hex["Bank transfer"],
    }
    # Under Windows High Contrast / forced-colors the ~4-colour system palette
    # cannot preserve four distinct method hues, and the legend maps colour →
    # method, so colour is the sole per-series key. Each method tile therefore
    # takes a distinct CanvasText pattern (hatch / dots / cross) on Canvas —
    # identity by texture, not hue. The patterns live in <defs> and are referenced
    # only inside the forced-colors media query, so the default render is
    # unchanged.
    fcp_defs, fcp_style = forced_color_patterns(
        [
            ".tile-wallet",
            ".tile-card",
            ".tile-buy-now-pay-later",
            ".tile-bank-transfer",
        ],
        prefix="mos-fcp",
    )
    parts.append(
        "<style>"
        ".tile{transition:transform .18s ease, filter .18s ease;transform-box:fill-box;transform-origin:center;}"
        ".tile:hover,.tile:focus{filter:brightness(1.06);transform:scale(1.015);outline:none;}"
        ".tile:focus{stroke:#1D1D1F;stroke-width:2;}"
        ".tip{opacity:0;pointer-events:none;transition:opacity .12s ease}"
        + foreground_tip_css(len(tiles), mark_prefix="tile", tip_prefix="tile-tip")
        + "@media (prefers-reduced-motion: reduce){.tile{transition:none;}.tile:hover,.tile:focus{transform:none;}.tip{transition:none}}"
        + os_adaptive_style(tile_series, role="fill")
        + fcp_style
        # Additive OS dark mode: dark paper + light ink (default ink_map); the
        # payment-method tile hues are data, left alone. The focus ring and the
        # hairline column rules flip to light so they read on the dark surface.
        + os_dark_style(
            extra=(
                '[stroke="#E5E5EA"]{stroke:#3A3A3E;}'
                ".tile:focus{stroke:#F2F2F7;}"
            )
        )
        + "</style>"
    )
    # Forced-colors pattern tiles (referenced only inside the media query above).
    parts.append(f"<defs>{fcp_defs}</defs>")

    # Background.
    parts.append(f'<rect width="{width}" height="{height}" fill="#FFFFFF"/>')

    # Title + subtitle.
    parts.append(f'<text x="{fmt_compact(plot_x, decimals=2)}" y="66" font-size="34" font-weight="700" fill="{ink}">{escape(TITLE)}</text>')
    parts.append(f'<text x="{fmt_compact(plot_x, decimals=2)}" y="102" font-size="20" fill="{muted}">{escape(SUBTITLE)}</text>')

    # Left axis label (vertical) — within-device composition axis.
    axis_cx = plot_x - 62.0
    axis_cy = plot_y + plot_h / 2.0
    parts.append(
        f'<text x="{fmt_compact(axis_cx, decimals=2)}" y="{fmt_compact(axis_cy, decimals=2)}" font-size="18" fill="{muted}" '
        f'text-anchor="middle" transform="rotate(-90 {fmt_compact(axis_cx, decimals=2)} {fmt_compact(axis_cy, decimals=2)})">{xml_escape(y_axis_title)}</text>'
    )

    # Vertical percentage ticks on the left (0 / 25 / 50 / 75 / 100 %).
    for pct in (0, 25, 50, 75, 100):
        ty = plot_y + plot_h * (pct / 100.0)
        parts.append(
            f'<text x="{fmt_compact(plot_x - 18, decimals=2)}" y="{fmt_compact(ty + 6, decimals=2)}" font-size="15" fill="{muted}" '
            f'text-anchor="end" font-family="Roboto Mono, monospace">{pct}%</text>'
        )
        parts.append(
            f'<line x1="{fmt_compact(plot_x - 12, decimals=2)}" y1="{fmt_compact(ty, decimals=2)}" x2="{fmt_compact(plot_x, decimals=2)}" y2="{fmt_compact(ty, decimals=2)}" '
            f'stroke="{hairline}" stroke-width="1.5"/>'
        )

    # Tiles, grouped so hover/focus works per rect. Every tile is drawn
    # first, every one of its bubbles appended afterward (see tile_tips
    # below): SVG paints in document order regardless of hover state, so a
    # bubble sitting next to its own tile would be covered by any tile
    # drawn after it.
    rx = 5.0
    tile_tips: List[str] = []
    for tile_i, t in enumerate(tiles):
        label = (
            f"{t['device']} - {t['method']}: {t['pct']:.0f}% of {t['device']} orders "
            f"({t['device']} = {t['share']:.0f}% of all orders)"
        )
        parts.append(
            f'<rect id="tile-{tile_i}" class="tile tile-{_method_slug(t["method"])} hit" tabindex="0" '
            f'x="{fmt_compact(t["x"], decimals=2)}" y="{fmt_compact(t["y"], decimals=2)}" '
            f'width="{fmt_compact(t["w"], decimals=2)}" height="{fmt_compact(t["h"], decimals=2)}" rx="{fmt_compact(rx, decimals=2)}" '
            f'fill="{t["color"]}" stroke="#FFFFFF" stroke-width="3" '
            f'role="img" aria-label="{escape(label)}"/>'
        )
        tile_tips.append(
            tooltip_bubble(
                t["x"] + t["w"] / 2.0, t["y"] - 12.0,
                [
                    f"{t['device']} · {t['method']}",
                    f"{t['pct']:.0f}% of {t['device']} orders",
                    f"{t['device']} = {t['share']:.0f}% of all orders",
                ],
                anchor="middle", canvas_w=width, canvas_h=height,
                ink=ink, secondary=muted, border=hairline,
                elem_id=f"tile-tip-{tile_i}",
            )
        )
        # In-tile percentage label when the segment is tall + wide enough.
        if t["h"] >= 34 and t["w"] >= 80:
            lx = t["x"] + t["w"] / 2.0
            ly = t["y"] + t["h"] / 2.0 + 6.0
            txt_fill = "#FFFFFF" if t["method"] != "Card" else ink
            parts.append(
                f'<text x="{fmt_compact(lx, decimals=2)}" y="{fmt_compact(ly, decimals=2)}" font-size="17" fill="{txt_fill}" '
                f'text-anchor="middle" font-family="Roboto Mono, monospace" '
                f'pointer-events="none">{t["pct"]:.0f}%</text>'
            )
    parts.extend(tile_tips)

    # Column headers: device name + its width-share, above each column.
    for dev in devices:
        # Find the column's tiles to recover its x-extent.
        col = [t for t in tiles if t["device"] == dev["name"]]
        cx = col[0]["x"] + col[0]["w"] / 2.0
        parts.append(
            f'<text x="{fmt_compact(cx, decimals=2)}" y="{fmt_compact(plot_y - 44, decimals=2)}" font-size="20" font-weight="700" '
            f'fill="{ink}" text-anchor="middle">{escape(dev["name"])}</text>'
        )
        parts.append(
            f'<text x="{fmt_compact(cx, decimals=2)}" y="{fmt_compact(plot_y - 20, decimals=2)}" font-size="15" fill="{muted}" '
            f'text-anchor="middle" font-family="Roboto Mono, monospace">{dev["share"] * 100:.0f}% of orders</text>'
        )

    # Bottom axis label — the columns encode order share by width.
    parts.append(
        f'<text x="{fmt_compact(plot_x + plot_w / 2, decimals=2)}" y="{fmt_compact(plot_y + plot_h + 54, decimals=2)}" font-size="18" '
        f'fill="{muted}" text-anchor="middle">Column width = share of all orders</text>'
    )

    # Legend panel on the right.
    legend_x = plot_x + plot_w + 56.0
    legend_y = plot_y + 12.0
    colors = method_colors(accessibility)
    parts.append(
        f'<text x="{fmt_compact(legend_x, decimals=2)}" y="{fmt_compact(legend_y - 20, decimals=2)}" font-size="18" font-weight="700" '
        f'fill="{ink}">{xml_escape(legend_title)}</text>'
    )
    for i, method in enumerate(METHODS):
        row_y = legend_y + i * 42.0
        parts.append(
            f'<rect x="{fmt_compact(legend_x, decimals=2)}" y="{fmt_compact(row_y, decimals=2)}" width="22" height="22" rx="5" '
            f'fill="{colors[method]}"/>'
        )
        parts.append(
            f'<text x="{fmt_compact(legend_x + 34, decimals=2)}" y="{fmt_compact(row_y + 17, decimals=2)}" font-size="17" '
            f'fill="{ink}">{escape(method)}</text>'
        )

    # --- shared fullscreen control. The right rail (300px) holds the legend,
    #     so inset the button well left of it. ---
    parts.append(fullscreen_control(width, height, mode, inset=320.0))

    parts.append("</svg>")
    return "\n".join(parts)


# --------------------------------------------------------------------------- #
# Contract wiring — DEMO_DATA (row-list) + make_mosaic()                      #
# --------------------------------------------------------------------------- #
#: The registry contract wants a flat row list; each row is one
#: (device, method) cell of the mosaic: the column's own share of the whole
#: plus that cell's within-column fraction.
DEMO_DATA: List[Dict[str, Any]] = [
    {"device": dev["name"], "share": dev["share"], "method": method, "fraction": COMPOSITION[dev["name"]][method]}
    for dev in DEVICES
    for method in METHODS
]


def _rows_to_mosaic(
    rows: List[Dict[str, Any]],
) -> "tuple[List[Dict[str, Any]], Dict[str, Dict[str, float]]]":
    """Reshape DEMO_DATA-style rows back into ``(devices, composition)``."""
    devices: List[Dict[str, Any]] = []
    seen_dev: set = set()
    composition: Dict[str, Dict[str, float]] = {}
    for r in rows:
        name = str(r["device"])
        if name not in seen_dev:
            seen_dev.add(name)
            devices.append({"name": name, "share": float(r["share"])})
        composition.setdefault(name, {})[str(r["method"])] = float(r["fraction"])
    return devices, composition


def make_mosaic(
    data: Optional[List[Dict[str, Any]]] = None,
    *,
    out: Optional[Path | str] = None,
    title: str = "",
    y_axis_title: str = "Share within device",
    legend_title: str = "Payment method",
    mode: str = "self-contained",
    accessibility: str = "universal",
    theme: str = "corporate",
) -> Path:
    """Render the mosaic / Marimekko chart and write the SVG to *out*.

    Parameters
    ----------
    data : list[dict[str, Any]] or None
        Rows shaped ``{"device", "share", "method", "fraction"}`` — one row
        per (device, method) cell. Defaults to :data:`DEMO_DATA`. ``title``
        is accepted for signature parity with the rest of the gallery and
        is currently a documented no-op.
    out : Path, str, or None
        Output path. Defaults to ``assets/svg-examples/mosaic.svg``.
    y_axis_title, legend_title : str, optional
        Forwarded to :func:`render_svg`.
    mode, accessibility : str
        Forwarded to :func:`render_svg`.
    theme : str, optional
        Visual theme. Forwarded to :func:`render_svg`.

    Returns
    -------
    Path
        Absolute path to the written SVG file.
    """
    _ = title
    rows = data if data else DEMO_DATA
    devices, composition = _rows_to_mosaic(rows)
    svg = render_svg(
        devices=devices,
        composition=composition,
        y_axis_title=y_axis_title,
        legend_title=legend_title,
        mode=mode,
        accessibility=accessibility,
        theme=theme,
    )
    dest = Path(out) if out else svg_example_path(__file__, "mosaic")
    return write_svg(dest, svg, theme=theme)


# --------------------------------------------------------------------------- #
# CLI                                                                           #
# --------------------------------------------------------------------------- #
def main() -> None:
    """Write the mosaic SVG to disk."""
    render_cli(__file__, "mosaic", render_svg, description="Render the mosaic / Marimekko example SVG.")



# ── kit: the data comes from data.csv ─────────────────────────────────────
# The generator keeps its own DEMO_DATA above as a fallback and as a record
# of the expected column names. When data.csv is present (it ships with this
# kit), it wins: edit the CSV, re-run this file, and the figure changes.
from sprezzature_svg import load_rows  # noqa: E402

try:
    DEMO_DATA = load_rows("data.csv") or DEMO_DATA
except FileNotFoundError:
    pass


if __name__ == "__main__":
    main()
