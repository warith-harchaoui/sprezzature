#!/usr/bin/env python3
"""
make_network — publication-quality node-link network as a hand-authored SVG.

A node-link diagram places every entity as a node and draws an edge for
every relationship between two entities. It answers "who is connected to
whom, and who sits at the centre?" far better than an adjacency matrix or
a list of pairs, because the eye reads clusters, hubs, and bridges
directly from the layout.

This figure is built as an SVG string by hand. The layout is a small,
deterministic force-directed relaxation computed in pure Python (no
scientific stack): nodes repel each other (Coulomb-like), edges pull
their endpoints together (Hooke-like springs), and a gentle gravity keeps
the whole graph centred. A fixed random seed makes every run identical, so
the committed SVG is reproducible.

House style follows ``_style.py`` / ``bar.vl.json``: Roboto type, the
Apple-system categorical palette, ink ``#1D1D1F`` on white, rounded label
treatment, a start-anchored title plus a one-line takeaway subtitle.

Interaction (no JavaScript): every node carries a native ``<title>``
tooltip, and a pure-CSS ``:hover`` / ``:focus-within`` rule fades the
whole graph except the hovered node, its incident edges, and its direct
neighbours: the "hover a node to highlight its neighbours" affordance
that suits this capability. The graph is otherwise static, so ``animated``
is false and ``interactive`` is true.

Running the module writes the SVG to
``sprezzature-figures/assets/svg-examples/network.svg``.

Author
------
`Warith Harchaoui, Ph.D. <https://www.linkedin.com/in/warith-harchaoui/>`_
"""

from __future__ import annotations

import math
import random
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from xml.sax.saxutils import escape

from sprezzature_svg import BG, INK, load_palette, os_adaptive_style, os_dark_style  # noqa: E402
from sprezzature_svg import render_cli, svg_example_path, write_svg  # noqa: E402
from sprezzature_svg import fullscreen_control  # noqa: E402
from sprezzature_svg import foreground_tip_css, svg_open, tooltip_bubble  # noqa: E402
from sprezzature_svg import text_width  # noqa: E402
from sprezzature_svg import chrome_stack_for_theme  # noqa: E402

# ------------------------------------------------------------------
# Canvas + house-style tokens
# ------------------------------------------------------------------
WIDTH = 1200
HEIGHT = 980
_MODULE_WIDTH, _MODULE_HEIGHT = WIDTH, HEIGHT  # baseline size before per-graph scaling
# y where the graph area begins (below the title/subtitle/hint block). Large enough that
# even a max-radius node (52px, see _radius) sitting at the very top of the layout box
# clears the hint line at y=134 with margin, instead of visually overlapping it.
PLOT_TOP = 210
PLOT_PAD = 92              # inner margin around the layout box

SUBINK = "#6E6E73"          # secondary text
EDGE = "#C7C7CC"            # resting edge colour (light neutral)

FONT = "Roboto, system-ui, sans-serif"


# ------------------------------------------------------------------
# The story: the service-to-service call
# graph of an online-store backend. A node is a microservice; an edge
# means "the first service makes synchronous calls to the second". The
# node's colour marks its team and its size marks how many other
# services depend on it (in-degree). The takeaway: the Auth service is a
# hidden single point of failure — almost everything calls it, so if it
# stalls, the whole store stalls. Hovering any service lights up exactly
# what it touches.
# ------------------------------------------------------------------
# Each service: (id, label, team). Team drives colour.
SERVICES: List[Tuple[str, str, str]] = [
    ("auth", "Auth", "Platform"),
    ("gateway", "API Gateway", "Platform"),
    ("web", "Web App", "Storefront"),
    ("mobile", "Mobile BFF", "Storefront"),
    ("catalog", "Catalog", "Storefront"),
    ("search", "Search", "Storefront"),
    ("cart", "Cart", "Checkout"),
    ("checkout", "Checkout", "Checkout"),
    ("payments", "Payments", "Checkout"),
    ("orders", "Orders", "Fulfilment"),
    ("shipping", "Shipping", "Fulfilment"),
    ("inventory", "Inventory", "Fulfilment"),
    ("notify", "Notifications", "Growth"),
    ("profile", "Profiles", "Growth"),
]

# Directed calls: (caller, callee). The graph is drawn undirected for the
# layout but the tooltip and degree use the full call list.
CALLS: List[Tuple[str, str]] = [
    ("gateway", "auth"),
    ("web", "gateway"),
    ("mobile", "gateway"),
    ("web", "catalog"),
    ("mobile", "catalog"),
    ("web", "search"),
    ("catalog", "search"),
    ("web", "cart"),
    ("mobile", "cart"),
    ("cart", "auth"),
    ("cart", "catalog"),
    ("checkout", "cart"),
    ("checkout", "auth"),
    ("checkout", "payments"),
    ("checkout", "orders"),
    ("payments", "auth"),
    ("orders", "auth"),
    ("orders", "inventory"),
    ("orders", "shipping"),
    ("orders", "notify"),
    ("shipping", "notify"),
    ("catalog", "inventory"),
    ("profile", "auth"),
    ("web", "profile"),
    ("mobile", "profile"),
    ("notify", "profile"),
    ("search", "catalog"),
]

# Team → brand hue. Built from the palette at render time so the accessibility
# level can remap the hues.
def _team_color(accessibility: str = "universal", theme: str = "corporate") -> Dict[str, str]:
    """Return the team → hex mapping at a given accessibility level.

    Parameters
    ----------
    accessibility : str, optional
        Palette accessibility level threaded into :func:`_style.load_palette`.
        ``"universal"`` (default) is the colour-vision-safe standard.
    theme : str, optional
        Forwarded to :func:`_style.load_palette`. Defaults to ``"corporate"``.

    Returns
    -------
    dict of str to str
        Mapping ``{team_name: hex}`` for each of the five service teams.
    """
    palette = load_palette(accessibility, theme=theme)
    return {
        "Platform": palette.get("Blue", "#007AFF"),
        "Storefront": palette.get("Teal", "#5AC8FA"),
        "Checkout": palette.get("Orange", "#FF9500"),
        "Fulfilment": palette.get("Green", "#34C759"),
        "Growth": palette.get("Purple", "#AF52DE"),
    }

#: Fallback hue-name cycling order for custom team sets beyond the five the
#: default story names (kept in the same order the default teams already use
#: so a custom graph whose teams happen to appear in the same order gets the
#: same hues).
_TEAM_HUE_ORDER = ["Blue", "Teal", "Orange", "Green", "Purple", "Pink", "Yellow", "Indigo", "Gray"]


def _team_colors_for(
    teams: List[str], accessibility: str = "universal", theme: str = "corporate"
) -> Dict[str, str]:
    """Return a generic ``{team: hex}`` map by cycling house hues in order.

    Used when :func:`build_svg` is given a custom ``services`` list whose
    team names are not the five the default microservice story names.
    """
    palette = load_palette(accessibility, theme=theme)
    return {
        team: palette.get(_TEAM_HUE_ORDER[i % len(_TEAM_HUE_ORDER)], "#8E8E93")
        for i, team in enumerate(teams)
    }


def _team_slug(team: str) -> str:
    """Return a CSS-class-safe slug for a team name (lower-cased alphanumerics).

    Parameters
    ----------
    team : str
        A team name from :data:`SERVICES` (e.g. ``"Platform"``).

    Returns
    -------
    str
        The slug used in the ``team-<slug>`` node-circle class and in the
        OS-adaptive ``@media`` selectors (e.g. ``"platform"``).
    """
    return "".join(ch.lower() if ch.isalnum() else "-" for ch in team).strip("-")


SEED = 20260725  # fixed so the committed SVG is byte-reproducible
# Extra clearance (px) added on top of a node-pair's summed radii before the
# overlap-avoidance term in `_layout` kicks in — leaves breathing room for the
# label that sits just below each circle, not just the circle itself.
OVERLAP_CLEARANCE = 34.0
OVERLAP_STRENGTH = 3.2


# ------------------------------------------------------------------
# Force-directed layout (pure Python, no numpy)
# ------------------------------------------------------------------
def _layout(
    ids: List[str],
    edges: List[Tuple[str, str]],
    width: float,
    height: float,
    radii: Optional[Dict[str, float]] = None,
    iterations: int = 520,
) -> Dict[str, Tuple[float, float]]:
    """Relax nodes into a force-directed layout inside a box.

    A tiny Fruchterman-Reingold-style simulation: every pair of nodes
    repels with an inverse-distance force, every edge acts as a spring
    pulling its endpoints toward an ideal length, and a temperature that
    cools each step caps how far any node may move, so the layout settles
    instead of oscillating. A weak pull toward the box centre keeps
    disconnected drift in check.

    Plain Fruchterman-Reingold treats every node as a dimensionless point,
    so on a dense graph (many nodes, high-degree hubs sized up to 52px)
    two circles can converge closer than their own radii and visibly
    overlap even at equilibrium — the "spaghetti" hairball look. On top
    of the point-charge repulsion, ``radii`` (when given) adds a linear
    penalty once two circles are closer than the sum of their radii plus
    label clearance, so the simulation actively pushes surfaces apart
    instead of just centres.

    Parameters
    ----------
    ids : list of str
        Node identifiers.
    edges : list of tuple of str
        Undirected endpoint pairs ``(a, b)``.
    width, height : float
        Size of the layout box the coordinates must fit inside.
    radii : dict of str to float, optional
        Per-node circle radius in pixels (see :func:`_radius`). When
        given, drives the overlap-avoidance term described above; omit
        to fall back to plain point-charge repulsion.
    iterations : int, optional
        Number of relaxation steps (default 520 — enough for a graph this
        size to reach a clean, uncrossed-looking arrangement).

    Returns
    -------
    dict of str to tuple of float
        ``{node_id: (x, y)}`` in the box's own pixel coordinates
        (0..width, 0..height), before translation onto the canvas.
    """
    rng = random.Random(SEED)
    n = len(ids)
    # Ideal edge length: scale so n nodes fill the box comfortably.
    area = width * height
    k = 0.92 * math.sqrt(area / max(n, 1))

    # Seed positions on a jittered circle — a stable, symmetric start that
    # relaxes into a pleasing layout far more reliably than pure noise.
    pos: Dict[str, List[float]] = {}
    for i, nid in enumerate(ids):
        ang = 2.0 * math.pi * i / n
        r = 0.32 * min(width, height) * (0.6 + 0.4 * rng.random())
        pos[nid] = [
            width / 2 + r * math.cos(ang) + rng.uniform(-8, 8),
            height / 2 + r * math.sin(ang) + rng.uniform(-8, 8),
        ]

    temp = 0.14 * min(width, height)  # initial max displacement per step
    cool = temp / (iterations + 1)

    adj = set()
    for a, b in edges:
        adj.add((a, b))
        adj.add((b, a))

    for _ in range(iterations):
        disp: Dict[str, List[float]] = {nid: [0.0, 0.0] for nid in ids}

        # Repulsion between every ordered pair.
        for i in range(n):
            a = ids[i]
            for j in range(i + 1, n):
                b = ids[j]
                dx = pos[a][0] - pos[b][0]
                dy = pos[a][1] - pos[b][1]
                dist = math.hypot(dx, dy) or 0.01
                force = (k * k) / dist
                if radii is not None:
                    min_sep = radii[a] + radii[b] + OVERLAP_CLEARANCE
                    if dist < min_sep:
                        force += (min_sep - dist) * OVERLAP_STRENGTH
                ux, uy = dx / dist, dy / dist
                disp[a][0] += ux * force
                disp[a][1] += uy * force
                disp[b][0] -= ux * force
                disp[b][1] -= uy * force

        # Attraction along edges.
        for a, b in edges:
            dx = pos[a][0] - pos[b][0]
            dy = pos[a][1] - pos[b][1]
            dist = math.hypot(dx, dy) or 0.01
            force = (dist * dist) / k
            ux, uy = dx / dist, dy / dist
            disp[a][0] -= ux * force
            disp[a][1] -= uy * force
            disp[b][0] += ux * force
            disp[b][1] += uy * force

        # Gentle gravity toward the centre so the graph stays framed.
        for nid in ids:
            gx = (width / 2 - pos[nid][0]) * 0.012
            gy = (height / 2 - pos[nid][1]) * 0.012
            disp[nid][0] += gx
            disp[nid][1] += gy

        # Apply, capped by the current temperature, then keep in-box.
        for nid in ids:
            dx, dy = disp[nid]
            d = math.hypot(dx, dy) or 0.01
            step = min(d, temp)
            pos[nid][0] += (dx / d) * step
            pos[nid][1] += (dy / d) * step
            pos[nid][0] = min(width, max(0.0, pos[nid][0]))
            pos[nid][1] = min(height, max(0.0, pos[nid][1]))

        temp = max(temp - cool, 0.0)

    return {nid: (p[0], p[1]) for nid, p in pos.items()}


# ------------------------------------------------------------------
# Degree + radius helpers
# ------------------------------------------------------------------
def _degrees(ids: List[str], calls: List[Tuple[str, str]]) -> Dict[str, int]:
    """Return the in-degree (number of distinct callers) per service.

    In-degree is the "how many services depend on me" measure — the one
    that reveals single points of failure — so it drives node size.

    Parameters
    ----------
    ids : list of str
        Service identifiers.
    calls : list of tuple of str
        Directed ``(caller, callee)`` pairs.

    Returns
    -------
    dict of str to int
        ``{service_id: in_degree}``.
    """
    indeg: Dict[str, set] = {nid: set() for nid in ids}
    for caller, callee in calls:
        if callee in indeg:
            indeg[callee].add(caller)
    return {nid: len(callers) for nid, callers in indeg.items()}


def _radius(indeg: int, max_indeg: int) -> float:
    """Map an in-degree to a node radius in pixels.

    Uses a square-root scale so *area* (not radius) tracks in-degree — the
    perceptually honest encoding for a circle-size legend.

    Parameters
    ----------
    indeg : int
        This node's in-degree.
    max_indeg : int
        The largest in-degree in the graph (sets the top of the scale).

    Returns
    -------
    float
        Circle radius in pixels.
    """
    r_min, r_max = 15.0, 52.0
    if max_indeg <= 0:
        return r_min
    frac = math.sqrt(indeg / max_indeg)
    return r_min + (r_max - r_min) * frac


# ------------------------------------------------------------------
# SVG emission
# ------------------------------------------------------------------
def build_svg(
    services: Optional[List[Tuple[str, str, str]]] = None,
    calls: Optional[List[Tuple[str, str]]] = None,
    mode: str = "self-contained",
    accessibility: str = "universal",
    title: Optional[str] = None,
    subtitle: Optional[str] = None,
    desc: Optional[str] = None,
    legend_title: str = "Owning team",
    hint: Optional[str] = None,
    theme: str = "corporate",
) -> str:
    """Assemble the full node-link network SVG document as a string.

    Parameters
    ----------
    services : list of tuple or None
        Each ``(id, label, team)``. Defaults to :data:`SERVICES`.
    calls : list of tuple or None
        Directed ``(caller_id, callee_id)`` pairs. Defaults to :data:`CALLS`.
        When a custom ``services``/``calls`` pair is supplied, team colours
        are assigned generically by cycling house hues in order of first
        appearance (see :func:`_team_colors_for`) rather than the five
        story-specific team hues.
    mode : str, optional
        Interactivity mode passed to :func:`_interactive.fullscreen_control`
        (``"self-contained"``, ``"external"`` or ``"static"``). Defaults to
        ``"self-contained"``.
    accessibility : str, optional
        Palette accessibility level threaded into :func:`_style.load_palette`
        (``"universal"``, ``"high-contrast"``, ``"monochrome"``,
        ``"deuteranopia"``, ``"protanopia"`` or ``"tritanopia"``). Defaults to
        ``"universal"``, the colour-vision-safe standard.
    title, subtitle, desc : str or None, optional
        Chart text. ``None`` (the default) keeps the illustrative
        microservice-call-graph story used by the shipped demo/gallery.
        Previously ``title`` was a documented no-op forcing callers with a
        different story to patch the rendered SVG's text after the fact
        (fragile string-replace); it is now honoured directly, along with
        the subtitle and accessible long description.
    legend_title : str, optional
        Heading above the team-colour legend row (default ``"Owning
        team"``, the shipped demo's language). Pass the caller's own word
        (e.g. a French ``"Catégorie"``) instead of patching the rendered
        text.
    hint : str or None, optional
        The small usage hint under the subtitle (node-size + hover
        affordance). ``None`` keeps the shipped demo's English hint.
    theme : str, optional
        Visual theme: ``"corporate"`` (default, Roboto -- byte-identical to
        the pre-theme render) or ``"academic"`` (LaTeX-style Latin Modern).
        See :func:`sprezzature_figures.fonts.chrome_stack_for_theme`.

    Returns
    -------
    str
        A complete, standalone SVG document.
    """
    services = services if services else SERVICES
    calls = calls if calls else CALLS
    is_default_services = services == SERVICES
    if is_default_services:
        TEAM_COLOR = _team_color(accessibility, theme)
    else:
        team_order: List[str] = []
        for s in services:
            if s[2] not in team_order:
                team_order.append(s[2])
        TEAM_COLOR = _team_colors_for(team_order, accessibility, theme)
    ids = [s[0] for s in services]
    label_of = {s[0]: s[1] for s in services}
    team_of = {s[0]: s[2] for s in services}
    # CSS-safe slug per node id, used everywhere a node id is embedded in a class
    # name or selector (n-<slug>, l-<slug>, i-<slug>). Node ids come straight from
    # caller data (e.g. French stratagem names with spaces and apostrophes) and an
    # unescaped apostrophe inside a CSS selector breaks the tokenizer for the rest
    # of the stylesheet — silently dropping unrelated rules like ``.tip{opacity:0}``,
    # which is why every tooltip bubble used to render visible at once instead of
    # only on hover. Reuses ``_team_slug``, which is generic despite the name.
    slug = {nid: _team_slug(nid) for nid in ids}

    # Canvas grows with the node count: the fixed 1200x980 box comfortably fits
    # the ~15-node demo graph, but a real bipartite "who employs what" graph
    # (many stratagems, each connected to several speakers) can have 20-30+
    # nodes — cramming those into the same fixed box is what produces the
    # overlapping-circle, overlapping-label "spaghetti" look. Growth is
    # additive past a baseline so the tracked demo SVG stays byte-identical.
    _BASELINE_NODES = 16
    _extra_nodes = max(0, len(ids) - _BASELINE_NODES)
    WIDTH = _MODULE_WIDTH + _extra_nodes * 30
    HEIGHT = _MODULE_HEIGHT + _extra_nodes * 24

    # Undirected edge set for the layout (dedupe reversed duplicates).
    undirected: List[Tuple[str, str]] = []
    seen_e: set = set()
    for a, b in calls:
        key = (min(a, b), max(a, b))
        if key not in seen_e:
            seen_e.add(key)
            undirected.append((a, b))

    # Adjacency (undirected) for neighbour highlighting.
    neigh: Dict[str, set] = {nid: set() for nid in ids}
    for a, b in undirected:
        neigh[a].add(b)
        neigh[b].add(a)

    indeg = _degrees(ids, calls)
    max_indeg = max(indeg.values()) if indeg else 1
    radii = {nid: _radius(indeg[nid], max_indeg) for nid in ids}

    box_w = WIDTH - 2 * PLOT_PAD
    box_h = HEIGHT - PLOT_TOP - PLOT_PAD - 72  # leave room for the legend row
    raw = _layout(ids, undirected, box_w, box_h, radii=radii)

    # Translate box coords onto the canvas.
    pos: Dict[str, Tuple[float, float]] = {
        nid: (PLOT_PAD + x, PLOT_TOP + y) for nid, (x, y) in raw.items()
    }

    title_txt = title if title is not None else "Auth is a hidden single point of failure"
    subtitle_txt = (
        subtitle if subtitle is not None else "Service-to-service calls in an online-store backend"
    )
    desc_txt = desc if desc is not None else (
        "Force-directed node-link diagram of a microservice call graph. Each "
        "node is a service, coloured by owning team and sized by how many "
        "other services call it. Edges join services that call each other. "
        "The Auth service is the largest node: nearly every checkout, order "
        "and profile path calls it, so a stall in Auth cascades across the "
        "whole store. Hover or focus any service to highlight only the "
        "services it talks to."
    )
    hint_txt = hint if hint is not None else (
        "Node size ∝ how many services call it · hover or focus a service "
        "to trace its calls"
    )

    parts: List[str] = []
    parts.append(svg_open(WIDTH, HEIGHT, "net-title", "net-desc", font_family=chrome_stack_for_theme(theme)))
    parts.append(f'<title id="net-title">{escape(title_txt)}</title>')
    parts.append(f'<desc id="net-desc">{escape(desc_txt)}</desc>')

    # --- CSS: hover/focus a node fades everything but that node, its
    #     incident edges, and its direct neighbours. CSS cannot walk
    #     arbitrary graph adjacency, so we precompute each node's
    #     neighbourhood in Python and emit one :has() rule per node: when
    #     the graph *contains* a hovered/focused node ``n-<id>``, dim the
    #     whole graph, then restore the hovered node, its neighbour nodes,
    #     their labels, and every edge tagged ``i-<id>``. :has() is
    #     supported by Chrome (used for the audit shot) and every modern
    #     browser. ---
    css_lines: List[str] = [
        ".node,.edge,.nlabel{transition:opacity .2s ease}",
        ".node circle{transition:opacity .2s ease}",
    ]
    for nid in ids:
        # When the graph contains a hovered/focused node with id n-<nid>,
        # fade everything, then restore the hovered node, its labels, its
        # incident edges, and its neighbour nodes + labels.
        # NOTE: :is(:hover,:focus-within) keeps ``cond`` a *single* complex
        # selector — a bare comma here would split the descendant rules and
        # silently break the fade.
        cond = f'#graph:has(.node.n-{slug[nid]}:is(:hover,:focus-within))'
        # Fade all.
        css_lines.append(f"{cond} .edge{{opacity:.07}}")
        css_lines.append(f"{cond} .node{{opacity:.20}}")
        css_lines.append(f"{cond} .nlabel{{opacity:.08}}")
        # Restore the hovered node + its neighbours (and their labels).
        keep = [nid] + sorted(neigh[nid])
        node_sel = ",".join(f"{cond} .node.n-{slug[k]}" for k in keep)
        label_sel = ",".join(f"{cond} .nlabel.l-{slug[k]}" for k in keep)
        css_lines.append(f"{node_sel}{{opacity:1}}")
        css_lines.append(f"{label_sel}{{opacity:1}}")
        # Restore incident edges: every edge touching nid carries class i-<nid>.
        css_lines.append(f"{cond} .edge.i-{slug[nid]}{{opacity:.85}}")
    css_lines.append(".node:focus{outline:none}")
    css_lines.append(".node circle:focus{outline:none}")
    css_lines.append(".tip{opacity:0;pointer-events:none;transition:opacity .12s ease}")
    css_lines.append(foreground_tip_css(len(ids), mark_prefix="node", tip_prefix="node-tip"))
    css_lines.append("@media (prefers-reduced-motion: reduce){.tip{transition:none}}")
    # OS-adaptive overrides (additive; the default render is byte-identical
    # because every rule below lives inside a media query). Under
    # prefers-contrast the five team hues deepen to their high-contrast
    # variants on the node fills. Under forced colours the whole graph drops to
    # system-palette line art — legitimate here because every node carries an
    # always-visible text label, so team identity survives without colour: the
    # nodes become CanvasText discs and the labels + edges follow the system
    # palette too.
    team_series = {
        f".team-{_team_slug(team)}": color for team, color in TEAM_COLOR.items()
    }
    css_lines.append(
        os_adaptive_style(
            team_series,
            role="fill",
            forced=True,
            extra_forced=".nlabel{fill:CanvasText;} .edge{stroke:CanvasText;}",
        )
    )
    # Additive OS dark mode: dark paper + light ink (default ink_map); the team
    # node hues are data, left alone. The node labels are ink text carried on a
    # white halo — under dark the text flips to off-white, so the halo must flip
    # to the dark paper (not stay white) or it would swallow the light text. The
    # resting edges dim to a mid-grey that reads as connectors on the dark ground.
    css_lines.append(
        os_dark_style(
            extra=(
                ".nlabel{stroke:#0B0B0C;}"
                ".edge{stroke:#4A4A50;}"
            )
        )
    )
    parts.append("<style>" + "".join(css_lines) + "</style>")

    # --- background ---
    parts.append(f'<rect width="{WIDTH}" height="{HEIGHT}" fill="{BG}"/>')

    # --- title + subtitle (start-anchored, house style) ---
    parts.append(
        f'<text x="48" y="66" font-size="34" font-weight="700" '
        f'fill="{INK}">{escape(title_txt)}</text>'
    )
    parts.append(
        f'<text x="48" y="102" font-size="19" fill="{SUBINK}">'
        f'{escape(subtitle_txt)}</text>'
    )

    parts.append('<g id="graph">')

    # --- edges (drawn first, under the nodes) ---
    parts.append('<g id="edges">')
    for a, b in undirected:
        xa, ya = pos[a]
        xb, yb = pos[b]
        parts.append(
            f'<line class="edge i-{slug[a]} i-{slug[b]}" x1="{xa:.1f}" y1="{ya:.1f}" '
            f'x2="{xb:.1f}" y2="{yb:.1f}" stroke="{EDGE}" '
            f'stroke-width="2.2" stroke-linecap="round"/>'
        )
    parts.append("</g>")

    # --- node labels (own layer so hover fade is independent of nodes) ---
    # Two problems previously slipped through here: (1) a label could sit close
    # enough to a neighbour's that their text ran together with no gap ("...adver
    # sTirer de..."), because nothing ever checked one label's box against
    # another's; (2) a label near the left/right canvas edge, anchored "middle"
    # on its node, could have its first characters clipped off-canvas. Both are
    # fixed the same way any label-declutter pass works: measure the actual
    # rendered width (`_textfit.text_width`, calibrated for the house Roboto
    # stack — a language-longer French label is measured correctly, not just
    # assumed to fit like English), clamp the anchor so the box never crosses
    # the canvas edge, then push a label straight down past any earlier-placed
    # label it would otherwise overlap.
    LABEL_SIZE = 18.0
    # Seed the collision set with every node circle's own bounding box first —
    # on a dense graph a label sitting a few px from its intended node can
    # otherwise land squarely on top of an unrelated neighbouring circle
    # (labels only used to dodge other labels, never the circles themselves).
    label_boxes: List[Dict[str, float]] = [
        {"left": x - radii[nid], "right": x + radii[nid],
         "top": y - radii[nid], "bottom": y + radii[nid]}
        for nid, (x, y) in pos.items()
    ]
    placements: Dict[str, Tuple[float, float, str]] = {}
    edge_margin = 6.0
    for nid in sorted(ids, key=lambda n: pos[n][0]):
        x, y = pos[nid]
        r = _radius(indeg[nid], max_indeg)
        w = text_width(label_of[nid], LABEL_SIZE, bold=True)
        below = y + r + 22

        anchor = "middle"
        lx = x
        if x - w / 2 < edge_margin:
            anchor, lx = "start", edge_margin
        elif x + w / 2 > WIDTH - edge_margin:
            anchor, lx = "end", WIDTH - edge_margin
        left = lx if anchor == "start" else (lx - w if anchor == "end" else lx - w / 2)

        # Push down to dodge a collision, but only up to a small cap: on a dense
        # graph, chasing every collision to a fully-clear spot can walk a label
        # 200+px away from the node it names, which reads as an orphaned block
        # of unrelated text — worse than the overlap it was avoiding. Past the
        # cap, accept the last position (light overlap, still legible, still
        # anchored near its node) rather than keep drifting.
        max_below = below + 4 * (LABEL_SIZE + 4)
        guard = 0
        while guard < 8 and below <= max_below:
            collided = False
            for box in label_boxes:
                if left < box["right"] and left + w > box["left"] and below < box["bottom"] and below + LABEL_SIZE > box["top"]:
                    below = box["bottom"] + 4
                    collided = True
                    break
            if not collided:
                break
            guard += 1
        below = min(below, max_below)
        label_boxes.append({"left": left, "right": left + w, "top": below, "bottom": below + LABEL_SIZE})
        placements[nid] = (lx, below, anchor)

    parts.append('<g id="labels">')
    for nid in ids:
        lx, below, anchor = placements[nid]
        parts.append(
            f'<text class="nlabel l-{slug[nid]}" x="{lx:.1f}" y="{below:.1f}" '
            f'text-anchor="{anchor}" font-size="{LABEL_SIZE:.0f}" font-weight="600" '
            f'fill="{INK}" paint-order="stroke" stroke="{BG}" stroke-width="5" '
            f'stroke-linejoin="round">{escape(label_of[nid])}</text>'
        )
    parts.append("</g>")

    # --- nodes ---
    # Every node is drawn first, every one of its bubbles appended afterward
    # (still inside #nodes, so the id-matched hover rule below still finds
    # them as siblings): SVG paints in document order regardless of hover
    # state, so a bubble sitting next to its own node would be covered by
    # any node drawn after it (a dense cluster easily has this).
    parts.append('<g id="nodes">')
    node_tips: List[str] = []
    for node_i, nid in enumerate(ids):
        x, y = pos[nid]
        r = _radius(indeg[nid], max_indeg)
        color = TEAM_COLOR[team_of[nid]]
        callers = sorted({c for c, e in calls if e == nid}, key=lambda c: label_of.get(c, c))
        callee_of = sorted({e for c, e in calls if c == nid}, key=lambda e: label_of.get(e, e))
        tip = (
            f"{label_of[nid]} · {team_of[nid]} team — "
            f"called by {indeg[nid]} service(s)"
        )
        if callers:
            tip += ": " + ", ".join(label_of.get(c, c) for c in callers)
        if callee_of:
            tip += f"; calls {', '.join(label_of.get(e, e) for e in callee_of)}"
        # The team slug rides on the <circle> itself (not the <g>) so a CSS
        # class rule can outrank the inline fill under the OS-adaptive media
        # queries below — a class on the group would not reach the circle's fill.
        team_slug = _team_slug(team_of[nid])
        parts.append(
            f'<g id="node-{node_i}" class="node hit n-{slug[nid]}" tabindex="0" role="img" '
            f'aria-label="{escape(tip)}">'
            f'<circle class="team-{team_slug}" cx="{x:.1f}" cy="{y:.1f}" '
            f'r="{r:.1f}" fill="{color}" stroke="{BG}" stroke-width="4"/>'
            f"</g>"
        )
        tip_lines = [label_of[nid], f"{team_of[nid]} team"]
        if callers:
            tip_lines.append(f"Called by {indeg[nid]}: " + ", ".join(label_of.get(c, c) for c in callers))
        else:
            tip_lines.append(f"Called by {indeg[nid]} service(s)")
        if callee_of:
            tip_lines.append("Calls: " + ", ".join(label_of.get(e, e) for e in callee_of))
        tip_anchor, tip_x = "middle", x
        if x < PLOT_PAD + 80:
            tip_anchor, tip_x = "start", x
        elif x > WIDTH - PLOT_PAD - 80:
            tip_anchor, tip_x = "end", x
        node_tips.append(
            tooltip_bubble(
                tip_x, y - r - 14,
                tip_lines,
                anchor=tip_anchor, canvas_w=WIDTH, canvas_h=HEIGHT,
                ink=INK, secondary=SUBINK, border=EDGE,
                elem_id=f"node-tip-{node_i}",
            )
        )
    parts.extend(node_tips)
    parts.append("</g>")

    parts.append("</g>")  # /graph

    # --- team legend (bottom-left, single row) ---
    ly = HEIGHT - 34
    lx = 48
    parts.append(
        f'<text x="{lx}" y="{ly - 30}" font-size="17" font-weight="600" '
        f'fill="{SUBINK}">{escape(legend_title)}</text>'
    )
    cursor: float = lx
    for team, color in TEAM_COLOR.items():
        parts.append(
            f'<circle cx="{cursor + 9:.1f}" cy="{ly - 6:.1f}" r="9" fill="{color}"/>'
        )
        parts.append(
            f'<text x="{cursor + 26:.1f}" y="{ly:.1f}" font-size="18" '
            f'fill="{INK}">{escape(team)}</text>'
        )
        cursor += 30 + 11.0 * len(team) + 30

    # --- size + hover hint: sits under the subtitle so it never collides
    #     with the legend row at the bottom of a dense graph. ---
    parts.append(
        f'<text x="48" y="134" font-size="17" fill="{SUBINK}">{escape(hint_txt)}</text>'
    )

    parts.append(fullscreen_control(WIDTH, HEIGHT, mode))
    parts.append("</svg>")
    return "".join(parts)


#: The registry contract wants a flat row list; a network's natural unit is
#: an edge, so each demo row denormalises one directed call with both
#: endpoints' label/team so the row list alone can rebuild the full graph.
_LABEL_OF: Dict[str, str] = {s[0]: s[1] for s in SERVICES}
_TEAM_OF: Dict[str, str] = {s[0]: s[2] for s in SERVICES}
DEMO_DATA: List[Dict[str, Any]] = [
    {
        "source": a, "source_label": _LABEL_OF[a], "source_team": _TEAM_OF[a],
        "target": b, "target_label": _LABEL_OF[b], "target_team": _TEAM_OF[b],
    }
    for a, b in CALLS
]


def _rows_to_graph(
    rows: List[Dict[str, Any]],
) -> "tuple[List[Tuple[str, str, str]], List[Tuple[str, str]]]":
    """Reshape DEMO_DATA-style edge rows back into ``(services, calls)``."""
    services: List[Tuple[str, str, str]] = []
    seen: set = set()
    calls: List[Tuple[str, str]] = []
    for r in rows:
        src, tgt = str(r["source"]), str(r["target"])
        if src not in seen:
            services.append((src, str(r.get("source_label", src)), str(r.get("source_team", "Team"))))
            seen.add(src)
        if tgt not in seen:
            services.append((tgt, str(r.get("target_label", tgt)), str(r.get("target_team", "Team"))))
            seen.add(tgt)
        calls.append((src, tgt))
    return services, calls


def make_network(
    data: Optional[List[Dict[str, Any]]] = None,
    *,
    out: Optional[Path | str] = None,
    title: Optional[str] = None,
    subtitle: Optional[str] = None,
    desc: Optional[str] = None,
    legend_title: str = "Owning team",
    hint: Optional[str] = None,
    mode: str = "self-contained",
    accessibility: str = "universal",
    theme: str = "corporate",
) -> Path:
    """Render the node-link network and write the SVG to *out*.

    Parameters
    ----------
    data : list[dict[str, Any]] or None
        Rows shaped ``{"source", "source_label", "source_team", "target",
        "target_label", "target_team"}`` — one row per directed edge.
        Defaults to :data:`DEMO_DATA`.
    out : Path, str, or None
        Output path. Defaults to ``assets/svg-examples/network.svg``.
    title, subtitle, desc : str or None, optional
        Chart text. ``None`` keeps the illustrative microservice-call-graph
        story. Forwarded to :func:`build_svg` (previously ``title`` was
        accepted but silently dropped, forcing callers with their own story
        to string-replace the rendered SVG's English text after the fact).
    legend_title : str, optional
        Heading above the team-colour legend row (default ``"Owning team"``).
    hint : str or None, optional
        The small usage hint under the subtitle. ``None`` keeps the demo's.
    mode, accessibility : str
        Forwarded to :func:`build_svg`.
    theme : str, optional
        Visual theme. Forwarded to :func:`build_svg`.

    Returns
    -------
    Path
        Absolute path to the written SVG file.
    """
    rows = data if data else DEMO_DATA
    services, calls = _rows_to_graph(rows)
    svg = build_svg(
        services=services, calls=calls, mode=mode, accessibility=accessibility,
        title=title, subtitle=subtitle, desc=desc, legend_title=legend_title, hint=hint,
        theme=theme,
    )
    dest = Path(out) if out else svg_example_path(__file__, "network")
    return write_svg(dest, svg, theme=theme)


def main() -> None:
    """Write the node-link network SVG to the skill's example asset folder.

    The ``--mode`` flag selects the interactivity mode of the emitted SVG
    (``self-contained`` / ``external`` / ``static``); see
    :func:`_interactive.fullscreen_control`.
    """
    render_cli(
        __file__, "network", build_svg, description="Render the node-link network SVG."
    )



# ── kit: the data comes from data.csv ─────────────────────────────────────
# The generator keeps its own DEMO_DATA above as a fallback and as a record
# of the expected column names. When data.csv is present (it ships with this
# kit), it wins: edit the CSV, re-run this file, and the figure changes.
from sprezzature_svg import load_rows  # noqa: E402

try:
    DEMO_DATA = load_rows("data.csv") or DEMO_DATA
except FileNotFoundError:
    pass


if __name__ == "__main__":
    main()
