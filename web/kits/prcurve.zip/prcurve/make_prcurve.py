#!/usr/bin/env python3
"""
make_prcurve — the precision-recall curve as hand-authored SVG.

Generate the **precision-recall (PR) curve** figure in the
``sprezzature-figures`` house style. As the decision threshold of a binary
classifier sweeps from strict to lenient, precision (of the positives it
flags, how many are truly positive) is plotted against recall (of all the
true positives, how many it caught). Each curve is the model's whole
precision-vs-recall trade-off in one line, and the area under it, the
**average precision (AP)**, labels the curve directly.

The scenario is a **fraud-detection** classifier scoring card
transactions, where the positive class (fraud) is rare: roughly 3 % of
transactions. That prevalence matters: on an imbalanced problem the PR
curve is the honest picture (unlike the receiver-operating-characteristic
curve, whose large true-negative pool flatters a weak model). To make the
comparison legible the figure layers **two** models: a strong gradient-
boosted model and a weaker logistic baseline, so the reader sees one
curve dominate the other across the whole recall range.

Every PR curve is read against the **no-skill baseline**: a classifier
that ignores its input scores precision equal to the positive-class
prevalence at every recall, a flat horizontal line. A curve hugging that
line has learned nothing; the vertical gap above it is the signal. The
figure draws that baseline as a dashed rule and annotates it, so the
takeaway ("well above chance") is unmistakable. Faint **iso-F1 contours**
(curves of constant F1 score) arc through the plot so a reader can read
each operating point's F1 straight off the background.

This generator builds the SVG by hand so the two curves are separated
by more than hue: each carries a
dash pattern and a distinct end marker, plus an inline direct label with
its AP. That keeps them apart under deuteranopia and in greyscale. The
figure matches the sprezzature-* house style: Roboto, the Apple-ish palette,
rounded corners, ink ``#1D1D1F``, secondary ``#6E6E73``, white
background, white keylines.

Each curve carries a native ``<title>`` tooltip and the shipped
(max-F1) operating point is emphasised with a marker and its own
tooltip; no JavaScript beyond the shared fullscreen control.

The final artifact is always an SVG written to
``sprezzature-figures/assets/svg-examples/prcurve.svg``.

Usage
-----
::

    python make_prcurve.py            # writes next to the skill
    python make_prcurve.py --out /tmp/prcurve.svg
    python make_prcurve.py --mode static   # no fullscreen button

Author
------
`Warith Harchaoui, Ph.D. <https://www.linkedin.com/in/warith-harchaoui/>`_
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

import numpy as np

# House-style palette + shared primitives live alongside in scripts/.
from sprezzature_svg import render_cli, svg_example_path, write_svg  # noqa: E402
from sprezzature_svg import fullscreen_control  # noqa: E402
from sprezzature_svg import load_palette, os_adaptive_style, os_dark_style  # noqa: E402
from sprezzature_svg import foreground_tip_css, svg_open, tooltip_bubble, xml_escape  # noqa: E402
from sprezzature_svg import chrome_stack_for_theme, mono_stack_for_theme  # noqa: E402


def _sigmoid(z: np.ndarray) -> np.ndarray:
    """Numerically-stable logistic sigmoid.

    Parameters
    ----------
    z : numpy.ndarray
        Log-odds / score values.

    Returns
    -------
    numpy.ndarray
        ``1 / (1 + exp(-z))`` in ``(0, 1)``.
    """
    return 1.0 / (1.0 + np.exp(-z))


def _pr_from_scores(
    y_true: np.ndarray,
    scores: np.ndarray,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, float]:
    """Compute the precision-recall curve and average precision from scores.

    Implements the standard scikit-learn ``precision_recall_curve`` +
    ``average_precision_score`` contract in a few lines of NumPy so the
    figure carries no scikit-learn dependency. Thresholds are the unique
    scores in descending order; at each threshold everything scoring at or
    above it is predicted positive.

    Average precision is the step-function area under the curve,
    :math:`\\sum_k (R_k - R_{k-1}) P_k` — the weighted mean of precisions
    with the recall increments as weights — which is what scikit-learn
    reports (and, unlike trapezoidal integration, does not optimistically
    interpolate between operating points).

    Parameters
    ----------
    y_true : numpy.ndarray
        Ground-truth labels in ``{0, 1}``.
    scores : numpy.ndarray
        Classifier scores; higher means more likely positive.

    Returns
    -------
    recall : numpy.ndarray
        Recall at each operating point, ascending, prepended with the
        ``(recall=0, precision=1)`` anchor scikit-learn uses.
    precision : numpy.ndarray
        Precision at each operating point, aligned with ``recall``.
    thresholds : numpy.ndarray
        The score threshold that produced each operating point, aligned with
        ``recall`` / ``precision``. The prepended anchor carries ``+inf``
        (nothing scores that high, so nothing is predicted positive).
    average_precision : float
        Area under the PR curve (the AP summary statistic).
    """
    # Sort by descending score; sweep the threshold downward.
    order = np.argsort(-scores, kind="mergesort")
    y_sorted = y_true[order]
    scores_sorted = scores[order]

    total_positives = float(y_sorted.sum())
    # Cumulative true / false positives as we admit each next-highest score.
    true_positives = np.cumsum(y_sorted)
    false_positives = np.cumsum(1.0 - y_sorted)

    precision = true_positives / np.maximum(true_positives + false_positives, 1e-12)
    recall = true_positives / max(total_positives, 1e-12)

    # Collapse tied scores onto their last index so each distinct threshold
    # contributes a single operating point (scikit-learn semantics). The
    # threshold at that operating point is the score itself: everything
    # scoring at or above it is predicted positive.
    distinct = np.where(np.diff(scores_sorted))[0]
    keep = np.r_[distinct, len(y_sorted) - 1]
    precision = precision[keep]
    recall = recall[keep]
    thresholds = scores_sorted[keep]

    # Average precision: sum of precision * (delta recall). The recall array
    # starts from the first admitted score, so the first increment is measured
    # against recall 0.
    recall_prev = np.r_[0.0, recall[:-1]]
    average_precision = float(np.sum((recall - recall_prev) * precision))

    # Prepend the canonical (recall=0, precision=1) anchor so the curve starts
    # cleanly on the left axis; its threshold is +inf (above every score, so
    # nothing is ever flagged positive).
    recall = np.r_[0.0, recall]
    precision = np.r_[1.0, precision]
    thresholds = np.r_[np.inf, thresholds]
    return recall, precision, thresholds, average_precision


def _thin(
    recall: np.ndarray,
    precision: np.ndarray,
    thresholds: np.ndarray,
    model: str,
    max_points: int = 120,
    must_keep: Sequence[int] = (),
) -> List[Dict[str, Any]]:
    """Down-sample a dense PR curve to a plottable record list.

    A full sweep over thousands of transactions yields thousands of
    operating points; the SVG only needs enough to draw a smooth line.
    Points are sampled at evenly-spaced recall indices, always keeping the
    first and last so the curve spans the full axis.

    Parameters
    ----------
    recall, precision, thresholds : numpy.ndarray
        The curve from :func:`_pr_from_scores`.
    model : str
        Label carried on every record.
    max_points : int, optional
        Target number of points to keep. Default 120.
    must_keep : sequence of int, optional
        Extra indices to force into the retained set even when they'd
        otherwise be thinned away — used so the shipped (max-F1) operating
        point marker always lands exactly on the drawn polyline instead of
        floating near it (evenly-spaced thinning has no reason to land on
        the argmax-F1 index, and PR curves are step functions, so a marker
        placed at a dropped index can visibly miss the line).

    Returns
    -------
    list of dict
        ``{"recall": float, "precision": float, "threshold": float | None,
        "model": str}`` records — ``threshold`` is ``None`` for the
        ``(recall=0, precision=1)`` anchor (its threshold is ``+inf``:
        nothing scores that high).
    """
    n = len(recall)
    if n <= max_points:
        idx = np.arange(n)
    else:
        idx = np.unique(np.linspace(0, n - 1, max_points).astype(int))
        if must_keep:
            idx = np.unique(np.concatenate([idx, np.asarray(must_keep, dtype=int)]))
    return [
        {
            "recall": round(float(recall[i]), 4),
            "precision": round(float(precision[i]), 4),
            "threshold": (
                None if not np.isfinite(thresholds[i]) else round(float(thresholds[i]), 4)
            ),
            "model": model,
        }
        for i in idx
    ]


def _simulate_rows(
    n: int = 6000,
    prevalence: float = 0.03,
    seed: int = 11,
) -> List[Dict[str, Any]]:
    """Simulate ``n`` fraud-detection transactions as row records.

    Ground truth is a rare positive class (fraud). Two score generators
    with different separability are simulated:

    * **Gradient-boosted** — well-separated scores, the strong model;
    * **Logistic baseline** — noisier scores, the weaker model.

    Both are pushed through a logistic link so the scores read as
    calibrated-ish probabilities in ``(0, 1)``. This is the row-record
    source :data:`DEMO_DATA` is built from; :func:`make_data` reshapes any
    row list of this shape (real or synthetic) into the PR-curve bundle
    :func:`build_svg` renders.

    Parameters
    ----------
    n : int, optional
        Number of transactions. Default 6000.
    prevalence : float, optional
        Fraction of the positive (fraud) class. Default 0.03.
    seed : int, optional
        NumPy random seed for reproducibility. Default 11.

    Returns
    -------
    list of dict
        One row per transaction: ``{"transaction": int, "is_fraud": bool,
        "score_strong": float, "score_weak": float}``.
    """
    rng = np.random.default_rng(seed)

    y_true = (rng.random(n) < prevalence).astype(int)
    positives = y_true == 1
    negatives = ~positives

    # Latent log-odds: positives shifted up, negatives down. A larger gap =
    # a stronger model. Both share the same ground truth so the curves are
    # directly comparable.
    def _scores(gap_pos: float, gap_neg: float, noise: float) -> np.ndarray:
        z = np.empty(n)
        z[positives] = rng.normal(gap_pos, noise, positives.sum())
        z[negatives] = rng.normal(gap_neg, noise, negatives.sum())
        return _sigmoid(z)

    strong = _scores(gap_pos=2.6, gap_neg=-2.2, noise=1.3)
    weak = _scores(gap_pos=1.2, gap_neg=-1.0, noise=1.7)

    return [
        {
            "transaction": i,
            "is_fraud": bool(y_true[i]),
            "score_strong": round(float(strong[i]), 6),
            "score_weak": round(float(weak[i]), 6),
        }
        for i in range(n)
    ]


#: Row-record demo data: one row per simulated transaction, the contract's
#: ``list[dict[str, Any]]`` shape. :func:`make_data` reshapes it (or any
#: caller-supplied row list of the same shape) into the PR-curve bundle.
DEMO_DATA: List[Dict[str, Any]] = _simulate_rows()

#: Row-level model names, in stacking/plot order; keys must match the
#: ``score_<slug>`` fields on each :data:`DEMO_DATA` row.
_ROW_MODELS: Dict[str, str] = {
    "Gradient-boosted": "score_strong",
    "Logistic baseline": "score_weak",
}


def make_data(data: Optional[List[Dict[str, Any]]] = None) -> Dict[str, Any]:
    """Reshape fraud-transaction row records into PR curves + AP.

    Parameters
    ----------
    data : list of dict, optional
        Rows with ``is_fraud`` (bool/0-1) and per-model score keys
        (``score_strong``, ``score_weak``). Defaults to :data:`DEMO_DATA`.

    Returns
    -------
    dict
        ``{"curves": [record, ...], "ap": {model: float}, "prevalence":
        float, "points": [operating-point record, ...]}`` — ``curves``
        feeds the line layers, ``points`` the highlighted operating-point
        markers, ``ap`` the direct labels, ``prevalence`` the baseline.
    """
    rows = data if data else DEMO_DATA
    y_true = np.array([1 if r.get("is_fraud") else 0 for r in rows])

    curves: List[Dict[str, Any]] = []
    ap: Dict[str, float] = {}
    points: List[Dict[str, Any]] = []

    for label, score_key in _ROW_MODELS.items():
        scores = np.array([float(r[score_key]) for r in rows])
        recall, precision, thresholds, average_precision = _pr_from_scores(y_true, scores)

        # Highlight one operating point per model: the threshold that
        # maximises the F1 score (the harmonic mean of precision and
        # recall) — the point a practitioner would ship. Computed before
        # thinning so `best`'s index can be forced into the retained set
        # (see `_thin`'s `must_keep` — otherwise the marker can float off
        # the drawn polyline).
        f1 = 2.0 * precision * recall / np.maximum(precision + recall, 1e-12)
        best = int(np.argmax(f1[1:])) + 1  # skip the (0, 1) anchor
        curves.extend(_thin(recall, precision, thresholds, label, must_keep=[best]))
        ap[label] = round(average_precision, 3)
        points.append(
            {
                "recall": round(float(recall[best]), 4),
                "precision": round(float(precision[best]), 4),
                "threshold": round(float(thresholds[best]), 4),
                "model": label,
                "f1": round(float(f1[best]), 3),
            }
        )

    return {
        "curves": curves,
        "ap": ap,
        "prevalence": round(float(y_true.mean()), 4),
        "points": points,
    }


def build_svg(
    data: Optional[List[Dict[str, Any]]] = None,
    mode: str = "self-contained",
    accessibility: str = "universal",
    theme: str = "corporate",
) -> str:
    """Assemble the full precision-recall-curve SVG string.

    The plot is a square unit view (recall on x, precision on y, both in
    ``[0, 1]``) carrying, bottom to top: a faint no-skill floor shaded up
    to the prevalence line; the dashed no-skill baseline with its label;
    faint iso-F1 contours; the two model curves (each a distinct hue *and*
    dash *and* end marker); the shipped (max-F1) operating-point markers;
    and inline direct labels with each curve's average precision.

    Parameters
    ----------
    mode : str, optional
        Interactivity mode passed to :func:`_interactive.fullscreen_control`
        (``"self-contained"``, ``"external"`` or ``"static"``). Defaults to
        ``"self-contained"``: the SVG carries its own fullscreen button.
    accessibility : str, optional
        Palette accessibility level threaded into :func:`_style.load_palette`
        (``"universal"``, ``"high-contrast"``, ``"monochrome"``,
        ``"deuteranopia"``, ``"protanopia"`` or ``"tritanopia"``). Defaults to
        ``"universal"``, the colour-vision-safe standard.
    theme : str, optional
        Visual theme: ``"corporate"`` (default, Roboto -- byte-identical to
        the pre-theme render) or ``"academic"`` (LaTeX-style Latin Modern).
        See :func:`sprezzature_figures.fonts.chrome_stack_for_theme`.

    Returns
    -------
    str
        A complete, standalone SVG document.
    """
    # This file's mono literal predates _style.FONT_MONO and is missing the
    # "ui-monospace" fallback -- keep it exact for corporate (byte-identical
    # to the pre-theme render) and only swap in the full academic stack.
    mono_family = "Roboto Mono, monospace" if theme == "corporate" else mono_stack_for_theme(theme)
    bundle = make_data(data)
    palette: Dict[str, str] = load_palette(accessibility, theme=theme)

    # Two hues that stay apart under deuteranopia and greyscale: blue for the
    # strong model, orange for the weak baseline. The split is reinforced by a
    # dash pattern and a distinct end marker per curve, so hue is never the
    # only channel carrying "which model is which".
    strong_col = palette.get("Blue", "#007AFF")
    weak_col = palette.get("Orange", "#FF9500")
    ink = "#1D1D1F"
    secondary = "#6E6E73"
    grid_col = "#ECECEC"
    floor_col = "#8E8E93"

    prevalence = bundle["prevalence"]
    ap = bundle["ap"]
    strong_ap = ap["Gradient-boosted"]
    weak_ap = ap["Logistic baseline"]

    # Per-model visual style. ``dash`` is the SVG dash-array (empty = solid),
    # ``marker`` picks the end-glyph shape so the two curves differ by shape
    # as well as hue.
    style: Dict[str, Dict[str, Any]] = {
        "Gradient-boosted": {"col": strong_col, "dash": "", "marker": "circle", "slug": "strong"},
        "Logistic baseline": {"col": weak_col, "dash": "10 7", "marker": "square", "slug": "weak"},
    }

    # --- canvas geometry -----------------------------------------
    width = 1180
    height = 1140
    m_left = 168
    m_right = 96
    m_top = 250
    m_bottom = 150
    plot_x = m_left
    plot_y = m_top
    plot_w = width - m_left - m_right
    plot_h = height - m_top - m_bottom

    ticks = [0.0, 0.25, 0.5, 0.75, 1.0]

    def sx(v: float) -> float:
        """Map recall in ``[0, 1]`` to an x pixel coordinate."""
        return plot_x + v * plot_w

    def sy(v: float) -> float:
        """Map precision in ``[0, 1]`` to a y pixel coordinate (y-down)."""
        return plot_y + (1.0 - v) * plot_h

    # Group the thinned curve records back into per-model point lists (recall,
    # precision, threshold), in the (recall-ascending) order make_data
    # produced them. ``threshold`` is ``None`` at the (0, 1) anchor.
    per_model: Dict[str, List[Tuple[float, float, Any]]] = {
        "Gradient-boosted": [],
        "Logistic baseline": [],
    }
    for rec in bundle["curves"]:
        per_model[rec["model"]].append(
            (float(rec["recall"]), float(rec["precision"]), rec["threshold"])
        )

    parts: List[str] = []

    # --- SVG root + accessible description ------------------------
    parts.append(svg_open(width, height, "pr-title", "pr-desc", font_family=chrome_stack_for_theme(theme)))
    parts.append(
        '<title id="pr-title">Gradient boosting flags fraud far more precisely '
        'than the logistic baseline</title>'
    )
    parts.append(
        f'<desc id="pr-desc">Precision-recall curves for two fraud-detection '
        f'classifiers on an imbalanced problem (fraud prevalence '
        f'{prevalence:.0%}). The horizontal axis is recall (share of fraud '
        f'caught); the vertical axis is precision (share of flagged '
        f'transactions that are fraud); both run from 0 to 1. The strong '
        f'gradient-boosted model (solid blue, circle marker, average '
        f'precision {strong_ap:.2f}) sits well above the weaker logistic '
        f'baseline (dashed orange, square marker, average precision '
        f'{weak_ap:.2f}) across the whole recall range. A dashed grey '
        f'no-skill baseline runs flat at precision equal to the {prevalence:.0%} '
        f'prevalence; the vertical gap above it is the signal each model has '
        f'learned. Faint iso-F1 contours arc through the plot, and each '
        f'model is marked at its shipped maximum-F1 operating point. '
        f'</desc>'
    )

    # OS-adaptive overrides are appended (additive; every rule lives inside an
    # @media block so the default render is byte-for-byte unchanged). The two
    # model hues carry ``.pr-line-<slug>`` on the curve strokes (and the key
    # sample lines) and ``.pr-mark-<slug>`` on the filled operating-point and
    # key glyphs. Under prefers-contrast both deepen to their high-contrast
    # blue/orange. The line hook is stroke-only so an open curve path is never
    # flooded by a fill override; the marker hook is fill-only so each glyph's
    # white keyline is left intact. forced-colors is left to the browser default
    # — the two models are already separated by dash pattern, end-marker shape
    # and a direct AP label, so colour is redundant and need not survive there.
    line_series = {
        f".pr-line-{style[m]['slug']}": style[m]["col"]
        for m in ("Gradient-boosted", "Logistic baseline")
    }
    mark_series = {
        f".pr-mark-{style[m]['slug']}": style[m]["col"]
        for m in ("Gradient-boosted", "Logistic baseline")
    }
    contrast_block = (
        os_adaptive_style(line_series, role="stroke")
        + "\n"
        + os_adaptive_style(mark_series, role="fill")
    )
    # Static figure (curves + markers); hover / focus enlargement only.
    parts.append(
        "<style>"
        ".op{cursor:pointer}"
        ".op .halo{opacity:0}"
        ".op:hover .halo,.op:focus .halo{opacity:1}"
        ".op:focus{outline:none}"
        ".curve{cursor:pointer}"
        ".sw{cursor:pointer}"
        ".sw .halo{opacity:0;transition:opacity .12s ease}"
        ".sw:hover .halo,.sw:focus .halo{opacity:1}"
        ".sw:focus{outline:none}"
        ".tip{opacity:0;pointer-events:none;transition:opacity .12s ease}"
        "@media (prefers-reduced-motion: reduce){.tip{transition:none}}"
        + "\n" + contrast_block + "\n"
        + os_dark_style() + "\n"
        "</style>"
    )

    # --- background ----------------------------------------------
    parts.append(f'<rect width="{width}" height="{height}" fill="#FFFFFF"/>')

    # --- title + subtitle (the takeaway) -------------------------
    parts.append(
        f'<text x="{m_left}" y="96" font-size="44" font-weight="700" '
        f'fill="{ink}">Gradient boosting flags fraud far more precisely</text>'
    )
    parts.append(
        f'<text x="{m_left}" y="148" font-size="25" fill="{secondary}">'
        f'Precision vs recall as the threshold varies — AP '
        f'{strong_ap:.2f} vs {weak_ap:.2f}</text>'
    )

    # --- gridlines (very light) ----------------------------------
    for t in ticks:
        gx = sx(t)
        parts.append(
            f'<line x1="{gx:.1f}" y1="{plot_y:.1f}" x2="{gx:.1f}" '
            f'y2="{plot_y + plot_h:.1f}" stroke="{grid_col}" stroke-width="1.4"/>'
        )
        gy = sy(t)
        parts.append(
            f'<line x1="{plot_x:.1f}" y1="{gy:.1f}" x2="{plot_x + plot_w:.1f}" '
            f'y2="{gy:.1f}" stroke="{grid_col}" stroke-width="1.4"/>'
        )

    # --- no-skill floor: a faint band from precision 0 up to the ---
    # prevalence line, the region where a curve means "no better than
    # guessing". Shaded so the eye reads the baseline as a floor.
    y_prev = sy(prevalence)
    y_zero = sy(0.0)
    parts.append(
        f'<rect x="{plot_x:.1f}" y="{y_prev:.1f}" width="{plot_w:.1f}" '
        f'height="{y_zero - y_prev:.1f}" fill="{floor_col}" '
        f'fill-opacity="0.09"/>'
    )

    # --- iso-F1 contours ------------------------------------------
    # Curves of constant F1: for a target F1 = f and recall r,
    # precision p = f * r / (2 r - f), valid where 2 r - f > 0. Drawn as a
    # faint polyline so a reader can read an operating point's F1 off the
    # background without a separate legend.
    for f in (0.2, 0.4, 0.6, 0.8):
        pts_iso: List[Tuple[float, float]] = []
        for k in range(201):
            r = k / 200.0
            denom = 2.0 * r - f
            if denom <= 1e-6:
                continue
            p = f * r / denom
            if 0.0 <= p <= 1.0 and 0.0 <= r <= 1.0:
                pts_iso.append((sx(r), sy(p)))
        if len(pts_iso) < 2:
            continue
        d_iso = "M " + " L ".join(f"{x:.1f} {y:.1f}" for x, y in pts_iso)
        parts.append(
            f'<path d="{d_iso}" fill="none" stroke="{floor_col}" '
            f'stroke-width="1.2" stroke-opacity="0.42" stroke-dasharray="2 6"/>'
        )
        # Label the contour where it exits the top edge (precision high).
        lx, ly = pts_iso[0]
        parts.append(
            f'<text x="{lx + 8:.1f}" y="{ly + 20:.1f}" font-size="17" '
            f'fill="{secondary}" fill-opacity="0.8">F1 {f:.1f}</text>'
        )

    # --- no-skill baseline ----------------------------------------
    parts.append(
        f'<line x1="{plot_x:.1f}" y1="{y_prev:.1f}" x2="{plot_x + plot_w:.1f}" '
        f'y2="{y_prev:.1f}" stroke="{secondary}" stroke-width="2" '
        f'stroke-dasharray="9 6"/>'
    )
    parts.append(
        f'<text x="{plot_x + 12:.1f}" y="{y_prev - 12:.1f}" font-size="20" '
        f'fill="{secondary}">No-skill baseline (prevalence {prevalence:.0%})</text>'
    )

    # --- axes (L-shaped, ink) ------------------------------------
    ax_bottom = plot_y + plot_h
    parts.append(
        f'<line x1="{plot_x:.1f}" y1="{ax_bottom:.1f}" '
        f'x2="{plot_x + plot_w:.1f}" y2="{ax_bottom:.1f}" '
        f'stroke="{ink}" stroke-width="1.8"/>'
    )
    parts.append(
        f'<line x1="{plot_x:.1f}" y1="{plot_y:.1f}" x2="{plot_x:.1f}" '
        f'y2="{ax_bottom:.1f}" stroke="{ink}" stroke-width="1.8"/>'
    )
    for t in ticks:
        gx = sx(t)
        parts.append(
            f'<line x1="{gx:.1f}" y1="{ax_bottom:.1f}" x2="{gx:.1f}" '
            f'y2="{ax_bottom + 8:.1f}" stroke="{ink}" stroke-width="1.8"/>'
        )
        parts.append(
            f'<text x="{gx:.1f}" y="{ax_bottom + 38:.1f}" font-size="21" '
            f'font-family="{mono_family}" fill="{ink}" '
            f'text-anchor="middle">{t:.0%}</text>'
        )
        gy = sy(t)
        parts.append(
            f'<line x1="{plot_x - 8:.1f}" y1="{gy:.1f}" x2="{plot_x:.1f}" '
            f'y2="{gy:.1f}" stroke="{ink}" stroke-width="1.8"/>'
        )
        parts.append(
            f'<text x="{plot_x - 18:.1f}" y="{gy + 7:.1f}" font-size="21" '
            f'font-family="{mono_family}" fill="{ink}" '
            f'text-anchor="end">{t:.0%}</text>'
        )

    # --- axis titles ---------------------------------------------
    parts.append(
        f'<text x="{plot_x + plot_w / 2:.1f}" y="{ax_bottom + 84:.1f}" '
        f'font-size="24" fill="{ink}" text-anchor="middle">'
        f'Recall — share of fraud caught → better</text>'
    )
    ytitle_x = 66
    ytitle_y = plot_y + plot_h / 2
    parts.append(
        f'<text x="{ytitle_x:.1f}" y="{ytitle_y:.1f}" font-size="24" '
        f'fill="{ink}" text-anchor="middle" '
        f'transform="rotate(-90 {ytitle_x:.1f} {ytitle_y:.1f})">'
        f'Precision — share of flags that are fraud → better</text>'
    )

    # --- the two model curves ------------------------------------
    # Draw a soft white under-stroke first so the coloured curve stays crisp
    # where it crosses a gridline or the other curve; then the coloured curve.
    # Order matters: draw the weaker (orange) curve first so the strong (blue)
    # hero curve sits on top.
    def _curve_path(pts: List[Tuple[float, float]]) -> str:
        """Return the SVG ``d`` for a polyline through mapped ``pts``."""
        return "M " + " L ".join(f"{x:.1f} {y:.1f}" for x, y in pts)

    def _threshold_words(threshold: Any) -> str:
        """Render a threshold value (or the ``None`` anchor) for a tooltip."""
        if threshold is None:
            return "threshold above every score (nothing flagged)"
        return f"threshold {float(threshold):.2f}"

    # Every bubble below is collected here instead of appended in place, and
    # drawn only once as the very last thing in the document (see the
    # `sw_tips`/`op_tips` extends near the end of this function): SVG has no
    # z-index, so a bubble sitting next to its own mark would be covered by
    # any mark drawn later in the arc. `sw_i`/`op_i` give each mark and
    # its bubble a matching id (`sw-N`/`op-N`) since they're no longer
    # next-door neighbours in the document, so foreground_tip_css needs a
    # unique pair to know which bubble belongs to which mark.
    sw_tips: List[str] = []
    sw_i = 0
    for label in ("Logistic baseline", "Gradient-boosted"):
        st = style[label]
        pts = [(sx(r), sy(p)) for r, p, _thr in per_model[label]]
        d_curve = _curve_path(pts)
        tip = f"{label}: average precision {ap[label]:.2f}"
        parts.append(
            f'<g class="curve" tabindex="0" role="img" '
            f'aria-label="{xml_escape(tip)}">'
        )
        parts.append(f"<title>{xml_escape(tip)}</title>")
        # White under-stroke (halo-free crispness where curves cross).
        parts.append(
            f'<path d="{d_curve}" fill="none" stroke="#FFFFFF" '
            f'stroke-width="12" stroke-linecap="round" '
            f'stroke-linejoin="round"/>'
        )
        dash_attr = f' stroke-dasharray="{st["dash"]}"' if st["dash"] else ""
        parts.append(
            f'<path class="pr-line-{st["slug"]}" d="{d_curve}" fill="none" '
            f'stroke="{st["col"]}" '
            f'stroke-width="6"{dash_attr} stroke-linecap="round" '
            f'stroke-linejoin="round"/>'
        )
        parts.append("</g>")

        # ---- threshold-sweep hover marks along the curve ---------
        # Real per-mark tooltips at a sparse subsample of thinned operating
        # points: the precision/recall pair *and* the score threshold that
        # produced it, so a reader can hover along the sweep and see how the
        # trade-off moves as the decision threshold relaxes. Sparse (~16 per
        # model, skipping the very first/last already-marked ends) so the
        # curve itself stays the star and the hover targets don't read as a
        # second, cluttered scatter layer.
        series = per_model[label]
        n_series = len(series)
        if n_series > 2:
            step = max(1, (n_series - 2) // 16)
            hover_idx = list(range(1, n_series - 1, step))
            for i in hover_idx:
                r, p, thr = series[i]
                hx, hy = sx(r), sy(p)
                htip = (
                    f"{label} — recall {r:.0%}, precision {p:.0%} at "
                    f"{_threshold_words(thr)}"
                )
                parts.append(
                    f'<g id="sw-{sw_i}" class="sw hit" tabindex="0" role="img" '
                    f'aria-label="{xml_escape(htip)}">'
                    f'<circle class="halo" cx="{hx:.1f}" cy="{hy:.1f}" r="12" '
                    f'fill="{st["col"]}" fill-opacity="0.14"/>'
                    f'<circle class="pr-mark-{st["slug"]}" cx="{hx:.1f}" '
                    f'cy="{hy:.1f}" r="3.4" fill="{st["col"]}" '
                    f'fill-opacity="0.85" stroke="#FFFFFF" stroke-width="1.2"/>'
                    f'</g>'
                )
                sw_tips.append(
                    tooltip_bubble(
                        hx, hy - 18,
                        [label, f"recall {r:.0%}, precision {p:.0%}", _threshold_words(thr)],
                        anchor="middle", canvas_w=width, canvas_h=height,
                        ink=ink, secondary=secondary, border=grid_col,
                        elem_id=f"tip-sw-{sw_i}",
                    )
                )
                sw_i += 1

    # --- shipped (max-F1) operating-point markers ----------------
    op_tips: List[str] = []
    op_i = 0
    for rec in bundle["points"]:
        label = rec["model"]
        st = style[label]
        cx, cy = sx(float(rec["recall"])), sy(float(rec["precision"]))
        tip = (
            f'{label} — shipped (max-F1) operating point: recall '
            f'{rec["recall"]:.0%}, precision {rec["precision"]:.0%}, '
            f'F1 {rec["f1"]:.2f}, {_threshold_words(rec["threshold"])}'
        )
        parts.append(
            f'<g id="op-{op_i}" class="op hit" tabindex="0" role="img" '
            f'aria-label="{xml_escape(tip)}">'
        )
        parts.append(
            f'<circle class="halo" cx="{cx:.1f}" cy="{cy:.1f}" r="26" '
            f'fill="{ink}" fill-opacity="0.08"/>'
        )
        # A distinct glyph per model: circle for the strong model, square for
        # the baseline — so the shipped points differ by shape, not hue
        # alone. Marker shapes that carry the colour-blind-safe split keep
        # their sharp corners (corners.md §5): the square stays a square, no
        # rx, so the shape itself — not a softened lozenge — is the signal.
        if st["marker"] == "circle":
            parts.append(
                f'<circle class="pr-mark-{st["slug"]}" cx="{cx:.1f}" cy="{cy:.1f}" r="13" '
                f'fill="{st["col"]}" stroke="#FFFFFF" stroke-width="3"/>'
            )
        else:
            s = 22.0
            parts.append(
                f'<rect class="pr-mark-{st["slug"]}" x="{cx - s / 2:.1f}" y="{cy - s / 2:.1f}" '
                f'width="{s:.1f}" height="{s:.1f}" '
                f'fill="{st["col"]}" stroke="#FFFFFF" stroke-width="3"/>'
            )
        parts.append("</g>")
        op_tips.append(
            tooltip_bubble(
                cx, cy - 34,
                [
                    f"{label} — shipped operating point",
                    f"recall {rec['recall']:.0%}, precision {rec['precision']:.0%}",
                    f"F1 {rec['f1']:.2f}, {_threshold_words(rec['threshold'])}",
                ],
                anchor="middle", canvas_w=width, canvas_h=height,
                ink=ink, secondary=secondary, border=grid_col,
                elem_id=f"tip-op-{op_i}",
            )
        )
        op_i += 1

    # --- inline direct labels (curve + AP), separated by shape ----
    # A small legend key sits inside the plot, low-left where both curves have
    # already dropped away. Each row shows the curve's own dash + end glyph and
    # its average precision, so the reader never round-trips to a colour key.
    key_x = sx(0.30)
    key_y = sy(0.42)
    row_h = 46.0
    for i, label in enumerate(("Gradient-boosted", "Logistic baseline")):
        st = style[label]
        ry = key_y + i * row_h
        # Sample line showing hue + dash.
        dash_attr = f' stroke-dasharray="{st["dash"]}"' if st["dash"] else ""
        parts.append(
            f'<line class="pr-line-{st["slug"]}" x1="{key_x:.1f}" y1="{ry:.1f}" '
            f'x2="{key_x + 58:.1f}" '
            f'y2="{ry:.1f}" stroke="{st["col"]}" stroke-width="6"'
            f'{dash_attr} stroke-linecap="round"/>'
        )
        # End glyph matching the operating-point marker shape. The square
        # keeps sharp corners (no rx) — same colour-blind-safe shape rule as
        # the operating-point marker it echoes.
        gx = key_x + 58
        if st["marker"] == "circle":
            parts.append(
                f'<circle class="pr-mark-{st["slug"]}" cx="{gx:.1f}" cy="{ry:.1f}" r="9" '
                f'fill="{st["col"]}" stroke="#FFFFFF" stroke-width="2.5"/>'
            )
        else:
            s = 16.0
            parts.append(
                f'<rect class="pr-mark-{st["slug"]}" x="{gx - s / 2:.1f}" y="{ry - s / 2:.1f}" '
                f'width="{s:.1f}" height="{s:.1f}" '
                f'fill="{st["col"]}" stroke="#FFFFFF" stroke-width="2.5"/>'
            )
        parts.append(
            f'<text x="{key_x + 84:.1f}" y="{ry + 8:.1f}" font-size="23" '
            f'fill="{ink}"><tspan font-weight="600">{xml_escape(label)}</tspan>'
            f'  ·  AP {ap[label]:.2f}</text>'
        )

    # Every bubble drawn last, after everything else in the document, so
    # each one always sits in front of the marks (SVG paints in document
    # order, hover state or not) -- see the `sw_tips`/`op_tips` comment
    # near the top of this function.
    parts.extend(sw_tips)
    parts.extend(op_tips)
    parts.append(
        f"<style>{foreground_tip_css(sw_i, mark_prefix='sw', tip_prefix='tip-sw')}"
        f"{foreground_tip_css(op_i, mark_prefix='op', tip_prefix='tip-op')}</style>"
    )
    parts.append(fullscreen_control(width, height, mode))
    parts.append("</svg>")
    return "\n".join(parts)


def make_prcurve(
    data: Optional[List[Dict[str, Any]]] = None,
    *,
    out: Optional[Path | str] = None,
    title: str = "",
    mode: str = "self-contained",
    accessibility: str = "universal",
    theme: str = "corporate",
) -> Path:
    """Render the precision-recall curve and write the SVG to *out*.

    Parameters
    ----------
    data : list[dict[str, Any]] or None
        Rows with keys ``is_fraud`` (bool/0-1) and per-model score keys
        ``score_strong``, ``score_weak``. Defaults to :data:`DEMO_DATA`.
    out : Path, str, or None
        Output path (.svg). Defaults to ``assets/svg-examples/prcurve.svg``.
    title : str, optional
        Accepted for signature parity; the figure's headline is baked into
        the diagnostic narrative (unused).
    mode, accessibility : str
        Forwarded to :func:`build_svg`.
    theme : str, optional
        Visual theme. Forwarded to :func:`build_svg`.

    Returns
    -------
    Path
        Absolute path to the written SVG file.
    """
    _ = title
    svg = build_svg(data, mode=mode, accessibility=accessibility, theme=theme)
    dest = Path(out) if out else svg_example_path(__file__, "prcurve")
    return write_svg(dest, svg, theme=theme)


def main() -> None:
    """Write the precision-recall-curve SVG to the canonical path (or --out)."""
    render_cli(
        __file__, "prcurve", build_svg,
        description="Render the precision-recall curve SVG (with average "
        "precision, no-skill baseline and iso-F1 contours).",
    )



# ── kit: the data comes from data.csv ─────────────────────────────────────
# The generator keeps its own DEMO_DATA above as a fallback and as a record
# of the expected column names. When data.csv is present (it ships with this
# kit), it wins: edit the CSV, re-run this file, and the figure changes.
from sprezzature_svg import load_rows  # noqa: E402

try:
    DEMO_DATA = load_rows("data.csv") or DEMO_DATA
except FileNotFoundError:
    pass


if __name__ == "__main__":
    main()
