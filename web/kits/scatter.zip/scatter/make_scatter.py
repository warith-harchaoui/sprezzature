#!/usr/bin/env python3
"""
make_scatter — a house-styled scatter plot as a hand-authored SVG.

Plots two numeric variables against each other, with an optional
categorical color and numeric size encoding, to reveal correlation,
clusters, or outliers. Typical uses: price vs. quality rating, engine
size vs. fuel economy, marketing spend vs. conversions.

This module builds the ``<svg>`` markup by hand. Every point carries a
native ``<title>`` tooltip with its exact reading.

Author
------
`Warith Harchaoui, Ph.D. <https://www.linkedin.com/in/warith-harchaoui/>`_
"""

from __future__ import annotations

import math
import random
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

from sprezzature_svg import fullscreen_control  # noqa: E402
from sprezzature_svg import render_cli, svg_example_path, write_svg  # noqa: E402
from sprezzature_svg import BG, GRIDLINE, INK, SECONDARY, cycle_hues  # noqa: E402
from sprezzature_svg import foreground_tip_css, fmt_number, svg_open, tooltip_bubble, xml_escape  # noqa: E402
from sprezzature_svg import chrome_stack_for_theme, mono_stack_for_theme  # noqa: E402


SEGMENTS = ["Economy", "Midsize", "Premium"]


def _make_demo_data() -> List[Dict[str, Any]]:
    rng = random.Random(11)
    rows: List[Dict[str, Any]] = []
    segments = {
        "Economy": (25, 35, 90, 120),
        "Midsize": (18, 26, 130, 180),
        "Premium": (10, 18, 200, 320),
    }
    for segment, (mpg_lo, mpg_hi, hp_lo, hp_hi) in segments.items():
        for _ in range(15):
            rows.append({
                "segment": segment,
                "horsepower": round(rng.uniform(hp_lo, hp_hi), 1),
                "mpg": round(rng.uniform(mpg_lo, mpg_hi), 1),
                "weight": round(rng.uniform(1100, 1900), 0),
            })
    return rows


DEMO_DATA: List[Dict[str, Any]] = _make_demo_data()


def _segment_colors(
    segments: List[str], accessibility: str = "universal", theme: str = "corporate"
) -> Dict[str, str]:
    return cycle_hues(segments, accessibility, theme=theme)


def build_svg(
    data: Optional[List[Dict[str, Any]]] = None,
    title: str = "Horsepower vs. Fuel Economy",
    subtitle: str = "Synthetic sample, sized by weight, colored by segment",
    width: int = 845,
    height: int = 519,
    mode: str = "self-contained",
    accessibility: str = "universal",
    x_label: str = "Horsepower",
    y_label: str = "Fuel economy (mpg)",
    diagonal: bool = False,
    square: bool = False,
    theme: str = "corporate",
    segment_legend_title: str = "Segment",
    weight_legend_title: str = "Weight (kg)",
) -> str:
    """Assemble the full scatter plot SVG document as a string.

    Parameters
    ----------
    data : list of dict or None
        Rows with keys ``segment``, ``horsepower``, ``mpg``, ``weight``.
        Defaults to :data:`DEMO_DATA`.
    title, subtitle : str
        Chart text.
    width, height : int
        Canvas size in pixels.
    segment_legend_title : str, optional
        Header above the colour-segment legend (was hardcoded ``"Segment"``).
    weight_legend_title : str, optional
        Header above the size legend shown when ``weight`` values are present
        (was hardcoded ``"Weight (kg)"``) — pass a label matching whatever
        ``weight`` actually encodes for non-vehicle data.
    mode, accessibility : str, optional
        Forwarded to :func:`_interactive.fullscreen_control` /
        :func:`_style.load_palette`.
    theme : str, optional
        Visual theme: ``"corporate"`` (default, Roboto -- byte-identical to
        the pre-theme render) or ``"academic"`` (LaTeX-style Latin Modern).
        See :func:`sprezzature_figures.fonts.chrome_stack_for_theme`.

    Returns
    -------
    str
        A complete, standalone SVG document.
    """
    mono_family = mono_stack_for_theme(theme)
    rows = data if data else DEMO_DATA
    seen_segments: List[str] = []
    for r in rows:
        seg = r.get("segment")
        if seg is not None and seg not in seen_segments:
            seen_segments.append(seg)
    segments = [s for s in SEGMENTS if s in seen_segments] + [s for s in seen_segments if s not in SEGMENTS]
    colors = _segment_colors(segments, accessibility, theme=theme)
    has_weight = any("weight" in r and r["weight"] is not None for r in rows)

    xs = [float(r["horsepower"]) for r in rows]
    ys = [float(r["mpg"]) for r in rows]
    x_min, x_max = min(xs), max(xs)
    y_min, y_max = min(ys), max(ys)
    x_pad, y_pad = (x_max - x_min) * 0.08, (y_max - y_min) * 0.10
    x0, x1 = x_min - x_pad, x_max + x_pad
    y0, y1 = y_min - y_pad, y_max + y_pad
    # Do not pad an axis below zero when all its values are non-negative (distances,
    # counts, magnitudes): a negative axis floor would be meaningless.
    if x_min >= 0:
        x0 = max(0.0, x0)
    if y_min >= 0:
        y0 = max(0.0, y0)
    if square:
        # One shared domain so both axes carry the same units, and (with a square plot
        # area below) the same resolution, making the y = x line a true 45-degree diagonal.
        lo, hi = min(x0, y0), max(x1, y1)
        x0 = y0 = lo
        x1 = y1 = hi

    right_margin = 176.0 if (has_weight or len(segments) > 1) else 40.0
    plot_x, plot_y = 60.0, 118.0
    bottom_reserved = 70.0
    plot_w = width - plot_x - right_margin
    plot_h = height - plot_y - bottom_reserved
    if square:
        plot_w = plot_h = min(plot_w, plot_h)  # equal pixels per unit on both axes

    def x_for(v: float) -> float:
        return plot_x + (v - x0) / (x1 - x0) * plot_w

    def y_for(v: float) -> float:
        return plot_y + plot_h - (v - y0) / (y1 - y0) * plot_h

    weights = [float(r.get("weight") or 0) for r in rows]
    w_max = max(weights) if weights and has_weight else 1.0
    w_min = min(weights) if weights and has_weight else 0.0
    r_min, r_max = 4.5, 11.0

    def r_for(w: float) -> float:
        if not has_weight or w_max <= 0:
            return 6.0
        return r_min + (r_max - r_min) * math.sqrt(max(w, 0.0) / w_max)

    parts: List[str] = []
    parts.append(svg_open(width, height, "sc-title", "sc-desc", font_family=chrome_stack_for_theme(theme)))
    parts.append(f'<title id="sc-title">{xml_escape(title)}</title>')
    parts.append(
        f'<desc id="sc-desc">Scatter plot of {len(rows)} points. Horizontal axis is the '
        f'first measure, vertical axis the second{"; bubble size is weight" if has_weight else ""}'
        f'{"; colour marks the segment" if len(segments) > 1 else ""}. Hover or focus a point '
        f'for its exact reading.</desc>'
    )

    parts.append(
        "<style>"
        ".pt{transition:opacity .12s ease,stroke-width .12s ease;}"
        ".pt:hover,.pt:focus{stroke-width:2.4;outline:none;}"
        ".tip{opacity:0;pointer-events:none;transition:opacity .12s ease}"
        + foreground_tip_css(len(rows))
        + "@media (prefers-reduced-motion: reduce){.pt{transition:none;}.tip{transition:none}}"
        "</style>"
    )

    parts.append(f'<rect width="{width}" height="{height}" fill="{BG}"/>')
    parts.append(
        f'<text x="40" y="46" font-size="24" font-weight="700" fill="{INK}" '
        f'letter-spacing="-0.3">{xml_escape(title)}</text>'
    )
    parts.append(f'<text x="40" y="70" font-size="14" fill="{SECONDARY}">{xml_escape(subtitle)}</text>')

    # ---- y-axis gridlines ----
    y_ticks = 6
    for i in range(y_ticks + 1):
        val = y0 + (y1 - y0) * i / y_ticks
        ty = y_for(val)
        parts.append(
            f'<line x1="{plot_x:.1f}" y1="{ty:.1f}" x2="{plot_x + plot_w:.1f}" y2="{ty:.1f}" '
            f'stroke="{GRIDLINE}" stroke-width="1"/>'
        )
        parts.append(
            f'<text x="{plot_x - 10:.1f}" y="{ty + 4:.1f}" font-size="11" font-family="{mono_family}" '
            f'fill="{SECONDARY}" text-anchor="end">{fmt_number(val)}</text>'
        )
    parts.append(
        f'<text x="18" y="{plot_y + plot_h / 2:.1f}" font-size="13" fill="{INK}" '
        f'text-anchor="middle" transform="rotate(-90 18 {plot_y + plot_h / 2:.1f})">{xml_escape(y_label)}</text>'
    )

    # ---- x-axis ----
    axis_y = plot_y + plot_h
    parts.append(
        f'<line x1="{plot_x:.1f}" y1="{axis_y:.1f}" x2="{plot_x + plot_w:.1f}" y2="{axis_y:.1f}" '
        f'stroke="{INK}" stroke-width="1.2"/>'
    )
    x_ticks = 6
    for i in range(x_ticks + 1):
        val = x0 + (x1 - x0) * i / x_ticks
        tx = x_for(val)
        parts.append(
            f'<line x1="{tx:.1f}" y1="{axis_y:.1f}" x2="{tx:.1f}" y2="{axis_y + 6:.1f}" stroke="{INK}" stroke-width="1"/>'
        )
        parts.append(
            f'<text x="{tx:.1f}" y="{axis_y + 20:.1f}" font-size="11" font-family="{mono_family}" '
            f'fill="{SECONDARY}" text-anchor="middle">{fmt_number(val)}</text>'
        )
    parts.append(
        f'<text x="{plot_x + plot_w / 2:.1f}" y="{axis_y + 42:.1f}" font-size="13" '
        f'fill="{INK}" text-anchor="middle">{xml_escape(x_label)}</text>'
    )

    # ---- optional y = x reference line (identity: points on it are unchanged) ----
    if diagonal:
        lo, hi = max(x0, y0), min(x1, y1)
        if hi > lo:
            parts.append(
                f'<line x1="{x_for(lo):.1f}" y1="{y_for(lo):.1f}" x2="{x_for(hi):.1f}" y2="{y_for(hi):.1f}" '
                f'stroke="{SECONDARY}" stroke-width="1.3" stroke-dasharray="5 4" opacity="0.8"/>'
            )

    # ---- points, largest-first so small ones never hide under big ones ----
    ordered = sorted(rows, key=lambda r: -(float(r.get("weight") or 0)))
    # Bubbles are collected here and drawn only once, all together, after
    # the point loop (see `parts.extend(tips)` below): SVG has no z-index,
    # so a bubble sitting next to its own point would be covered by any
    # point drawn afterward -- points are already sorted largest-first so
    # small ones stay visible, but a bubble is thinner than even the
    # smallest point and would still lose to a later, larger one nearby.
    # `i` pairs each point with its bubble (`hit-N`/`tip-N`).
    tips: List[str] = []
    for i, row in enumerate(ordered):
        seg = row.get("segment", segments[0] if segments else "")
        cx, cy = x_for(float(row["horsepower"])), y_for(float(row["mpg"]))
        r = r_for(float(row.get("weight") or 0))
        color = colors.get(seg, colors[segments[0]] if segments else "#007AFF")
        bits = [f"Horsepower {row['horsepower']:.0f}", f"Fuel economy {row['mpg']:.1f} mpg"]
        if has_weight:
            bits.append(f"weight {row['weight']:.0f} kg")
        if seg:
            bits.insert(0, str(seg))
        tip = ", ".join(bits)
        parts.append(
            f'<circle id="hit-{i}" class="pt hit" tabindex="0" cx="{cx:.1f}" cy="{cy:.1f}" r="{r:.1f}" '
            f'fill="{color}" fill-opacity="0.72" stroke="{color}" stroke-width="1.2" '
            f'role="img" aria-label="{xml_escape(tip)}"/>'
        )
        tip_lines = [str(seg)] if seg else []
        tip_lines.append(f"HP {row['horsepower']:.0f}, {row['mpg']:.1f} mpg")
        if has_weight:
            tip_lines.append(f"Weight {row['weight']:.0f} kg")
        tips.append(
            tooltip_bubble(
                cx, cy - r - 12,
                tip_lines,
                anchor="middle", canvas_w=width, canvas_h=height,
                ink=INK, secondary=SECONDARY, border=GRIDLINE,
                elem_id=f"tip-{i}",
            )
        )
    parts.extend(tips)

    # ---- segment legend ----
    if len(segments) > 1:
        leg_x = width - right_margin + 28
        leg_y = 118.0
        parts.append(f'<text x="{leg_x:.1f}" y="{leg_y:.1f}" font-size="13" font-weight="700" fill="{INK}">{xml_escape(segment_legend_title)}</text>')
        for i, seg in enumerate(segments):
            ry = leg_y + 26 + i * 26
            parts.append(f'<circle cx="{leg_x + 7:.1f}" cy="{ry - 5:.1f}" r="7" fill="{colors[seg]}" fill-opacity="0.85"/>')
            parts.append(f'<text x="{leg_x + 20:.1f}" y="{ry:.1f}" font-size="13" fill="{INK}">{xml_escape(seg)}</text>')

        if has_weight:
            size_leg_y = leg_y + 26 + len(segments) * 26 + 30
            parts.append(f'<text x="{leg_x:.1f}" y="{size_leg_y:.1f}" font-size="13" font-weight="700" fill="{INK}">{xml_escape(weight_legend_title)}</text>')
            cursor_y = size_leg_y + 22
            # Bracket the *actual* weight range in the plotted data (not an
            # arbitrary fraction of the max) -- a legend value smaller than
            # every real data point (e.g. the old w_max/3) draws a reference
            # circle no bubble in the plot ever matches, which misleads
            # rather than calibrates the eye.
            for val in (w_max, w_min):
                r = r_for(val)
                cy = cursor_y + r
                parts.append(f'<circle cx="{leg_x + r_max:.1f}" cy="{cy:.1f}" r="{r:.1f}" fill="none" stroke="{SECONDARY}" stroke-width="1"/>')
                parts.append(
                    f'<text x="{leg_x + r_max * 2 + 10:.1f}" y="{cy + 4:.1f}" font-size="12" '
                    f'font-family="{mono_family}" fill="{SECONDARY}">{val:.0f}</text>'
                )
                cursor_y = cy + r + 8

    parts.append(fullscreen_control(width, height, mode))
    parts.append("</svg>")
    return "\n".join(parts)


def make_scatter(
    data: Optional[List[Dict[str, Any]]] = None,
    *,
    out: Optional[Path | str] = None,
    title: str = "Horsepower vs. Fuel Economy",
    subtitle: str = "Synthetic sample, sized by weight, colored by segment",
    width: int = 845,
    height: int = 519,
    mode: str = "self-contained",
    accessibility: str = "universal",
    x_label: str = "Horsepower",
    y_label: str = "Fuel economy (mpg)",
    diagonal: bool = False,
    square: bool = False,
    theme: str = "corporate",
    segment_legend_title: str = "Segment",
    weight_legend_title: str = "Weight (kg)",
) -> Path:
    """Render a hand-authored scatter plot and write the SVG to *out*.

    Parameters
    ----------
    data : list[dict[str, Any]] or None
        Rows with keys ``segment`` (str), ``horsepower`` (float), ``mpg``
        (float), ``weight`` (float). Defaults to DEMO_DATA.
    out : Path, str, or None
        Output path (.svg). Defaults to ``assets/svg-examples/scatter.svg``.
    title, subtitle : str
        Chart text.
    width, height : int
        Canvas size in pixels.
    mode, accessibility : str
        Forwarded to :func:`build_svg`.
    theme : str, optional
        Visual theme. Forwarded to :func:`build_svg`.
    segment_legend_title, weight_legend_title : str, optional
        Forwarded to :func:`build_svg` — were hardcoded ``"Segment"`` and
        ``"Weight (kg)"`` with no way to override them for non-vehicle data.

    Returns
    -------
    Path
        Absolute path to the written SVG file.

    Examples
    --------
    >>> p = make_scatter()
    >>> p.exists()
    True
    """
    svg = build_svg(data, title=title, subtitle=subtitle, width=width, height=height,
                     mode=mode, accessibility=accessibility, x_label=x_label, y_label=y_label,
                     diagonal=diagonal, square=square, theme=theme,
                     segment_legend_title=segment_legend_title, weight_legend_title=weight_legend_title)
    dest = Path(out) if out else svg_example_path(__file__, "scatter")
    return write_svg(dest, svg, theme=theme)


def main() -> None:
    """CLI entry point: build the SVG and write it to disk."""
    render_cli(__file__, "scatter", build_svg, description="Generate a scatter plot.")



# ── kit: the data comes from data.csv ─────────────────────────────────────
# The generator keeps its own DEMO_DATA above as a fallback and as a record
# of the expected column names. When data.csv is present (it ships with this
# kit), it wins: edit the CSV, re-run this file, and the figure changes.
from sprezzature_svg import load_rows  # noqa: E402

try:
    DEMO_DATA = load_rows("data.csv") or DEMO_DATA
except FileNotFoundError:
    pass


if __name__ == "__main__":
    main()
